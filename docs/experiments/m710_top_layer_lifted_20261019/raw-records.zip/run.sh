#!/bin/bash
source /opt/ros/humble/setup.bash
set -eu
cd /work-top-layer-lifted-run-20261019
export PYTHONPATH=src PYTHONNOUSERSITE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export M710_MOVEIT_ASSET_ROOT=$PWD
exec /opt/planning-opt-20261003-venv/bin/python tools/audit_m710_coupled_batch_start.py \
 --source-commit a93ebbb4a9ed866c552f28ef5e86f885f6a840fe --source-manifest source-manifest.json \
 --worker-command /tmp/right-inner-20261019/worker.sh \
 --worker-binary /tmp/right-inner-20261019/build/m710_moveit_worker \
 --seeds 71070 71071 --height-step-m .01 --output /tmp/top-layer-lifted-20261019/formal
