Open initial-rejection.html in a browser. All resources are embedded.
This is INITIAL REJECTION INSPECTION, NOT a continuous pick/place replay.
0/5 completed; 40 cartons retained; no robot motion, release, reception or drain.
The MP4 is an 8-second static-scene inspection presentation at 640x360/5fps.
