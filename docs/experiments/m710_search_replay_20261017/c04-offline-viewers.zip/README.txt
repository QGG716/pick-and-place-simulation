打开 baseline-c04.html 查看未改变求解策略的 BASELINE；打开 revised-c04.html 查看新版失败诊断。
两份 HTML 均完全离线，包含官方机器人碰撞网格、完整工具与原始数据，不需要 ROS、开发服务器或 CDN。
pregrasp / loaded transit 页签切换阶段；attempt 选择原生运动请求。IK 面板包含未进入 RRT 的失败恢复。
搜索条是实际事件顺序；轨迹条是原生输出的预计运动时间。两者不等价。
点击节点或拒绝线显示完整机器人和负载姿态；绿/红点是该次扩展实际返回的自定义检查样本。
普通 MoveIt 检查或缓存未给出对应见证时显示 UNKNOWN。不会用旧 last_failure 补原因。
默认只抽稀显示拒绝线，可勾选完整显示；原始记录不抽稀。TCP 弦线仅 DISPLAY_ONLY，不是碰撞证明。
BASELINE 视频使用真实输出样本，轨迹按 2 倍预计时间播放；并非物理执行录像。
新版诊断正面 transit 原生返回 SUCCESS，但超过共享连接阶段预算，任务拒绝接受；不能把该路径当作任务成功。
PLANNING_REPLAY_NOT_PHYSICAL_EXECUTION
qualification_status=NOT_EVALUATED
continuous_swept_proof=false
physical_execution=NOT_RUN
