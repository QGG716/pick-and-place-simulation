#!/bin/bash
set -euo pipefail
rootfs=/root/autodl-tmp/m710-l05-x500-20261022/rootfs
chroot "$rootfs" /bin/bash -s <<'INSIDE'
set -euo pipefail
export PYTHONPATH=/work-l00-top-xplus200-b05652e/src:/work-l00-top-xplus200-b05652e/tools PYTHONNOUSERSITE=1
export M710_MOVEIT_ASSET_ROOT=/work-l00-top-xplus200-b05652e OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cd /l00-top-xplus200-v2-20261024
test "$(cat formal-v1.exit)" = 0
set +e
/opt/planning-venv/bin/python /work-l00-top-xplus200-b05652e/tools/verify_m710_population.py formal-v1 > original-verifier.log 2>&1
printf "%s\n" "$?" > original-verifier.exit
set -e
/opt/planning-venv/bin/python verify_m710_population.py formal-v1 --prepare-replay replay-v1
/opt/planning-venv/bin/python analyze.py
/opt/planning-venv/bin/python - <<'PY'
import json
from pathlib import Path
from export_m710_top_layer_replay import export
if json.loads(Path('formal-v1/summary.json').read_text())['completed_count']:
    export(Path('replay-v1'),71070,Path('analysis-v1/accepted-cycles.html'))
PY
INSIDE
tar czf /root/autodl-tmp/m710-l05-x500-20261022/l00-top-xplus200-v2-analysis.tar.gz -C "$rootfs/l00-top-xplus200-v2-20261024" analysis-v1 formal-v1/summary.json formal-v1/protocol.json formal-v1/verification.json formal-v1/initial-state-check.json formal-v1/predecessor.json focused-tests.log production-check.log formal-v1.log formal-v1.exit raw-receipt.json build.log native-policy-tests.log native-binary-sha256.txt original-verifier.log original-verifier.exit verify_m710_population.py
