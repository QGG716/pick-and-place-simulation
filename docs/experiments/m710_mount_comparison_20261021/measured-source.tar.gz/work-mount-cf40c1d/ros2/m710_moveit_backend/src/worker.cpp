#include "request_evidence.h"
#include "search_trace.h"
// JSONL is the sole application IPC. ROS logging goes to stderr, never stdout.
#include <rclcpp/rclcpp.hpp>
#include <moveit/robot_model_loader/robot_model_loader.h>
#include <moveit/planning_scene/planning_scene.h>
#include <moveit/planning_pipeline/planning_pipeline.h>
#include <moveit/task_constructor/task.h>
#include <moveit/task_constructor/stages/fixed_state.h>
#include <moveit/task_constructor/stages/move_to.h>
#include <moveit/task_constructor/solvers/pipeline_planner.h>
#include <moveit/trajectory_processing/iterative_time_parameterization.h>
#include <moveit/robot_state/conversions.h>
#include <moveit/utils/moveit_error_code.h>
#include <ompl/util/RandomNumbers.h>
#include <nlohmann/json.hpp>
#include <chrono>
#include <iostream>
#include <map>
#include <set>
#include "clearance.h"
#include "bounded_ik.h"
#include "process_policy.h"
#include "scene_geometry.h"
#include "native_zero_motion.h"
#include "native_semantic_event.h"
#include "static_prior.h"
#include "lifted_receiver.h"
#include "coupled_receiver.h"
#include "nominal_release.h"
#include <moveit/kinematic_constraints/kinematic_constraint.h>
#include <moveit/kinematic_constraints/utils.h>

using J = nlohmann::json;
namespace mtc = moveit::task_constructor;
using Clock = std::chrono::steady_clock;
// Operations dispatched after init; keep this gate shared with the protocol regression.
bool knownInitializedOperation(const std::string& op) {
  return op=="fk" || op=="ik" || op=="ik_batch" || op=="load_static_prior" ||
    op=="build_static_prior" || op=="task_audit" || op=="plan" ||
    op=="diagnostic_connection" || op=="compose" || op=="inspect" ||
    op=="validate" || op=="check_receiver_state" || op=="check_start" || (op=="check_extraction_end" || op=="check_transit_end");
}
double seconds(Clock::time_point t) { return std::chrono::duration<double>(Clock::now()-t).count(); }
Eigen::Isometry3d matrix(const J& j) {
  if (j.size()!=4) throw std::runtime_error("INVALID_TRANSFORM");
  Eigen::Isometry3d t=Eigen::Isometry3d::Identity();
  for(int r=0;r<4;++r) for(int c=0;c<4;++c) t.matrix()(r,c)=j.at(r).at(c).get<double>();
  if(!t.matrix().allFinite() || (t.linear().transpose()*t.linear()-Eigen::Matrix3d::Identity()).norm()>1e-8
     || std::abs(t.linear().determinant()-1)>1e-8) throw std::runtime_error("INVALID_TRANSFORM");
  return t;
}
J serial(const Eigen::Isometry3d& t) {
  J j=J::array(); for(int r=0;r<4;++r) { J row=J::array(); for(int c=0;c<4;++c) row.push_back(t.matrix()(r,c)); j.push_back(row); } return j;
}
geometry_msgs::msg::Pose pose(const J& value) {
  auto t=matrix(value); Eigen::Quaterniond q(t.linear()); geometry_msgs::msg::Pose p;
  p.position.x=t.translation().x(); p.position.y=t.translation().y(); p.position.z=t.translation().z();
  p.orientation.x=q.x();p.orientation.y=q.y();p.orientation.z=q.z();p.orientation.w=q.w(); return p;
}
moveit_msgs::msg::CollisionObject object(const J& b, const std::string& frame="world") {
  moveit_msgs::msg::CollisionObject o; o.header.frame_id=frame; o.id=b.at("id"); o.operation=o.ADD;
  if(b.contains("solid")) {
    m710::validateSolid(b);shape_msgs::msg::Mesh mesh;
    for(const auto& v:m710::solidVertices(b)){geometry_msgs::msg::Point p;p.x=v.x();p.y=v.y();p.z=v.z();mesh.vertices.push_back(p);}
    for(const auto& f:m710::solidFaces())for(int i:{1,2}) {
      shape_msgs::msg::MeshTriangle t;t.vertex_indices={static_cast<uint32_t>(f[0]),
        static_cast<uint32_t>(f[i]),static_cast<uint32_t>(f[i+1])};mesh.triangles.push_back(t);
    }
    o.meshes.push_back(mesh);o.mesh_poses.push_back(pose(b.at("pose")));return o;
  }
  shape_msgs::msg::SolidPrimitive s; s.type=s.BOX; auto dimensions=b.at("size").get<std::vector<double>>(); s.dimensions.assign(dimensions.begin(),dimensions.end());
  if(s.dimensions.size()!=3) throw std::runtime_error("INVALID_BOX");
  for(auto d:s.dimensions) if(!std::isfinite(d)||d<=0) throw std::runtime_error("INVALID_BOX");
  o.primitives.push_back(s); o.primitive_poses.push_back(pose(b.at("pose"))); return o;
}


// This stage imports an already authoritative-checked process path. It does
// not claim native coverage of compression/history constraints and never plans.
class CheckedProcessStage : public mtc::PropagatingForward {
  J spec;
public:
  explicit CheckedProcessStage(J value): mtc::PropagatingForward(value.at("name").get<std::string>()), spec(std::move(value)) {}
  void computeForward(const mtc::InterfaceState& from) override {
    auto next=from.scene()->diff();next->decoupleParent();
    auto state=next->getCurrentState(); std::vector<double> incoming;
    state.copyJointGroupPositions("manipulator",incoming);
    auto first=spec.at("path").at(0).get<std::vector<double>>();
    if(first.size()!=incoming.size()) throw std::runtime_error("STAGE_JOINT_COUNT_MISMATCH");
    for(size_t i=0;i<first.size();++i) if(std::abs(first[i]-incoming[i])>1e-9) throw std::runtime_error("STAGE_DISCONTINUITY");
    auto trajectory=std::make_shared<robot_trajectory::RobotTrajectory>(state.getRobotModel(),"manipulator");
    size_t index=0;
    for(const auto& row:spec.at("path")) {
      auto q=row.get<std::vector<double>>();state.setJointGroupPositions("manipulator",q);state.update();
      if(!state.satisfiesBounds()) throw std::runtime_error("STAGE_BOUNDS");
      trajectory->addSuffixWayPoint(state,index==0?0.:spec.at("durations").at(index-1).get<double>());++index;
    }
    next->setCurrentState(state);
    if(spec.contains("attach")) {
      const auto& b=spec.at("attach");std::string id=b.at("id");
      if(!next->getWorld()->hasObject(id)) throw std::runtime_error("ATTACH_WORLD_OBJECT_MISSING");
      next->getWorldNonConst()->removeObject(id);
      moveit_msgs::msg::AttachedCollisionObject a;a.link_name="flange";a.object=object(b,"flange");
      a.touch_links=b.at("touch_links").get<std::vector<std::string>>();
      if(!next->processAttachedCollisionObjectMsg(a)) throw std::runtime_error("ATTACH_FAILED");
    }
    if(spec.contains("release")) {
      const auto& b=spec.at("release");std::string id=b.at("id");
      if(!next->getCurrentState().hasAttachedBody(id)) throw std::runtime_error("RELEASE_ATTACHED_OBJECT_MISSING");
      moveit_msgs::msg::AttachedCollisionObject a;a.link_name="flange";a.object.id=id;a.object.operation=a.object.REMOVE;
      if(!next->processAttachedCollisionObjectMsg(a) || !next->processCollisionObjectMsg(object(b))) throw std::runtime_error("RELEASE_FAILED");
      if(next->getCurrentState().hasAttachedBody(id) || !next->getWorld()->hasObject(id)) throw std::runtime_error("RELEASE_OBJECT_STATE_INVALID");
    }
    mtc::SubTrajectory solution(trajectory);solution.setComment(spec.at("generator"));
    sendForward(from,mtc::InterfaceState(next),std::move(solution));
  }
};


class CountedPlanner : public mtc::solvers::PipelinePlanner {
  size_t& count;
public:
  CountedPlanner(const planning_pipeline::PlanningPipelinePtr& pipeline, size_t& calls): PipelinePlanner(pipeline), count(calls) {}
  Result plan(const planning_scene::PlanningSceneConstPtr& from, const planning_scene::PlanningSceneConstPtr& to,
    const moveit::core::JointModelGroup* group, double timeout, robot_trajectory::RobotTrajectoryPtr& result,
    const moveit_msgs::msg::Constraints& constraints) override {
    ++count; return PipelinePlanner::plan(from,to,group,timeout,result,constraints);
  }
  Result plan(const planning_scene::PlanningSceneConstPtr& from, const moveit::core::LinkModel& link,
    const Eigen::Isometry3d& offset, const Eigen::Isometry3d& target, const moveit::core::JointModelGroup* group,
    double timeout, robot_trajectory::RobotTrajectoryPtr& result, const moveit_msgs::msg::Constraints& constraints) override {
    ++count; return PipelinePlanner::plan(from,link,offset,target,group,timeout,result,constraints);
  }
};

// Cache is native-owned and scoped to this resident task. It can only be
// populated inside computeForward(), never JSON paths. A checked semantic
// event has an end scene and no motion trajectory.
struct NativeStageRecord {
  J request,result;
  planning_scene::PlanningScenePtr start,end;
  robot_trajectory::RobotTrajectoryPtr trajectory;
  std::shared_ptr<m710::Clearance> clearance;
  std::shared_ptr<m710::ProcessPolicy> process;
  std::string parent;
  size_t cache_hits=0;
  bool ready=false;
};
class NativeProcessStage : public mtc::PropagatingForward {
  std::shared_ptr<NativeStageRecord> record_;
  std::function<void(NativeStageRecord&)> generate_;
  std::function<void(const planning_scene::PlanningSceneConstPtr&,const planning_scene::PlanningSceneConstPtr&,const J&)> verify_scene_;
public:
  NativeProcessStage(std::shared_ptr<NativeStageRecord> record,std::function<void(NativeStageRecord&)> generate,
    std::function<void(const planning_scene::PlanningSceneConstPtr&,const planning_scene::PlanningSceneConstPtr&,const J&)> verify_scene)
    :mtc::PropagatingForward(record->request.at("stage_id").get<std::string>()),record_(std::move(record)),generate_(std::move(generate)),verify_scene_(std::move(verify_scene)) {}
  void computeForward(const mtc::InterfaceState& from) override {
    auto& r=*record_;std::vector<double> q;
    from.scene()->getCurrentState().copyJointGroupPositions("manipulator",q);
    const auto expected=r.request.at("q_start").get<std::vector<double>>();
    if(q.size()!=expected.size()) throw std::runtime_error("NATIVE_TASK_JOINT_COUNT_MISMATCH");
    if(r.request.value("pipeline_id",std::string())=="external_axis" && q!=expected)
      throw std::runtime_error("NATIVE_TASK_EXTERNAL_AXIS_ROBOT_STATE_CHANGED");
    for(size_t i=0;i<q.size();++i) if(std::abs(q[i]-expected[i])>1e-9) throw std::runtime_error("NATIVE_TASK_UNPLANNED_CONNECTION");
    verify_scene_(from.scene(),r.start,r.request);
    if(r.ready) ++r.cache_hits;else generate_(r);
    if(!r.ready) return;
    if(!r.end) throw std::runtime_error("NATIVE_TASK_READY_WITHOUT_END");
    if(r.result.value("generation_source",std::string())=="SEMANTIC_EVENT") {
      std::vector<double> terminal;r.end->getCurrentState().copyJointGroupPositions("manipulator",terminal);
      // No-motion semantics cannot use the motion connection tolerance to
      // change the real predecessor, even by a sub-nanoradian amount.
      if(q!=terminal) {r.ready=false;throw std::runtime_error("NATIVE_SEMANTIC_START_CHANGED");}
    }
    mtc::SubTrajectory solution(r.trajectory);solution.setComment("native_task_generated:"+r.request.at("stage_id").get<std::string>());
    sendForward(from,mtc::InterfaceState(r.end),std::move(solution));
  }
};
struct NativeTaskSession {
  std::unique_ptr<mtc::Task> task;
  std::map<std::string,std::shared_ptr<NativeStageRecord>> records;
  std::vector<std::string> active;
  J initial_q,initial_world;
  std::string target_id;
  size_t solve_calls=0,backtracks=0;
  bool diagnostic=false;
};
// Reply compression only. The request, bound predicates and native record
// context retain the complete policy; cold/build outputs are unaffected.
void compactPlanningOnlyReply(J& reply,bool planning_only,const std::string& mode) {
  if(planning_only && mode=="static_prior_fast" && reply.contains("clearance") && reply.at("clearance").is_object())
    reply["clearance"].erase("policy");
}
class Worker {
  rclcpp::Node::SharedPtr node;
  std::shared_ptr<robot_model_loader::RobotModelLoader> loader;
  moveit::core::RobotModelPtr model;
  planning_scene::PlanningScenePtr base;
  std::map<std::string,planning_pipeline::PlanningPipelinePtr> pipelines;
  std::vector<std::string> names;
  J identity, scene_content, bound_policy, bound_tools, bound_compliant, bound_process_geometry; std::string scene_key;
  uint32_t seed=0; size_t requests=0; std::map<std::string,size_t> calls;
  std::map<std::string,std::unique_ptr<NativeTaskSession>> tasks;
  size_t ik_calls=0;
  bool bounded_preplace_ik_enabled=false;
  bool single_target_recovery_enabled=false;
  bool planning_only=false;  // Bound at process initialization, never per-stage downgrade.
  std::string planning_mode="cold_from_scratch";
  J static_prior_database=nullptr;
  std::string prior_placement_policy_sha256;
  void checkPriorContext(const J& req) const {
    const auto& context=req.at("prior_context");const auto& policy=req.at("clearance_policy");
    auto equal=[&](const char* key,const J& value) {
      if(!context.contains(key)||context.at(key)!=value) throw std::runtime_error(std::string("PRIOR_REQUEST_BINDING_MISMATCH:")+key);
    };
    auto sorted=[](J value){std::sort(value.begin(),value.end());return value;};
    equal("schema","m710_static_prior_context_v1");equal("identity",identity);
    equal("flange_from_task_tcp",identity.at("flange_from_task_tcp"));
    if(req.at("flange_from_task_tcp")!=identity.at("flange_from_task_tcp")) throw std::runtime_error("TASK_TCP_CONTEXT_MISMATCH");
    equal("tool_links",sorted(bound_tools));equal("compliant_tool_links",sorted(bound_compliant));
    equal("collision_policy",bound_policy);
    J fixed=J::array();std::set<std::string> dynamic;
    for(const auto& body:req.at("world")) {
      const auto category=body.value("category",std::string());
      if(category=="carton"||category=="payload") dynamic.insert(body.at("id").get<std::string>());
      else fixed.push_back(body);
    }
    std::sort(fixed.begin(),fixed.end(),[](const J& a,const J& b){return a.at("id").get<std::string>()<b.at("id").get<std::string>();});
    equal("static_world",fixed);
    const auto& attached=req.at("attachment");
    if(!attached.is_null()) dynamic.insert(attached.at("id").get<std::string>());
    J pairs=J::array();
    for(const auto& pair:req.at("allowed_pairs")) {
      if(pair.size()!=2) throw std::runtime_error("PRIOR_ACM_PAIR_INVALID");
      if(!dynamic.count(pair.at(0).get<std::string>())&&!dynamic.count(pair.at(1).get<std::string>()))pairs.push_back(sorted(pair));
    }
    equal("allowed_pairs",sorted(pairs));
    const double resolution=policy.at("edge_resolution_rad");
    if(!std::isfinite(resolution)||resolution<=0) throw std::runtime_error("PRIOR_RESOLUTION_INVALID");
    equal("interpolation",{{"edge_resolution_rad",resolution},{"joint_step_l1_rad",std::min(resolution,.01)},
      {"distance_norm","L1"},{"waypoint_semantics","joint_linear_between_nodes"}});
    equal("receiver_reserve_m",policy.value("receiver_reserve_m",0.));
    J attachment={{"mode","empty"}};
    if(!attached.is_null()) {
      m710::processTransform(attached.at("pose"));m710::processBox(attached);
      attachment={{"mode","loaded"},{"size",attached.at("size")},{"pose",attached.at("pose")},
        {"touch_links",sorted(attached.at("touch_links"))}};
    }
    equal("attachment",attachment);
    const auto& limits=context.at("joint_limits_rad");
    if(limits.size()!=names.size())throw std::runtime_error("PRIOR_JOINT_LIMITS_INVALID");
    for(size_t i=0;i<names.size();++i) {
      const auto& bounds=model->getVariableBounds(names[i]);
      const double lo=limits.at(i).at(0),hi=limits.at(i).at(1);
      if(!std::isfinite(lo)||!std::isfinite(hi)||lo>=hi ||
        (bounds.position_bounded_ && (lo<bounds.min_position_-1e-9 || hi>bounds.max_position_+1e-9)))
        throw std::runtime_error("PRIOR_JOINT_LIMITS_EXCEED_MODEL");
    }
    const std::string placement=context.at("placement_policy_sha256");
    if(placement.empty()||(!prior_placement_policy_sha256.empty()&&placement!=prior_placement_policy_sha256))
      throw std::runtime_error("PRIOR_PLACEMENT_POLICY_MISMATCH");
  }
  static bool samePose(const Eigen::Isometry3d& a,const Eigen::Isometry3d& b) {return (a.matrix()-b.matrix()).cwiseAbs().maxCoeff()<=1e-7;}
  // Between adjacent motions only the selected target may change ownership.
  // Its actual pose must be identical on both sides of attach/release.
  void checkTransition(const planning_scene::PlanningSceneConstPtr& before,const planning_scene::PlanningSceneConstPtr& after,const J& req,
      const std::string& location="mtc_compute") {
    const std::string target=req.at("clearance_policy").at("target_id");
    auto ids=before->getWorld()->getObjectIds(),next=after->getWorld()->getObjectIds();
    std::set<std::string> a(ids.begin(),ids.end()),b(next.begin(),next.end());a.erase(target);b.erase(target);
    if(a!=b) throw std::runtime_error("NATIVE_TASK_WORLD_IDENTITY_CHANGED");
    for(const auto& id:a) {
      const auto x=before->getWorld()->getObject(id),y=after->getWorld()->getObject(id);
      if(x->shapes_.size()!=y->shapes_.size() || x->global_shape_poses_.size()!=x->shapes_.size() ||
         y->global_shape_poses_.size()!=y->shapes_.size()) throw std::runtime_error("NATIVE_TASK_WORLD_GEOMETRY_CHANGED");
      for(size_t i=0;i<x->shapes_.size();++i) {
        if(x->shapes_[i]->type!=y->shapes_[i]->type)throw std::runtime_error("NATIVE_TASK_WORLD_GEOMETRY_CHANGED");
        if(x->shapes_[i]->type==shapes::BOX) {
          const auto* sx=static_cast<const shapes::Box*>(x->shapes_[i].get());const auto* sy=static_cast<const shapes::Box*>(y->shapes_[i].get());
          for(int k=0;k<3;++k) if(sx->size[k]!=sy->size[k]) throw std::runtime_error("NATIVE_TASK_WORLD_GEOMETRY_CHANGED");
        } else if(x->shapes_[i]->type==shapes::MESH) {
          const auto* sx=static_cast<const shapes::Mesh*>(x->shapes_[i].get());const auto* sy=static_cast<const shapes::Mesh*>(y->shapes_[i].get());
          if(sx->vertex_count!=sy->vertex_count || sx->triangle_count!=sy->triangle_count ||
             !std::equal(sx->vertices,sx->vertices+3*sx->vertex_count,sy->vertices) ||
             !std::equal(sx->triangles,sx->triangles+3*sx->triangle_count,sy->triangles))
            throw std::runtime_error("NATIVE_TASK_WORLD_GEOMETRY_CHANGED");
        } else throw std::runtime_error("NATIVE_TASK_WORLD_GEOMETRY_UNSUPPORTED");
        if(!samePose(m710::worldShapePose(*x,i),m710::worldShapePose(*y,i))) throw std::runtime_error("NATIVE_TASK_WORLD_POSE_CHANGED");
      }
    }
    auto targetPose=[&](const planning_scene::PlanningSceneConstPtr& s) {
      const auto* attached=s->getCurrentState().getAttachedBody(target);const auto world=s->getWorld()->getObject(target);
      if(bool(attached)==bool(world)) throw std::runtime_error("NATIVE_TASK_TARGET_OWNERSHIP_INVALID");
      return attached?attached->getGlobalCollisionBodyTransforms().at(0):m710::worldShapePose(*world,0);
    };
    const auto before_pose=targetPose(before),after_pose=targetPose(after);
    if(!samePose(before_pose,after_pose)) {
      auto describe=[&](const planning_scene::PlanningSceneConstPtr& scene,const Eigen::Isometry3d& cached) {
        auto fresh=scene->getCurrentState();fresh.update();fresh.updateCollisionBodyTransforms();
        std::vector<double> q;fresh.copyJointGroupPositions("manipulator",q);
        const auto* body=fresh.getAttachedBody(target);
        J detail={{"q",q},{"in_world",scene->getWorld()->hasObject(target)},{"attached",bool(body)},
          {"cached_world_pose",serial(cached)},{"flange_world_pose",serial(fresh.getGlobalLinkTransform("flange"))}};
        if(body) {detail["updated_world_pose"]=serial(body->getGlobalCollisionBodyTransforms().at(0));
          detail["shape_pose_in_link"]=serial(body->getShapePosesInLinkFrame().at(0));}
        return detail;
      };
      std::cerr<<J({{"diagnostic","NATIVE_TASK_ATTACHMENT_TELEPORT"},{"location",location},{"task_id",req.value("task_id",std::string())},
        {"stage_id",req.value("stage_id",std::string())},{"parent_stage_id",req.value("parent_stage_id",std::string())},{"target_id",target},
        {"maximum_matrix_difference",(before_pose.matrix()-after_pose.matrix()).cwiseAbs().maxCoeff()},
        {"before",describe(before,before_pose)},{"after",describe(after,after_pose)}}).dump()<<std::endl;
      throw std::runtime_error("NATIVE_TASK_ATTACHMENT_TELEPORT");
    }
    auto targetSize=[&](const planning_scene::PlanningSceneConstPtr& s) {
      const auto* attached=s->getCurrentState().getAttachedBody(target);const auto world=s->getWorld()->getObject(target);
      const auto& shapes=attached?attached->getShapes():world->shapes_;
      if(shapes.size()!=1 || shapes[0]->type!=shapes::BOX) throw std::runtime_error("NATIVE_TASK_TARGET_SHAPE_INVALID");
      const auto* box=static_cast<const shapes::Box*>(shapes[0].get());return std::vector<double>{box->size[0],box->size[1],box->size[2]};
    };
    if(targetSize(before)!=targetSize(after)) throw std::runtime_error("NATIVE_TASK_TARGET_GEOMETRY_CHANGED");
  }
  J nativeTaskPlan(const J& req,const planning_scene::PlanningScenePtr& scene,
      const std::shared_ptr<m710::Clearance>& clearance,const std::shared_ptr<m710::ProcessPolicy>& process,bool diagnostic=false) {
    if(req.contains("path") || req.contains("stages")) throw std::runtime_error("NATIVE_COLD_EXTERNAL_PATH_FORBIDDEN");
    if(m710::coupledBinding(receiver_binding))m710::validateReceiveHeight(req,receiver_binding);
    if(req.value("pipeline_id",std::string())=="external_axis") {
      if(m710::coupledBinding(receiver_binding))m710::coupledTransitionWorld(req,m710::activeCoupledBinding(req,receiver_binding));
      else m710::receiverTransitionWorld(req,receiver_binding);
    }
    else if(req.value("pipeline_id",std::string())=="semantic_event" && m710::coupledBinding(receiver_binding)) {
      if(req.value("planner_id","")!="NOMINAL_DROP_RELEASE" || req.at("stage")!="extraction" ||
          req.at("q_start")!=req.at("q_goal") || req.at("attachment").is_null() || req.value("parent_stage_id","").empty())
        throw std::runtime_error("NOMINAL_RELEASE_SCOPE_INVALID");
    }
    else {
      if(single_target_recovery_enabled && !diagnostic && req.at("stage")=="pregrasp" &&
          req.at("pipeline_id")=="pilz_industrial_motion_planner" && !req.value("empty_approach_direct",false))
        throw std::runtime_error("EMPTY_APPROACH_DIRECT_SCOPE_MARKER_REQUIRED");
      m710::validateNativeMotionScope(req);
    }
    const std::string connection_scope=req.value("connection_scope",std::string());
    if(!connection_scope.empty()) {
      if(!planning_only || planning_mode!="static_prior_fast" || req.at("stage")!="pregrasp" ||
          !req.at("attachment").is_null() || req.value("purpose",std::string())!="FREE_APPROACH" ||
          req.contains("goal_pose") || !req.contains("q_goal") ||
          (connection_scope!="DIRECT_ONLY" && connection_scope!="GLOBAL_ALLOWED"))
        throw std::runtime_error("APPROACH_CONNECTION_SCOPE_INVALID");
      if(connection_scope=="DIRECT_ONLY" && !(
          (req.at("pipeline_id")=="static_prior" && req.at("planner_id")=="CHECKED_JOINT_DIRECT") ||
          (req.at("pipeline_id")=="pilz_industrial_motion_planner" && req.at("planner_id")=="PTP")))
        throw std::runtime_error("DIRECT_ONLY_GLOBAL_SEARCH_FORBIDDEN");
    }
    const std::string task_id=req.at("task_id"),stage_id=req.at("stage_id");
    if(diagnostic) {
      const std::string stage=req.at("stage");
      if(!planning_only || task_id.rfind("diagnostic-",0)!=0 || !req.contains("q_goal") || req.contains("goal_pose") ||
        !(stage=="pregrasp"||stage=="transit"||stage=="residence"))throw std::runtime_error("DIAGNOSTIC_CONNECTION_SCOPE_REQUIRED");
    } else if(task_id.rfind("diagnostic-",0)==0)throw std::runtime_error("DIAGNOSTIC_TASK_NOT_FORMAL");

    if(!req.contains("parent_stage_id") || !req.at("parent_stage_id").is_string())
      throw std::runtime_error("NATIVE_TASK_EXPLICIT_PARENT_REQUIRED");
    const std::string parent=req.at("parent_stage_id");
    if(task_id.empty() || stage_id.empty()) throw std::runtime_error("NATIVE_TASK_ID_REQUIRED");
    if(!diagnostic && parent.empty() && !req.at("attachment").is_null()) throw std::runtime_error("NATIVE_COLD_INITIAL_ATTACHMENT_FORBIDDEN");
    if(!tasks.count(task_id)) {
      if(!parent.empty()) throw std::runtime_error("NATIVE_TASK_PARENT_MISSING");
      if(tasks.size()>=8) throw std::runtime_error("NATIVE_TASK_SESSION_CAPACITY");
      auto session=std::make_unique<NativeTaskSession>();session->task=std::make_unique<mtc::Task>("",false);
      session->task->setRobotModel(model);session->task->setName(task_id);session->initial_q=req.at("q_start");session->initial_world=req.at("world");
      session->target_id=req.at("clearance_policy").at("target_id");session->diagnostic=diagnostic;
      auto initial=std::make_unique<mtc::stages::FixedState>("frozen_actual_initial_state");initial->setState(scene);session->task->add(std::move(initial));
      tasks[task_id]=std::move(session);
    }
    auto& session=*tasks.at(task_id);
    if(req.contains("receiver_template") && ((req.at("receiver_template")!="RIGHT_INNER_HMAX" &&
        !(req.at("receiver_template")=="COUPLED_PLANAR" && m710::coupledBinding(receiver_binding))) ||
        parent.empty() || receiver_binding.is_null()))throw std::runtime_error("NATIVE_TASK_RECEIVER_TEMPLATE_SCOPE");
    if(session.diagnostic!=diagnostic)throw std::runtime_error("DIAGNOSTIC_TASK_SCOPE_CHANGED");
    if(req.at("clearance_policy").at("target_id")!=session.target_id) throw std::runtime_error("NATIVE_TASK_TARGET_ID_CHANGED");
    if(session.records.count(stage_id)) throw std::runtime_error("NATIVE_STAGE_ID_REUSED");
    if(session.records.size()>=4096) throw std::runtime_error("NATIVE_TASK_STAGE_CAPACITY");
    std::vector<std::string> ancestors;std::string cursor=parent;std::set<std::string> seen;
    while(!cursor.empty()) {
      if(!seen.insert(cursor).second || !session.records.count(cursor) || !session.records.at(cursor)->ready) throw std::runtime_error("NATIVE_TASK_PARENT_INVALID");
      ancestors.push_back(cursor);cursor=session.records.at(cursor)->parent;
    }
    std::reverse(ancestors.begin(),ancestors.end());
    if(ancestors.empty()) {
      if(req.at("q_start")!=session.initial_q || req.at("world")!=session.initial_world) throw std::runtime_error("NATIVE_TASK_INITIAL_STATE_CHANGED");
    } else {
      const auto& previous=*session.records.at(parent);checkTransition(previous.end,scene,req,"stage_registration");
      if(req.value("receiver_template","")=="RIGHT_INNER_HMAX" || req.value("receiver_template","")=="COUPLED_PLANAR") {
        const auto leg=req.at("process_substage");
        if(receiver_binding.is_null() || (leg=="RIGHT_INNER_Y" && (previous.request.at("stage")!="contact" || req.at("ownership_transition")!="ATTACH")) ||
            (leg=="RIGHT_INNER_X" && (previous.request.value("process_substage","")!="RIGHT_INNER_Y" || !req.at("ownership_transition").is_null())))
          throw std::runtime_error("NATIVE_TASK_SIDE_SUBSTAGE_PARENT_INVALID");
      }
      if(previous.process && req.contains("process_policy") && !req.at("process_policy").at("initial_proximity").is_null()) {
        const auto terminal=previous.process->terminalProximity();const auto& next=req.at("process_policy").at("initial_proximity");
        if(next.contains("controlled_side_transfer") && previous.request.at("stage")=="extraction" &&
            (terminal.is_null() || terminal!=next))throw std::runtime_error("NATIVE_TASK_SIDE_HISTORY_CHANGED");
        if(!terminal.is_null() && terminal.value("fully_released",false) && !next.value("fully_released",false))
          throw std::runtime_error("NATIVE_TASK_PROXIMITY_HISTORY_RESET");
        if(!terminal.is_null() && terminal.contains("pairs") && next.contains("pairs")) {
          std::map<std::string,J> by_name;for(const auto& pair:next.at("pairs")) by_name[pair.at("obstacle").get<std::string>()]=pair;
          for(const auto& pair:terminal.at("pairs")) {
            const std::string name=pair.at("obstacle");
            if(!by_name.count(name) || std::abs(pair.at("last_signed_distance_m").get<double>()-by_name.at(name).at("last_signed_distance_m").get<double>())>1e-7 ||
               (pair.at("released").get<bool>()&&!by_name.at(name).at("released").get<bool>())) throw std::runtime_error("NATIVE_TASK_PROXIMITY_HISTORY_CHANGED");
          }
        }
      }
    }
    if(req.contains("direct_rejection_stage_id")) {
      const std::string rejected=req.at("direct_rejection_stage_id");
      if(connection_scope!="GLOBAL_ALLOWED" || req.at("pipeline_id")!="static_prior" ||
          req.at("planner_id")!="SPARSE_PRM" || !session.records.count(rejected))
        throw std::runtime_error("DIRECT_REJECTION_RECEIPT_INVALID");
      const auto& prior=*session.records.at(rejected);
      if(prior.ready || prior.request.value("planner_id",std::string())!="CHECKED_JOINT_DIRECT" ||
          prior.result.value("status",std::string())!="DIRECT_CONNECTION_REJECTED" ||
          m710::StaticPriorGraph::directContext(prior.request)!=m710::StaticPriorGraph::directContext(req))
        throw std::runtime_error("DIRECT_REJECTION_CONTEXT_CHANGED");
    }
    size_t common=0;while(common<ancestors.size()&&common<session.active.size()&&ancestors[common]==session.active[common]) ++common;
    session.task->reset();
    if(common<session.active.size()) ++session.backtracks;
    while(session.active.size()>common) {session.task->stages()->remove(-1);session.active.pop_back();}
    auto generate=[this](NativeStageRecord& r) {
      const auto& req=r.request;const std::string pipeline=req.at("pipeline_id"),planner=req.at("planner_id");
      if(pipeline=="semantic_event" && planner=="NOMINAL_DROP_RELEASE") {
        m710::validateNominalDrop(req,receiver_binding);
        const auto began=Clock::now();const auto& samples=req.at("nominal_release").at("samples");
        const std::string target=req.at("process_policy").at("target_id");
        const auto* held=r.start->getCurrentState().getAttachedBody(target);
        if(!held || !samePose(held->getGlobalCollisionBodyTransforms().at(0),m710::processBox(samples.front().at("box")).pose))
          throw std::runtime_error("RELEASE_ACTUAL_ATTACHMENT_MISMATCH");
        r.result={{"status","NOMINAL_DROP_REJECTED"},{"task_id",req.at("task_id")},{"stage_id",req.at("stage_id")},
          {"parent_stage_id",r.parent},{"request_id",req.at("request_id")},{"generation_source","SEMANTIC_EVENT"},
          {"pipeline_id",pipeline},{"planner_id",planner},{"native_solver_calls",J::object()},
          {"mtc_generation",true},{"generated_during_task",true}};
        auto next=r.start->diff();next->decoupleParent();
        next->getCurrentStateNonConst().clearAttachedBody(target);next->getCurrentStateNonConst().update();
        std::map<std::string,double> last_gap;std::set<std::string> initial_contact,restored;
        const auto cups=req.at("clearance_policy").at("compliant_tool_links").get<std::set<std::string>>();
        J checks=J::array(),failure=nullptr;
        for(size_t index=0;index<samples.size();++index) {
          const auto& sample=samples[index];const auto box=m710::processBox(sample.at("box"));
          if(seconds(began)>=req.at("allowed_planning_time_s").get<double>()) {failure={{"reason","NOMINAL_DROP_CHECK_TIMEOUT"}};break;}
          if(!next->processCollisionObjectMsg(object(sample.at("box"))))throw std::runtime_error("RELEASE_WORLD_IMPORT_FAILED");
          if(next->getCurrentState().hasAttachedBody(target) || !next->getWorld()->hasObject(target))throw std::runtime_error("RELEASE_OWNERSHIP_INVALID");
          auto& acm=next->getAllowedCollisionMatrixNonConst();
          for(const auto& name:cups) {
            const auto* link=model->getLinkModel(name);if(!link || link->getShapes().empty())throw std::runtime_error("RELEASE_CUP_MISSING");
            double gap=1e9;
            for(size_t k=0;k<link->getShapes().size();++k) {
              if(link->getShapes()[k]->type!=shapes::BOX)throw std::runtime_error("RELEASE_CUP_SHAPE_UNKNOWN");
              const auto* shape=static_cast<const shapes::Box*>(link->getShapes()[k].get());
              m710::ProcessBox cup;cup.id=name;cup.pose=next->getCurrentState().getCollisionBodyTransform(link,k);
              cup.half=Eigen::Vector3d(shape->size[0],shape->size[1],shape->size[2])/2.;gap=std::min(gap,m710::processSignedGap(cup,box));
            }
            if(index==0 && gap<.005)initial_contact.insert(name);
            if(gap>=.005)restored.insert(name);
            const bool permitted=initial_contact.count(name) && !restored.count(name);
            if((index>0 && permitted && gap<last_gap[name]-1e-7) || gap < -req.at("process_policy").at("collision_policy").at("maximum_compliant_cup_additional_compression_m").get<double>()) {
              failure={{"reason","RELEASE_CUP_COMPRESSION_OR_REENTRY"},{"pair",{name,target}},{"signed_gap_m",gap}};break;
            }
            last_gap[name]=gap;acm.setEntry(name,target,permitted);
          }
          if(!failure.is_null())break;
          m710::Clearance gate(next,req.at("clearance_policy"),"optimized",true,true,false);
          if(!gate.check(next->getCurrentState()))failure=gate.last_failure;
          if(failure.is_null())failure=m710::nominalDropWorldFailure(sample.at("box"),req.at("world"));
          checks.push_back({{"t",sample.at("t")},{"passed",failure.is_null()},{"failure",failure},{"clearance",gate.evidence()}});
          if(!failure.is_null())break;
        }
        r.result["nominal_release"]={{"checks",checks},{"same_pose_detachment",true},{"target_in_world_once",true},
          {"first_contact",failure.is_null()},{"tool_q_constant",true},{"initial_contact_cups",initial_contact},
          {"restored_clearance_cups",restored},{"physical_execution","NOT_RUN"},{"continuous_swept_proof",false}};
        r.result["failure"]=failure;if(!failure.is_null())return;
        r.end=next;r.trajectory=std::make_shared<robot_trajectory::RobotTrajectory>(model,"manipulator");
        r.trajectory->addSuffixWayPoint(r.start->getCurrentState(),0.);
        r.result.update({{"status","SUCCESS"},{"terminal_q",req.at("q_start")},{"points",J::array()},
          {"joint_names",names},{"native_output_status","SKIPPED_PLANNING_ONLY"},{"planning_only_status","PLANNING_ONLY_NOT_EXECUTABLE"},
          {"time_parameterization","NOMINAL_GRAVITY_MODEL_NOT_ROBOT_MOTION"}});r.ready=true;return;
      }
      if(pipeline=="external_axis" && m710::coupledBinding(receiver_binding)) {
        const auto& transition_binding=m710::activeCoupledBinding(req,receiver_binding);
        const auto began=Clock::now();const auto end_world=m710::coupledTransitionWorld(req,transition_binding);
        r.result={{"status","RECEIVER_SWEEP_REJECTED"},{"task_id",req.at("task_id")},{"stage_id",req.at("stage_id")},
          {"parent_stage_id",r.parent},{"request_id",req.at("request_id")},{"generation_source","NATIVE_EXTERNAL_AXIS"},
          {"pipeline_id",pipeline},{"planner_id",planner},{"native_solver_calls",J::object()},
          {"mtc_generation",true},{"generated_during_task",true}};
        J checks=J::array();J failure=nullptr;planning_scene::PlanningScenePtr next;
        for(auto sample:transition_binding.at("samples")) {
          if(!req.at("attachment").is_null()) {
            J filtered=J::array();for(const auto& box:sample.at("world"))if(box.at("id")!=transition_binding.at("target_id"))filtered.push_back(box);
            sample["world"]=filtered;
          }
          if(seconds(began)>=req.at("allowed_planning_time_s").get<double>()) {r.result["status"]="RECEIVER_SWEEP_TIMEOUT";break;}
          next=r.start->diff();next->decoupleParent();
          for(const auto& box:sample.at("world"))if(!next->processCollisionObjectMsg(object(box)))throw std::runtime_error("COUPLED_IMPORT_FAILED");
          m710::Clearance gate(next,req.at("clearance_policy"),"optimized",true,true,false);
          const bool valid=gate.check(next->getCurrentState());
          failure=valid?m710::coupledWorldFailure(sample,transition_binding):gate.last_failure;
          checks.push_back({{"height_m",sample.at("height_m")},{"passed",failure.is_null()},{"failure",failure},{"clearance",gate.evidence()}});
          if(!failure.is_null())break;
        }
        r.result["external_axis"]={{"type","COUPLED_CONVEYOR_DISCRETE_HEIGHT_TRANSITION"},{"robot_q_constant",true},
          {"robot_q",req.at("q_start")},{"from_height_m",transition_binding.at("samples").front().at("height_m")},
          {"to_height_m",transition_binding.at("samples").back().at("height_m")},{"checks",checks},
          {"maximum_height_step_m",transition_binding.at("maximum_height_step_m")},{"continuous_swept_proof",false},
          {"after_scene_fingerprint",req.at("receiver_end_fingerprint")},{"execution_duration_s",nullptr},{"physical_execution","NOT_RUN"}};
        r.result["failure"]=failure;
        if(!failure.is_null() || r.result["status"]=="RECEIVER_SWEEP_TIMEOUT")return;
        r.end=next;r.trajectory=std::make_shared<robot_trajectory::RobotTrajectory>(model,"manipulator");
        r.trajectory->addSuffixWayPoint(r.start->getCurrentState(),0.);
        r.result.update({{"status","SUCCESS"},{"terminal_q",req.at("q_start")},{"points",J::array({{{"q",req.at("q_start")},{"t",0.}}})},
          {"joint_names",names},{"native_output_status","SKIPPED_PLANNING_ONLY"},{"planning_only_status","PLANNING_ONLY_NOT_EXECUTABLE"},
          {"time_parameterization","NOT_AVAILABLE_EXTERNAL_AXIS_HARDWARE_PARAMETERS"}});r.ready=true;return;
      }
      if(pipeline=="external_axis") {
        const auto began=Clock::now();
        const auto end_world=m710::receiverTransitionWorld(req,receiver_binding);
        const auto swept=m710::receiverSweep(receiver_binding.at("low"),receiver_binding.at("high"));
        r.result={{"status","RECEIVER_SWEEP_REJECTED"},{"task_id",req.at("task_id")},
          {"stage_id",req.at("stage_id")},{"parent_stage_id",r.parent},{"request_id",req.at("request_id")},
          {"generation_source","NATIVE_EXTERNAL_AXIS"},{"pipeline_id",pipeline},{"planner_id",planner},
          {"native_solver_calls",J::object()},{"mtc_generation",true},{"generated_during_task",true}};
        auto swept_scene=r.start->diff();swept_scene->decoupleParent();
        if(!swept_scene->processCollisionObjectMsg(object(swept)))throw std::runtime_error("RECEIVER_SWEEP_IMPORT_FAILED");
        m710::Clearance sweep_clearance(swept_scene,req.at("clearance_policy"),req.value("clearance_mode",std::string("optimized")),true,true,false);
        const bool valid=sweep_clearance.check(swept_scene->getCurrentState());
        J failure=valid?J(nullptr):sweep_clearance.last_failure;size_t world_queries=0;J designed_contacts=J::array();
        // Robot/tool clearance uses the actual model. World boxes use the exact
        // union of all belt positions, not endpoint sampling or a broadphase verdict.
        if(valid) for(const auto& box:req.at("world")) {
          if(seconds(began)>=req.at("allowed_planning_time_s").get<double>()) {
            r.result["status"]="RECEIVER_SWEEP_TIMEOUT";break;
          }
          if(box.at("id")=="conveyor_transverse")continue;
          const double gap=m710::receiverBoxDistance(swept,box);++world_queries;
          if((gap<=0. || gap+1e-9<.005) && m710::receiverDesignedPlaneContact(receiver_binding.at("low"),box,receiver_binding)) {
            const double end_gap=m710::receiverBoxDistance(receiver_binding.at("high"),box);++world_queries;
            if(end_gap+1e-9>=.005) {
              designed_contacts.push_back({{"pair",{"conveyor_transverse",box.at("id")}},
                {"rule","EXISTING_DESIGNED_PLANE_CONTACT_MONOTONE_Z_SEPARATION"},
                {"nonpenetration_proof","UNCHANGED_VERTICAL_SEPARATING_PLANE"},{"final_gap_m",end_gap},
                {"normal_final_clearance_restored",true}});
              continue;
            }
          }
          if(gap<=0. || gap+1e-9<.005) {failure={{"reason","RECEIVER_WORLD_CLEARANCE"},
            {"pair",{"conveyor_transverse",box.at("id")}},{"surface_distance_m",gap},{"required_pair_clearance_m",.005}};break;}
        }
        r.result["external_axis"]={{"type","TRANSVERSE_BELT_Z_LIFT"},{"robot_q_constant",true},
          {"robot_q",req.at("q_start")},{"from",receiver_binding.at("low")},{"to",receiver_binding.at("high")},
          {"swept_volume",swept},{"check_method","EXACT_HORIZONTAL_BOX_Z_UNION_NATIVE_FCL"},
          {"sweep_clearance",sweep_clearance.evidence()},{"world_fcl_queries",world_queries},
          {"designed_contact_transitions",designed_contacts},
          {"geometry_check_s",seconds(began)},{"before_scene_fingerprint",req.at("scene_fingerprint")},
          {"after_scene_fingerprint",req.at("receiver_end_fingerprint")},{"mechanism_geometry","NOT_MODELED"},
          {"mechanical_travel","UNKNOWN"},{"execution_duration_s",nullptr},{"physical_execution","NOT_RUN"}};
        r.result["failure"]=failure;
        if(!failure.is_null() || r.result["status"]=="RECEIVER_SWEEP_TIMEOUT")return;
        if(seconds(began)>=req.at("allowed_planning_time_s").get<double>()) {r.result["status"]="RECEIVER_SWEEP_TIMEOUT";return;}
        r.end=r.start->diff();r.end->decoupleParent();
        if(!r.end->processCollisionObjectMsg(object(receiver_binding.at("high"))))throw std::runtime_error("RECEIVER_END_IMPORT_FAILED");
        r.trajectory=std::make_shared<robot_trajectory::RobotTrajectory>(model,"manipulator");
        r.trajectory->addSuffixWayPoint(r.start->getCurrentState(),0.);
        r.result.update({{"status","SUCCESS"},{"terminal_q",req.at("q_start")},
          {"points",J::array({{{"q",req.at("q_start")},{"t",0.}}})},{"joint_names",names},
          {"native_output_status","SKIPPED_PLANNING_ONLY"},{"planning_only_status","PLANNING_ONLY_NOT_EXECUTABLE"},
          {"time_parameterization","NOT_AVAILABLE_EXTERNAL_AXIS_HARDWARE_PARAMETERS"}});
        r.ready=true;return;
      }
      if(pipeline=="static_prior") {
        const auto begin=Clock::now();const std::string stage=req.at("stage");
        const bool direct_only=planner=="CHECKED_JOINT_DIRECT";
        if(direct_only && req.value("connection_scope",std::string())!="DIRECT_ONLY")
          throw std::runtime_error("DIRECT_ONLY_SCOPE_REQUIRED");
        if(!planning_only || planning_mode!="static_prior_fast" || (!direct_only && planner!="SPARSE_PRM") ||
          !req.contains("q_goal") || req.contains("goal_pose") ||
          !(stage=="pregrasp" || stage=="transit" || stage=="residence"))
          throw std::runtime_error("PRIOR_FREE_MOTION_SCOPE_REQUIRED");
        checkPriorContext(req);
        const std::string mode=req.at("attachment").is_null()?"empty":"loaded";
        r.result={{"status","PRIOR_NOT_COVERED"},{"pipeline_id",pipeline},{"planner_id",planner},
          {"generation_source",direct_only?"NATIVE_DIRECT_CHECK":"STATIC_PRIOR_QUERY"},{"mtc_generation",true},{"generated_during_task",true},
          {"task_id",req.at("task_id")},{"stage_id",req.at("stage_id")},{"parent_stage_id",r.parent},
          {"request_id",req.at("request_id")},{"native_solver_calls",J::object()},{"native_solver_s",0.},
          {"mtc_plan_s",0.},{"pipeline_calls",calls},{"returned_waypoint_count",0},{"trajectory_present",false}};
        if(static_prior_database.is_null() || !static_prior_database.at("modes").contains(mode)) return;
        auto result=m710::StaticPriorGraph::query(static_prior_database.at("modes").at(mode),req,r.start,
          *r.clearance,r.process.get(),direct_only,req.contains("direct_rejection_stage_id"));
        r.result["status"]=result.at("status");r.result["prior_query_s"]=seconds(begin);
        if(result.contains("termination"))r.result["termination"]=result.at("termination");
        if(result.contains("prior_usage")) {r.result["prior_usage"]=result.at("prior_usage");r.result["prior_usage"]["context_bound_by_worker"]=true;}
        if(result.at("status")!="SUCCESS") {if(result.contains("failure"))r.result["failure"]=result.at("failure");return;}
        r.result["generation_source"]=result.at("prior_usage").at("prior_hit").get<bool>()?
          "STATIC_PRIOR_REUSE":"NATIVE_DIRECT_CONNECTION";
        const double velocity=req.at("velocity_scale"),acceleration=req.at("acceleration_scale");
        if(!std::isfinite(velocity)||!std::isfinite(acceleration)||velocity<=0||velocity>1||acceleration<=0||acceleration>1)
          throw std::runtime_error("PRIOR_TIME_SCALE_INVALID");
        r.result["processing_branch"]="PRIOR_TIME_PARAMETERIZATION";
        auto trajectory=std::make_shared<robot_trajectory::RobotTrajectory>(model,"manipulator");
        auto state=r.start->getCurrentState();
        for(const auto& point:result.at("path")) {
          state.setJointGroupPositions("manipulator",point.get<std::vector<double>>());state.update();
          trajectory->addSuffixWayPoint(state,0.);
        }
        if(trajectory->getWayPointCount()<2) {r.result["status"]="PRIOR_EMPTY_MOTION";return;}
        trajectory_processing::IterativeParabolicTimeParameterization iptp;
        if(!iptp.computeTimeStamps(*trajectory,velocity,acceleration)) {r.result["status"]="PRIOR_TIME_PARAMETERIZATION_FAILED";return;}
        moveit_msgs::msg::RobotTrajectory msg;trajectory->getRobotTrajectoryMsg(msg);
        if(msg.joint_trajectory.joint_names!=names)throw std::runtime_error("OUTPUT_JOINT_ORDER_MISMATCH");
        J points=J::array();for(const auto& point:msg.joint_trajectory.points)
          points.push_back({{"q",point.positions},{"v",point.velocities},{"a",point.accelerations},
            {"t",point.time_from_start.sec+point.time_from_start.nanosec*1e-9}});
        r.trajectory=trajectory;r.end=r.start->diff();r.end->decoupleParent();r.end->setCurrentState(trajectory->getLastWayPoint());
        r.result["points"]=points;r.result["joint_names"]=names;r.result["returned_waypoint_count"]=trajectory->getWayPointCount();
        r.result["trajectory_present"]=true;r.result["native_output_status"]="SKIPPED_PLANNING_ONLY";
        r.result["planning_only_status"]="PLANNING_ONLY_NOT_EXECUTABLE";r.result["native_output_check_s"]=nullptr;
        r.result["time_parameterization"]="IPTP_preserves_waypoints";r.result["clearance"]=r.clearance->evidence();
        r.result["process_policy"]=r.process?r.process->evidence():J(nullptr);
        r.result["process_semantics_checked"]=false;r.result["planner_internal_process_checks"]=bool(r.process);
        r.result["task_tcp_identity"]=identity.at("task_tcp_fingerprint");r.result["interpolated_link"]=nullptr;
        r.result["processing_branch"]="ACCEPTED_CURRENT_CONTEXT_PRIOR";r.result["prior_query_s"]=seconds(begin);
        r.ready=true;return;
      }
      if(!pipelines.count(pipeline)||!((pipeline=="ompl"&&planner=="RRTConnectkConfigDefault") ||
          (pipeline=="pilz_industrial_motion_planner"&&(planner=="PTP"||planner=="LIN")))) throw std::runtime_error("PLANNER_UNAVAILABLE");
      const std::string stage=req.at("stage");
      if(pipeline=="ompl" && (req.contains("goal_pose") || !(stage=="pregrasp" || stage=="transit" || stage=="residence")))
        throw std::runtime_error("CONSTRAINED_PROCESS_OMPL_FORBIDDEN");
      const auto event_begin=Clock::now();
      const std::string target_id=req.at("clearance_policy").at("target_id");
      const auto& current=r.start->getCurrentState();
      if(m710::semanticPlaceScope(planning_only,planning_mode,req,
          current.hasAttachedBody(target_id),r.start->getWorld()->hasObject(target_id))) {
        if(req.at("flange_from_task_tcp")!=identity.at("flange_from_task_tcp"))
          throw std::runtime_error("TASK_TCP_CONTEXT_MISMATCH");
        const std::string tcp=identity.at("task_tcp_link");
        if(!model->getLinkModel(tcp)) throw std::runtime_error("TASK_TCP_UNAVAILABLE");
        if(m710::placeGoalSatisfied(r.start,tcp,pose(req.at("goal_pose")))) {
          // The common plan entry checked this exact start's bounds, clearance
          // and ordinary collision. Complete the same endpoint process gate;
          // preserve attachment until the subsequent withdrawal transition.
          if(!r.process || !r.process->check(current,true)) {
            r.result={{"status","NATIVE_SEMANTIC_PROCESS_REJECTED"},
              {"failure",r.process?r.process->last_failure:J("PROCESS_POLICY_REQUIRED")}};
            return;
          }
          std::vector<double> terminal;current.copyJointGroupPositions("manipulator",terminal);
          r.end=r.start->diff();r.end->decoupleParent();r.end->setCurrentState(current);
          r.result={{"status","SUCCESS"},{"pipeline_id","semantic_event"},{"planner_id","NONE"},
            {"generation_source","SEMANTIC_EVENT"},{"mtc_plan_s",0.},{"native_solver_s",0.},
            {"event_check_s",seconds(event_begin)},{"mtc_generation",true},{"generated_during_task",true},
            {"task_id",req.at("task_id")},{"stage_id",req.at("stage_id")},{"parent_stage_id",r.parent},
            {"request_id",req.at("request_id")},{"native_solver_calls",J::object()},{"pipeline_calls",calls},
            {"points",J::array()},{"terminal_q",terminal},{"joint_names",names},
            {"returned_waypoint_count",0},{"trajectory_present",false},
            {"solver_returned_success",nullptr},{"moveit_error_code",nullptr},
            {"processing_branch","SEMANTIC_PLACE_AT_GOAL"},{"goal_constraints_satisfied",true},
            {"native_output_status","SKIPPED_PLANNING_ONLY"},{"native_output_check_s",nullptr},
            {"planning_only_status","PLANNING_ONLY_NOT_EXECUTABLE"},{"process_semantics_checked",false},
            {"planner_internal_process_checks",true},{"time_parameterization","NOT_APPLICABLE_SEMANTIC_EVENT"},
            {"task_tcp_identity",identity.at("task_tcp_fingerprint")},{"interpolated_link",nullptr},
            {"clearance",r.clearance->evidence()},{"process_policy",r.process->evidence()},
            {"semantic_event",{{"event_type","PLACE_TARGET_REACHED"},{"task_id",req.at("task_id")},
              {"stage_id",req.at("stage_id")},{"parent_stage_id",r.parent},{"target_id",target_id},
              {"start_unchanged",true},{"goal_constraints_satisfied",true},{"release_pending",true}}}};
          r.ready=true;
          return;
        }
      }
      std::shared_ptr<m710::SearchTrace> trace;
      if(pipeline=="ompl" && pipelines.at(pipeline)->getPlannerPluginName()=="m710/RecordedOMPLPlanner") {
        trace=std::make_shared<m710::SearchTrace>();trace->input=req;
      }
      m710::active_search_trace=trace;
      auto solver=std::make_shared<CountedPlanner>(pipelines.at(pipeline),calls[pipeline+"/"+planner]);
      solver->setPlannerId(planner);solver->setProperty("goal_joint_tolerance",1e-12);solver->setProperty("goal_position_tolerance",m710::kNativeGoalPositionToleranceM);
      solver->setProperty("goal_orientation_tolerance",m710::kNativeGoalOrientationToleranceRad);solver->setProperty("max_velocity_scaling_factor",req.at("velocity_scale").get<double>());
      solver->setProperty("max_acceleration_scaling_factor",req.at("acceleration_scale").get<double>());
      solver->setTimeout(req.at("allowed_planning_time_s").get<double>());solver->init(model);
      const auto* group=model->getJointModelGroup("manipulator");robot_trajectory::RobotTrajectoryPtr trajectory;
      r.clearance->phase="search";const auto begin=Clock::now();
      mtc::solvers::PlannerInterface::Result result;
      if(req.contains("goal_pose")) {
        if(req.at("flange_from_task_tcp")!=identity.at("flange_from_task_tcp")) throw std::runtime_error("TASK_TCP_CONTEXT_MISMATCH");
        const auto* tcp=model->getLinkModel(identity.at("task_tcp_link").get<std::string>());
        if(!tcp) throw std::runtime_error("TASK_TCP_UNAVAILABLE");
        result=solver->plan(r.start,*tcp,Eigen::Isometry3d::Identity(),matrix(req.at("goal_pose")),group,req.at("allowed_planning_time_s").get<double>(),trajectory,moveit_msgs::msg::Constraints{});
      } else {
        auto goal=r.start->diff();auto state=goal->getCurrentState();state.setJointGroupPositions(group,req.at("q_goal").get<std::vector<double>>());state.update();goal->setCurrentState(state);
        result=solver->plan(r.start,goal,group,req.at("allowed_planning_time_s").get<double>(),trajectory,moveit_msgs::msg::Constraints{});
      }
      r.result={{"status","NATIVE_PLANNING_FAILED"},{"pipeline_id",pipeline},{"planner_id",planner},{"mtc_plan_s",seconds(begin)},
        {"mtc_generation",true},{"generated_during_task",true},{"task_id",req.at("task_id")},{"stage_id",req.at("stage_id")},
        {"parent_stage_id",r.parent},{"native_solver_calls",{{pipeline=="ompl"?"OMPL":planner,1}}},{"pipeline_calls",calls},{"request_id",req.at("request_id")}};
      if(trace) {
        r.result["search_trace"]={{"schema","m710_rrt_search_v1"},{"input",trace->input},{"planners",trace->planners},
          {"marker","PLANNING_REPLAY_NOT_PHYSICAL_EXECUTION"},{"qualification_status","NOT_EVALUATED"},
          {"continuous_swept_proof",false},{"physical_execution","NOT_RUN"}};
      }
      m710::active_search_trace.reset();
      r.result["solver_returned_success"]=result.success;
      r.result["solver_message"]=result.message;
      // MTC exposes the original error name on failure, but drops the numeric
      // response and the successful response message. Never invent that code.
      r.result["moveit_error_code"]=nullptr;
      r.result["moveit_error_code_source"]="MTC_result_message_only";
      if(!result.success) for(int code : {-1,-2,-3,-4,-5,-6,-7,-10,-11,-12,-13,-14,-15,-16,-17,-18,-19,-21,-22,-23,-24,-25,-26,-27,-28,-29,-30,-31,99999}) {
        if(result.message!=moveit::core::error_code_to_string(0) && result.message==moveit::core::error_code_to_string(code)) {
          r.result["moveit_error_code"]=code;
          r.result["moveit_error_code_source"]="recovered_from_original_MoveIt_error_name";
          break;
        }
      }
      r.result["returned_waypoint_count"]=trajectory?trajectory->getWayPointCount():0;
      r.result["trajectory_present"]=bool(trajectory);
      r.result["processing_branch"]=!result?"SOLVER_RETURNED_FAILURE":!trajectory?
          "NULL_TRAJECTORY":trajectory->getWayPointCount()<2?"INSUFFICIENT_WAYPOINTS":"TRAJECTORY_CONVERSION";
      if(req.contains("goal_pose")) {
        const auto start_pose=r.start->getCurrentState().getGlobalLinkTransform(identity.at("task_tcp_link").get<std::string>());
        const auto goal_pose=matrix(req.at("goal_pose"));
        r.result["goal_translation_delta_m"]=(start_pose.translation()-goal_pose.translation()).norm();
        r.result["goal_rotation_delta_rad"]=Eigen::AngleAxisd(start_pose.linear().transpose()*goal_pose.linear()).angle();
      }
      if(!result || !trajectory || trajectory->getWayPointCount()==0) return;
      const bool singleton=trajectory->getWayPointCount()==1;
      // Only this experimental place event accepts one native point. The Task
      // still creates its own stage and uses the real predecessor and scene.
      if(singleton && !(planning_only && stage=="place" && pipeline=="pilz_industrial_motion_planner" &&
          planner=="LIN" && req.contains("goal_pose") && !req.at("attachment").is_null())) return;
      try {
      if(pipeline=="ompl") {r.result["processing_branch"]="TIME_PARAMETERIZATION";trajectory_processing::IterativeParabolicTimeParameterization iptp;
        if(!iptp.computeTimeStamps(*trajectory,req.at("velocity_scale").get<double>(),req.at("acceleration_scale").get<double>())) throw std::runtime_error("TIME_PARAMETERIZATION_FAILED");}
      r.result["processing_branch"]="TRAJECTORY_CONVERSION";
      moveit_msgs::msg::RobotTrajectory msg;trajectory->getRobotTrajectoryMsg(msg);
      if(msg.joint_trajectory.joint_names!=names) throw std::runtime_error("OUTPUT_JOINT_ORDER_MISMATCH");
      if(singleton) {
        r.result["processing_branch"]="SINGLETON_GOAL_AND_STATE_CHECK";
        geometry_msgs::msg::PoseStamped target;target.header.frame_id=r.start->getPlanningFrame();
        target.pose=pose(req.at("goal_pose"));
        const auto constraints=kinematic_constraints::constructGoalConstraints(
          identity.at("task_tcp_link").get<std::string>(),target,
          solver->properties().get<double>("goal_position_tolerance"),
          solver->properties().get<double>("goal_orientation_tolerance"));
        kinematic_constraints::KinematicConstraintSet goal(model);
        const bool configured=goal.add(constraints,r.start->getTransforms());
        const bool satisfied=configured && goal.decide(trajectory->getFirstWayPoint()).satisfied;
        const auto rejection=m710::stationaryPointFailure(msg.joint_trajectory,
            req.at("q_start").get<std::vector<double>>(),satisfied);
        if(!rejection.empty()) throw std::runtime_error(rejection);
        // Start clearance was already checked under this exact stage context.
        // Complete the single endpoint's existing process predicates as well.
        if(!r.process || !r.process->check(trajectory->getFirstWayPoint(),true)) {
          r.result["failure"]=r.process?r.process->last_failure:J("PROCESS_POLICY_REQUIRED");
          r.result["status"]="NATIVE_SINGLETON_PROCESS_REJECTED";return;
        }
        r.result["zero_motion_event"]={{"type","NATIVE_STATIONARY_PLACE"},{"goal_constraints_satisfied",true},
          {"native_duration_s",msg.joint_trajectory.points.front().time_from_start.sec+msg.joint_trajectory.points.front().time_from_start.nanosec*1e-9},
          {"start_unchanged",true},{"task_id",req.at("task_id")},{"stage_id",req.at("stage_id")},{"parent_stage_id",r.parent}};
      }
      J points=J::array(),path=J::array();
      for(const auto& p:msg.joint_trajectory.points) {points.push_back({{"q",p.positions},{"v",p.velocities},{"a",p.accelerations},{"t",p.time_from_start.sec+p.time_from_start.nanosec*1e-9}});path.push_back(p.positions);}
      J failure=nullptr;
      if(!planning_only) {
        const auto checking=Clock::now();r.clearance->phase="output";const double resolution=req.at("clearance_policy").at("edge_resolution_rad");
        failure=r.clearance->checkPath(r.start->getCurrentState(),path,resolution);
        if(failure.is_null() && r.process) failure=r.process->checkPath(r.start->getCurrentState(),path,resolution);
        r.result["native_output_check_s"]=seconds(checking);
      } else {
        r.result["native_output_check_s"]=nullptr;
        r.result["planning_only_status"]="PLANNING_ONLY_NOT_EXECUTABLE";
        if(r.process && r.process->hasSideTransfer()) {
          const auto checking=Clock::now();
          failure=r.process->checkSideReturned(r.start->getCurrentState(),path,
              begin+std::chrono::duration_cast<Clock::duration>(std::chrono::duration<double>(req.at("allowed_planning_time_s").get<double>())));
          r.result["side_returned_history_s"]=seconds(checking);
          r.result["side_history_scope"]="RETURNED_POINTS_ONLY_NOT_CONTINUOUS_PROOF";
        }
      }
      r.result["clearance"]=r.clearance->evidence();
      if(r.process) r.result["process_policy"]=r.process->evidence();
      r.result["points"]=points;r.result["joint_names"]=names;
      if(!failure.is_null()) {r.result["status"]="NATIVE_PATH_REJECTED";r.result["failure"]=failure;return;}
      r.trajectory=trajectory;r.end=r.start->diff();r.end->decoupleParent();r.end->setCurrentState(trajectory->getLastWayPoint());
      r.result["status"]="SUCCESS";r.result["native_output_status"]=planning_only?"SKIPPED_PLANNING_ONLY":"PASS";
      r.result["process_semantics_checked"]=!planning_only && bool(r.process);
      r.result["planner_internal_process_checks"]=bool(r.process);
      r.result["time_parameterization"]=pipeline=="ompl"?"IPTP_preserves_waypoints":"Pilz_original";
      r.result["task_tcp_identity"]=identity.at("task_tcp_fingerprint");r.result["interpolated_link"]=req.contains("goal_pose")?identity.at("task_tcp_link"):J(nullptr);
      r.result["processing_branch"]="ACCEPTED";
      r.result["generation_source"]="NATIVE_GENERATED";
      r.ready=true;
      } catch(const std::exception& e) {
        r.result["status"]="NATIVE_PROCESSING_FAILED";
        r.result["failure"]={{"reason",e.what()},{"branch",r.result.at("processing_branch")}};
        r.ready=false;r.trajectory.reset();r.end.reset();
      }
    };
    auto verify_scene=[this](const planning_scene::PlanningSceneConstPtr& before,const planning_scene::PlanningSceneConstPtr& after,const J& request) {
      checkTransition(before,after,request);
    };
    for(size_t i=common;i<ancestors.size();++i) {session.task->add(std::make_unique<NativeProcessStage>(session.records.at(ancestors[i]),generate,verify_scene));session.active.push_back(ancestors[i]);}
    auto record=std::make_shared<NativeStageRecord>();record->request=req;record->start=scene;record->clearance=clearance;record->process=process;record->parent=parent;
    session.records[stage_id]=record;session.task->add(std::make_unique<NativeProcessStage>(record,generate,verify_scene));session.active.push_back(stage_id);
    ++session.solve_calls;++requests;session.task->plan(1);
    if(record->result.is_null()) record->result={{"status","MTC_GENERATION_NOT_REACHED"}};
    record->result["mtc_task_solution_count"]=session.task->solutions().size();
    if(record->ready && session.task->solutions().empty()) {
      record->result["status"]="NATIVE_MTC_CONNECTION_FAILED";record->result["failure"]={{"reason","MTC_FULL_PREFIX_HAS_NO_SOLUTION"}};
      record->ready=false;record->trajectory.reset();record->end.reset();
    }
    record->result["mtc_attempt_index"]=requests;record->result["task_solve_calls"]=session.solve_calls;record->result["task_backtracks"]=session.backtracks;
    record->result["retained_native_subsolutions"]=session.records.size();record->result["task_stage_ids"]=session.active;
    record->result["diagnostic_only"]=diagnostic;
    if(req.contains("connection_scope"))record->result["connection_scope"]=req.at("connection_scope");
    if(req.contains("direct_rejection_stage_id"))record->result["direct_rejection_stage_id"]=req.at("direct_rejection_stage_id");
    if(diagnostic)record->result["planning_only_status"]="PLANNING_ONLY_NOT_EXECUTABLE";
    compactPlanningOnlyReply(record->result,planning_only,planning_mode);
    return record->result;
  }
J receiver_binding=nullptr;
public:
  J run(const J& req) {
    std::shared_ptr<m710::Clearance> clearance;
    std::shared_ptr<m710::ProcessPolicy> process;
    J result;
    const auto op=req.value("op",std::string());
    try {result=runImpl(req,clearance,process);}
    catch(const std::exception& e) {
      if(op!="plan" && op!="diagnostic_connection" && op!="validate" && op!="check_start" && op!="check_receiver_state" && op!="check_extraction_end" && op!="check_transit_end") throw;
      result={{"status","ERROR"},{"detail",e.what()}};
    }
    if(op=="plan" || op=="diagnostic_connection" || op=="validate" || (op=="check_start" || op=="check_receiver_state" || (op=="check_extraction_end" || op=="check_transit_end")))
      m710::completeRequestEvidence(result,bool(clearance),bool(process),
        [&]{return clearance->evidence();},[&]{return process->evidence();});
    return result;
  }
private:
  J runImpl(const J& req,std::shared_ptr<m710::Clearance>& clearance,
            std::shared_ptr<m710::ProcessPolicy>& process) {
    auto begin=Clock::now(); auto op=req.at("op").get<std::string>();
    if(op=="init") {
      if(model) throw std::runtime_error("ALREADY_INITIALIZED");
      planning_only=req.value("planning_only",false);
      receiver_binding=req.value("lifted_receiver_binding",J(nullptr));
      if(!receiver_binding.is_null()) {
        if(!planning_only || req.value("planning_mode","")!="cold_from_scratch")throw std::runtime_error("RECEIVER_INIT_SCOPE_INVALID");
        if(m710::coupledBinding(receiver_binding))m710::validateCoupledBinding(receiver_binding);
        else m710::receiverSweep(receiver_binding.at("low"),receiver_binding.at("high"));
      }
      bounded_preplace_ik_enabled=req.value("bounded_preplace_ik_enabled",false);
      single_target_recovery_enabled=req.value("single_target_recovery_enabled",false);
      if(single_target_recovery_enabled && (!req.value("planning_only",false) || req.value("planning_mode","")!="cold_from_scratch"))
        throw std::runtime_error("SINGLE_TARGET_RECOVERY_SCOPE");
      if(bounded_preplace_ik_enabled && (!planning_only ||
          req.value("planning_mode","cold_from_scratch")!="cold_from_scratch"))
        throw std::runtime_error("BOUNDED_PREPLACE_IK_SCOPE");
      if(bounded_preplace_ik_enabled || single_target_recovery_enabled) {
        const auto& params=req.at("parameters");
        const std::string prefix="robot_description_kinematics.manipulator.";
        if(params.value(prefix+"position_only_ik",false) ||
            params.value(prefix+"orientation_vs_position",1.)<=0.)
          throw std::runtime_error("BOUNDED_PREPLACE_REQUIRES_FULL_POSE_IK");
      }
      planning_mode=req.value("planning_mode",std::string("cold_from_scratch"));
      prior_placement_policy_sha256=req.value("placement_policy_sha256",std::string());
      if(planning_mode!="cold_from_scratch" && planning_mode!="static_prior_fast")
        throw std::runtime_error("UNKNOWN_PLANNING_MODE");
      if(planning_mode=="static_prior_fast" && !planning_only)
        throw std::runtime_error("STATIC_PRIOR_REQUIRES_PLANNING_ONLY");
      seed=req.at("seed");
      static bool seeded=false;static uint32_t process_seed=0;
      if(!seeded) {ompl::RNG::setSeed(seed);process_seed=seed;seeded=true;}
      else if(seed!=process_seed) throw std::runtime_error("RESIDENT_SEED_MISMATCH");
      if(req.value("search_trace_enabled",false) && (!planning_only || planning_mode!="cold_from_scratch"))
        throw std::runtime_error("SEARCH_TRACE_SCOPE_INVALID");
      std::vector<rclcpp::Parameter> params;
      for(auto it=req.at("parameters").begin(); it!=req.at("parameters").end(); ++it) {
        if(req.value("search_trace_enabled",false) && it.key()=="ompl.planning_plugin") {
          params.emplace_back(it.key(),std::string("m710/RecordedOMPLPlanner"));continue;
        }
        const auto& v=it.value();
        if(v.is_string()) params.emplace_back(it.key(),v.get<std::string>());
        else if(v.is_boolean()) params.emplace_back(it.key(),v.get<bool>());
        else if(v.is_number_integer()) params.emplace_back(it.key(),v.get<int64_t>());
        else if(v.is_number()) params.emplace_back(it.key(),v.get<double>());
        else if(v.is_array()) params.emplace_back(it.key(),v.get<std::vector<std::string>>());
        else throw std::runtime_error("INVALID_PARAMETER_TYPE");
      }
      node=std::make_shared<rclcpp::Node>("m710_moveit_worker_"+req.at("identity").at("model_tool_fingerprint").get<std::string>().substr(0,12), rclcpp::NodeOptions().parameter_overrides(params).automatically_declare_parameters_from_overrides(true));
      loader=std::make_shared<robot_model_loader::RobotModelLoader>(node,"robot_description");
      model=loader->getModel(); if(!model) throw std::runtime_error("MODEL_UNAVAILABLE");
      const auto* group=model->getJointModelGroup("manipulator");
      if(!group) throw std::runtime_error("GROUP_UNAVAILABLE");
      names=group->getVariableNames(); if(names!=req.at("joint_names").get<std::vector<std::string>>()) throw std::runtime_error("JOINT_ORDER_MISMATCH");
      for(const auto& name:{"pilz_industrial_motion_planner","ompl"}) {
        auto p=std::make_shared<planning_pipeline::PlanningPipeline>(model,node,name,"planning_plugin","request_adapters");
        if(!p->getPlannerManager()) throw std::runtime_error(std::string("PIPELINE_UNAVAILABLE:")+name);
        p->displayComputedMotionPlans(false); p->publishReceivedRequests(false);
        pipelines[name]=p;
      }
      for(auto it=req.at("expected_collision_shapes").begin();it!=req.at("expected_collision_shapes").end();++it) {
        const auto* link=model->getLinkModel(it.key());
        if(!link || link->getShapes().size()!=it.value().get<size_t>()) throw std::runtime_error("COLLISION_GEOMETRY_MISSING:"+it.key());
        for(const auto& shape:link->getShapes()) {
          if(shape->type==shapes::MESH && static_cast<const shapes::Mesh*>(shape.get())->triangle_count==0) throw std::runtime_error("EMPTY_COLLISION_MESH");
        }
      }
      bound_policy=req.at("collision_policy");bound_tools=req.at("tool_links");
      bound_compliant=req.value("compliant_tool_links",J::array());bound_process_geometry=req.value("process_geometry",J(nullptr));
      base=std::make_shared<planning_scene::PlanningScene>(model);
      identity=req.at("identity");
      return {{"status","READY"},{"identity",identity},{"joint_names",names},{"cold_start_s",seconds(begin)},{"planning_only",planning_only},{"planning_mode",planning_mode},
              {"seed",seed},{"versions",{{"moveit",M710_MOVEIT_VERSION},{"mtc",M710_MTC_VERSION},{"pilz",M710_PILZ_VERSION}}},{"pipelines",{"pilz_industrial_motion_planner","ompl"}},
              {"capabilities",{{"native_ik",true},{"native_task_session",true},{"semantic_place_event",planning_only&&planning_mode=="static_prior_fast"},
                {"native_ik_batch",planning_only&&planning_mode=="static_prior_fast"},
                {"coupled_receiver_discrete",m710::coupledBinding(receiver_binding)},
                {"nominal_drop_release",m710::coupledBinding(receiver_binding)},
                {"static_prior_graph",planning_only&&planning_mode=="static_prior_fast"},{"process_policy_schema","m710_native_process_v1"},
                {"process_geometry_bound",!bound_process_geometry.is_null()&&!bound_compliant.empty()},
                {"max_task_sessions",8},{"max_task_stages_per_session",4096}}}};
    }
#ifdef M710_IK_INPUT_PROBE
    // This non-installed diagnostic build cannot generate or import motion.
    if(op!="ik" && op!="fk") throw std::runtime_error("IK_INPUT_PROBE_NO_MOTION");
#endif
    if(!model) throw std::runtime_error("NOT_INITIALIZED");
    if((op=="plan" || op=="diagnostic_connection" || (op=="check_start" || op=="check_receiver_state" || (op=="check_extraction_end" || op=="check_transit_end")) || op=="ik" || op=="ik_batch") && req.value("planning_only",false)!=planning_only)
      throw std::runtime_error("PLANNING_ONLY_MODE_MISMATCH");
    if((op=="plan" || op=="diagnostic_connection" || (op=="check_start" || op=="check_receiver_state" || (op=="check_extraction_end" || op=="check_transit_end")) || op=="ik" || op=="ik_batch" || op=="load_static_prior" || op=="build_static_prior" || op.rfind("prior_",0)==0) &&
        req.value("planning_mode",std::string("cold_from_scratch"))!=planning_mode)
      throw std::runtime_error("PLANNING_MODE_MISMATCH");
    if(planning_only && (op=="task_audit" || op=="compose" || op=="validate"))
      throw std::runtime_error("PLANNING_ONLY_NOT_EXECUTABLE");
    if(planning_only && (op=="plan" || op=="diagnostic_connection") && !req.value("require_native_motion",false))
      throw std::runtime_error("PLANNING_ONLY_REQUIRES_NATIVE_TASK");
    if(!knownInitializedOperation(op)) throw std::runtime_error("UNKNOWN_OPERATION");
    if(req.at("identity")!=identity) throw std::runtime_error("MODEL_OR_POLICY_MISMATCH");
    if(op=="load_static_prior" || op=="build_static_prior" || op=="ik_batch") {
      if(!planning_only || planning_mode!="static_prior_fast") throw std::runtime_error("STATIC_PRIOR_MODE_REQUIRED");
    }
    if(op=="load_static_prior") {
      const auto& database=req.at("database");
      if(database.at("schema")!="m710_static_prior_v1" || database.at("status")!="PLANNING_ONLY_NOT_EXECUTABLE" ||
          database.at("qualification_status")!="NOT_EVALUATED") throw std::runtime_error("PRIOR_DATABASE_MARKER_INVALID");
      if(database.at("modes").empty() || database.at("modes").size()>2) throw std::runtime_error("PRIOR_DATABASE_MODES_INVALID");
      for(auto it=database.at("modes").begin();it!=database.at("modes").end();++it) {
        if(it.key()!="empty" && it.key()!="loaded")throw std::runtime_error("PRIOR_DATABASE_MODE_INVALID");
        m710::StaticPriorGraph::validate(it.value());
        if(it.value().at("context").at("identity")!=identity ||
            it.value().at("context").at("attachment").at("mode")!=it.key())
          throw std::runtime_error("PRIOR_DATABASE_IDENTITY_MISMATCH");
      }
      static_prior_database=database;
      return {{"status","SUCCESS"},{"loaded_modes",database.at("modes").size()},{"load_s",seconds(begin)},
        {"planning_only_status","PLANNING_ONLY_NOT_EXECUTABLE"}};
    }
    if(op=="ik_batch") {
      const auto& seeds=req.at("ik_seeds");
      if(!seeds.is_array() || seeds.empty() || seeds.size()>8) throw std::runtime_error("NATIVE_IK_BATCH_LIMIT");
      const double budget=req.at("allowed_planning_time_s");
      if(!std::isfinite(budget)||budget<=0) return {{"status","NATIVE_IK_BATCH_TIMEOUT"},{"results",J::array()},{"consume_count",0},{"native_ik_calls",0},{"ik_s",0.}};
      J results=J::array();double solver_s=0.;bool timed_out=false;
      for(size_t i=0;i<seeds.size();++i) {
        if(req.value("cancelled",false)) return {{"status","CANCELLED"},{"results",results},{"consume_count",results.size()},{"native_ik_calls",results.size()},{"ik_s",solver_s}};
        if(seconds(begin)>=budget) {timed_out=true;break;}
        auto one=req;one["op"]="ik";one["q_start"]=seeds.at(i);one.erase("ik_seeds");
        one["seed"]=req.at("seed").get<uint32_t>()+i;
        one["allowed_planning_time_s"]=budget-seconds(begin);
        const auto before=Clock::now();auto result=run(one);result["seed_index"]=i;
        solver_s+=result.value("ik_s",seconds(before));results.push_back(result);
        if(result.at("status")=="SUCCESS" && req.value("stop_on_first_success",true))break;
      }
      return {{"status",timed_out?"NATIVE_IK_BATCH_TIMEOUT":"SUCCESS"},{"results",results},
        {"consume_count",results.size()},{"native_ik_calls",results.size()},{"ik_s",solver_s},{"batch_s",seconds(begin)}};
    }
    if(op=="task_audit") {
      const std::string id=req.at("task_id");if(!tasks.count(id)) throw std::runtime_error("NATIVE_TASK_UNKNOWN");
      const auto& session=*tasks.at(id);const auto ids=req.at("stage_ids").get<std::vector<std::string>>();
      if(req.contains("target_id") && req.at("target_id")!=session.target_id) throw std::runtime_error("NATIVE_TASK_TARGET_ID_CHANGED");
      if(ids.empty()) throw std::runtime_error("NATIVE_TASK_EMPTY");
      std::string previous;size_t edges=0,attach=0,release=0;J stages=J::array(),terminal_transition=nullptr;
      bool was_attached=false;std::set<std::string> phase_names;
      for(const auto& stage_id:ids) {
        if(!session.records.count(stage_id)) throw std::runtime_error("NATIVE_TASK_STAGE_UNKNOWN");
        const auto& r=*session.records.at(stage_id);
        if(r.parent!=previous || !r.ready || r.result.at("status")!="SUCCESS") throw std::runtime_error("NATIVE_TASK_SOURCE_CHAIN_INVALID");
        const std::string target=r.request.at("clearance_policy").at("target_id");const bool attached=r.start->getCurrentState().hasAttachedBody(target);
        if(attached&&!was_attached) ++attach;if(!attached&&was_attached) ++release;was_attached=attached;
        phase_names.insert(r.request.at("stage").get<std::string>());
        size_t motion_edges=0;for(size_t i=1;r.trajectory && i<r.trajectory->getWayPointCount();++i)
          if(r.trajectory->getWayPoint(i-1).distance(r.trajectory->getWayPoint(i))>1e-12) ++motion_edges;
        edges+=motion_edges;stages.push_back({{"stage_id",stage_id},{"parent_stage_id",r.parent},{"request_id",r.request.at("request_id")},
          {"native_solver_calls",r.result.at("native_solver_calls")},{"nonzero_motion_edges",motion_edges},{"native_cache_reuses",r.cache_hits}});previous=stage_id;
      }
      if(req.contains("terminal_state_request")) {
        auto terminal=req.at("terminal_state_request");
        for(const auto* key:{"path","probe_path","probe_states","stages","q_goal","goal_pose","pipeline_id","planner_id"})
          if(terminal.contains(key)) throw std::runtime_error("NATIVE_TASK_TERMINAL_MOTION_INPUT_FORBIDDEN");
        if(terminal.at("identity")!=identity || terminal.at("task_id")!=id || terminal.at("parent_stage_id")!=previous ||
           terminal.at("clearance_policy").at("target_id")!=session.target_id)
          throw std::runtime_error("NATIVE_TASK_TERMINAL_IDENTITY_MISMATCH");
        const std::string terminal_stage=terminal.at("stage");
        if((terminal_stage!="withdrawal" && terminal_stage!="residence") || !terminal.at("attachment").is_null() ||
           !terminal.contains("process_policy") || terminal.at("clearance_policy").at("schema")!="m710_native_process_clearance_v1")
          throw std::runtime_error("NATIVE_TASK_TERMINAL_RELEASE_CONTEXT_REQUIRED");
        const auto& last=*session.records.at(previous);std::vector<double> last_q;
        last.end->getCurrentState().copyJointGroupPositions("manipulator",last_q);
        if(terminal.at("q_start").get<std::vector<double>>()!=last_q) throw std::runtime_error("NATIVE_TASK_TERMINAL_STATE_CHANGED");
        // Use the same bound-model, scene import, clearance and process gates
        // as any native state validation. This operation cannot call a solver.
        terminal["op"]="validate";const auto before_calls=calls;const J checked=run(terminal);
        if(calls!=before_calls) throw std::runtime_error("NATIVE_TASK_TERMINAL_UNEXPECTED_SOLVER_CALL");
        if(checked.at("status")!="SUCCESS" || !checked.at("native_valid").get<bool>() || !checked.at("process_valid").get<bool>())
          return {{"status","NATIVE_TASK_TERMINAL_STATE_REJECTED"},{"task_id",id},{"complete_task",false},{"terminal_validation",checked}};
        // run(validate) left base bound to exactly the validated world. Its
        // current state is immutable import state; copy the native endpoint,
        // remove only this target's attachment, then compare both scenes.
        auto final_scene=base->diff();final_scene->decoupleParent();auto final_state=last.end->getCurrentState();
        final_state.clearAttachedBody(session.target_id);final_state.update();final_scene->setCurrentState(final_state);
        checkTransition(last.end,final_scene,terminal,"terminal_release");
        if(final_scene->getCurrentState().hasAttachedBody(session.target_id) || !final_scene->getWorld()->hasObject(session.target_id))
          throw std::runtime_error("NATIVE_TASK_TERMINAL_TARGET_OWNERSHIP_INVALID");
        const bool released=last.end->getCurrentState().hasAttachedBody(session.target_id);
        if(released) ++release;was_attached=false;
        terminal_transition={{"event",released?"RELEASE":"NONE"},{"zero_motion",true},{"native_solver_calls",0},
          {"parent_stage_id",previous},{"target_id",session.target_id},{"q_rad",last_q},{"native_state_validation",checked}};
      }
      if(attach!=1 || release!=1 || was_attached || !phase_names.count("contact") || !phase_names.count("extraction"))
        throw std::runtime_error("NATIVE_TASK_CYCLE_EVENTS_INCOMPLETE");
      return {{"status","SUCCESS"},{"task_id",id},{"generated_during_task",true},{"stage_ids",ids},{"complete_task",true},
        {"stage_sources",stages},{"nonzero_native_motion_edges",edges},{"attach_transitions",attach},{"release_transitions",release},
        {"terminal_transition",terminal_transition},
        {"task_solve_calls",session.solve_calls},{"task_backtracks",session.backtracks},{"external_path_imports",0}};
    }
    auto state=base->getCurrentState();
    auto q=req.at("q_start").get<std::vector<double>>();
    if(q.size()!=names.size()) throw std::runtime_error("INVALID_JOINT_VECTOR");
    for(double x:q) if(!std::isfinite(x)) throw std::runtime_error("INVALID_JOINT_VECTOR");
    state.setJointGroupPositions("manipulator",q); state.setVariableVelocities(std::vector<double>(model->getVariableCount(),0)); state.update();
    if(!state.satisfiesBounds()) throw std::runtime_error("INVALID_START_BOUNDS");
    if(op=="fk") {
      J frames=J::object(); for(auto& l:req.at("links")) frames[l.get<std::string>()]=serial(state.getGlobalLinkTransform(l.get<std::string>()));
      return {{"status","SUCCESS"},{"frames",frames}};
    }
    if(req.value("cancelled",false)) throw std::runtime_error("CANCELLED");
    if(op!="ik" && req.value("ik_mode",std::string())=="bounded_target") throw std::runtime_error("SINGLE_TARGET_RECOVERY_SCOPE");
    if(op=="ik") {
      if(req.contains("history") || req.contains("path") || req.contains("q_goal")) throw std::runtime_error("NATIVE_IK_FORBIDDEN_INPUT");
      const auto mode=req.value("ik_mode",std::string("single_attempt"));
      if(mode!="single_attempt" && mode!="bounded_preplace" && mode!="bounded_target") throw std::runtime_error("UNKNOWN_IK_MODE");
      const bool recovery=mode=="bounded_target";
      const bool bounded=mode!="single_attempt";
      double budget=0.,stage_budget=0.;
      if(bounded) {
        if(!(recovery?m710::boundedTargetIkScope(req,single_target_recovery_enabled,planning_only,planning_mode,m710::coupledBinding(receiver_binding)):m710::boundedIkScope(req,bounded_preplace_ik_enabled,planning_only,planning_mode)))
          throw std::runtime_error("BOUNDED_PREPLACE_IK_SCOPE");
        stage_budget=req.at("allowed_planning_time_s");
        budget=m710::boundedIkBudget(req.at("solver_budget_s"),stage_budget-seconds(begin));
        if(stage_budget<=0 || budget<=0) throw std::runtime_error("NATIVE_IK_REQUEST_DEADLINE");
        for(const auto* key:{"position_tolerance_m","orientation_tolerance_rad"}) {
          const double x=req.at(key);if(!std::isfinite(x)||x<=0)throw std::runtime_error("INVALID_IK_TOLERANCE");
        }
        if(req.at("clearance_policy").at("source_policy")!=bound_policy ||
            req.at("clearance_policy").at("tool_links")!=bound_tools ||
            req.at("process_policy").at("target_id")!=req.at("clearance_policy").at("target_id") ||
            req.at("process_policy").at("cups")!=bound_process_geometry.at("cups") ||
            req.at("process_policy").at("flange_from_physical_contact")!=bound_process_geometry.at("flange_from_physical_contact"))
          throw std::runtime_error("NATIVE_IK_POLICY_IDENTITY_MISMATCH");
#ifndef M710_IK_INPUT_PROBE
        if(req.at("stage")=="transit") {
        // Continue this live task's generated extraction endpoint, never an old q.
        const std::string task_id=req.at("task_id"),parent_id=req.at("parent_stage_id");
        if(!tasks.count(task_id) || !tasks.at(task_id)->records.count(parent_id))
          throw std::runtime_error("NATIVE_TASK_IK_PARENT_UNKNOWN");
        const auto& parent=*tasks.at(task_id)->records.at(parent_id);
        std::vector<double> end;
        if(!parent.ready || !parent.end || parent.request.at("stage")!="extraction")
          throw std::runtime_error("NATIVE_TASK_IK_PARENT_INVALID");
        parent.end->getCurrentState().copyJointGroupPositions("manipulator",end);
        const auto& a=req.at("attachment");const auto& old=parent.request.at("attachment");
        if(q!=end || req.at("world")!=parent.request.at("world") || a.at("id")!=old.at("id") ||
            a.at("size")!=old.at("size") || a.at("touch_links")!=old.at("touch_links") ||
            !samePose(matrix(a.at("pose")),matrix(old.at("pose"))) ||
            !parent.end->getCurrentState().hasAttachedBody(a.at("id").get<std::string>()) ||
            req.at("process_policy").at("actual_contact_mask")!=parent.request.at("process_policy").at("actual_contact_mask"))
          throw std::runtime_error("NATIVE_TASK_IK_PARENT_CONTEXT_MISMATCH");
        } else if(recovery) {
          const std::string task_id=req.at("task_id");
            const std::string parent_id=req.value("parent_stage_id","");
            if(!parent_id.empty()) {
              if(!m710::coupledBinding(receiver_binding) || !tasks.count(task_id) || !tasks.at(task_id)->records.count(parent_id))
                throw std::runtime_error("COUPLED_IK_PARENT_UNKNOWN");
              const auto& parent=*tasks.at(task_id)->records.at(parent_id);std::vector<double> actual;
              if(!parent.ready || !parent.end || parent.request.at("pipeline_id")!="external_axis" ||
                  parent.request.at("stage")!="pregrasp" || !parent.request.at("attachment").is_null())
                throw std::runtime_error("COUPLED_IK_PARENT_INVALID");
              parent.end->getCurrentState().copyJointGroupPositions("manipulator",actual);
              if(actual!=q || req.at("world")!=parent.request.at("receiver_end_world") ||
                  tasks.at(task_id)->target_id!=req.at("process_policy").at("target_id") || !req.at("ownership_transition").is_null())
                throw std::runtime_error("COUPLED_IK_PARENT_CONTEXT_MISMATCH");
            } else if(tasks.count(task_id) && (tasks.at(task_id)->initial_q!=req.at("q_start") ||
              tasks.at(task_id)->initial_world!=req.at("world") ||
              tasks.at(task_id)->target_id!=req.at("process_policy").at("target_id")))
            throw std::runtime_error("NATIVE_TASK_IK_ROOT_CONTEXT_MISMATCH");
        }
#endif
      }
      const auto* group=model->getJointModelGroup("manipulator");const auto& solver=group->getSolverInstance();
      if(!solver || solver->getJointNames()!=names || solver->getTipFrame()!=identity.at("task_tcp_link").get<std::string>()) throw std::runtime_error("NATIVE_IK_SOLVER_CONTEXT_MISMATCH");
      const auto target=matrix(req.at("goal_pose"));const auto base_frame=solver->getBaseFrame();
      const auto local=state.getGlobalLinkTransform(base_frame).inverse()*target;
      if(bounded) {
        budget=m710::boundedIkBudget(req.at("solver_budget_s"),stage_budget-seconds(begin));
        if(budget<=0)throw std::runtime_error("NATIVE_IK_REQUEST_DEADLINE");
      }
      std::vector<double> solution;moveit_msgs::msg::MoveItErrorCodes error;
      // One API call starts with q; plugin-internal retries are not observable.
      std::vector<std::vector<double>> excluded;
      if(recovery)for(const auto& row:req.value("excluded_ik",J::array())) {
        auto values=row.get<std::vector<double>>();if(values.size()!=names.size())throw std::runtime_error("INVALID_IK_EXCLUSION");
        for(auto x:values)if(!std::isfinite(x))throw std::runtime_error("INVALID_IK_EXCLUSION");excluded.push_back(std::move(values));
      }
      const double tolerance=req.value("ik_dedup_tolerance_rad",1e-6);
      if(recovery && (!std::isfinite(tolerance)||tolerance<=0||tolerance>.01))throw std::runtime_error("INVALID_IK_DEDUP_TOLERANCE");
      if(recovery) {budget=m710::boundedIkBudget(req.at("solver_budget_s"),stage_budget-seconds(begin));
        if(budget<=0)throw std::runtime_error("NATIVE_IK_REQUEST_DEADLINE");}
      const auto started=Clock::now();++ik_calls;bool success;
      auto numerical_seed=q;
      if(req.contains("numerical_ik_seed")) {
        if(!recovery || req.at("stage")!="pregrasp" || !m710::coupledBinding(receiver_binding) ||
           req.value("numerical_seed_policy","")!="SOFT_UPPER_ARM_WITH_GENERAL_SEEDS_V1")
          throw std::runtime_error("NUMERICAL_IK_SEED_SCOPE");
        numerical_seed=req.at("numerical_ik_seed").get<std::vector<double>>();
        if(numerical_seed.size()!=names.size())throw std::runtime_error("INVALID_NUMERICAL_IK_SEED");
        for(auto x:numerical_seed)if(!std::isfinite(x))throw std::runtime_error("INVALID_NUMERICAL_IK_SEED");
        auto probe=state;probe.setJointGroupPositions(group,numerical_seed);probe.update();
        if(!probe.satisfiesBounds())throw std::runtime_error("NUMERICAL_IK_SEED_OUTSIDE_OFFICIAL_LIMITS");
      }
      if(recovery) {
        kinematics::KinematicsQueryOptions exact;exact.return_approximate_solution=false;
        kinematics::KinematicsBase::IKCallbackFn callback=[&](const geometry_msgs::msg::Pose&,const std::vector<double>& candidate,moveit_msgs::msg::MoveItErrorCodes& code) {
          code.val=moveit_msgs::msg::MoveItErrorCodes::SUCCESS;
          for(const auto& old:excluded) {bool duplicate=candidate.size()==old.size();
            for(size_t i=0;duplicate&&i<old.size();++i)duplicate=std::abs(candidate[i]-old[i])<=tolerance;
            if(duplicate) {code.val=moveit_msgs::msg::MoveItErrorCodes::NO_IK_SOLUTION;return;}}
        };
        success=solver->searchPositionIK(pose(serial(local)),numerical_seed,budget,solution,callback,error,exact);
      } else success=m710::invokeIk(*solver,bounded,pose(serial(local)),q,budget,solution,error);
      const double actual_ik_s=seconds(started);
      J result={{"status","NATIVE_IK_FAILED"},{"native_ik_calls",1},{"resident_native_ik_calls",ik_calls},
        {"solver",bounded?"MoveIt_KDL_searchPositionIK":"MoveIt_KDL_getPositionIK"},
        {"solver_api",bounded?"searchPositionIK":"getPositionIK"},{"ik_mode",mode},
        {"bounded_search",bounded},{"solver_api_calls",1},{"ik_request_count",1},
        {"requested_solver_budget_s",bounded?req.at("solver_budget_s"):J(nullptr)},
        {"effective_solver_budget_s",bounded?J(budget):J(nullptr)},
        {"internal_attempts",bounded?J(nullptr):J(1)},
        {"internal_attempts_observability",bounded?"NOT_OBSERVABLE":"SINGLE_INITIAL_ATTEMPT"},
        {"ik_collision_checked",false},{"ik_s",actual_ik_s},{"actual_ik_s",actual_ik_s},{"error_code",error.val},
        {"seed",req.at("seed")},{"seed_scope","OMPL_ONLY_KDL_INTERNAL_RNG_NOT_CONTROLLED"},
        {"random_restarts",bounded?J(nullptr):J(0)}};
      if(bounded && seconds(begin)>=stage_budget) {result["status"]="NATIVE_IK_REQUEST_DEADLINE";return result;}
#ifdef M710_IK_INPUT_PROBE
      result["diagnostic_scope"]="IK_INPUT_ONLY_NO_LIVE_TASK_NO_MOTION";
#endif
      if(recovery) {result["excluded_local_ik_count"]=excluded.size();result["ik_exclusion_scope"]="THIS_FIXED_TARGET_CONNECTION_ONLY";}
      if(req.contains("numerical_ik_seed")) {
        result["numerical_ik_seed"]=numerical_seed;
        result["numerical_seed_index"]=req.at("numerical_seed_index");
        result["real_start_q_unchanged"]=q;
        result["numerical_seed_policy"]=req.at("numerical_seed_policy");
      }
      if(!success || solution.size()!=names.size()) return result;
      if(recovery)result["solver_candidate_q"]=solution;
      for(double x:solution) if(!std::isfinite(x)) return result;
      state.setJointGroupPositions(group,solution);state.update();if(!state.satisfiesBounds()) return result;
      const auto actual=state.getGlobalLinkTransform(identity.at("task_tcp_link").get<std::string>());
      const double position=(actual.translation()-target.translation()).norm();
      const double rotation=Eigen::AngleAxisd(actual.linear().transpose()*target.linear()).angle();
      result["position_error_m"]=position;result["orientation_error_rad"]=rotation;
      if(position>req.value("position_tolerance_m",1e-6) || rotation>req.value("orientation_tolerance_rad",1e-6)) return result;
      result["status"]="SUCCESS";result["q"]=solution;return result;
    }
    if(req.at("start_velocity").size()!=names.size()) throw std::runtime_error("INVALID_START_VELOCITY");
    for(double v:req.at("start_velocity")) if(v!=0.0) throw std::runtime_error("UNSUPPORTED_NONZERO_START_VELOCITY");
    if(!req.at("path_constraints").empty()) throw std::runtime_error("UNSUPPORTED_PATH_CONSTRAINTS");
    auto imported=Clock::now();
    std::string key=req.at("scene_fingerprint"); bool changed=key!=scene_key;
    if(!changed && req.at("world")!=scene_content) throw std::runtime_error("SCENE_FINGERPRINT_REUSED_WITH_DIFFERENT_CONTENT");
    if(changed) {
      auto next=std::make_shared<planning_scene::PlanningScene>(model); std::set<std::string> ids;
      for(const auto& b:req.at("world")) {
        if(!ids.insert(b.at("id").get<std::string>()).second) throw std::runtime_error("DUPLICATE_OBJECT");
        if(!next->processCollisionObjectMsg(object(b))) throw std::runtime_error("SCENE_IMPORT_FAILED");
      }
      base=next;scene_key=key;scene_content=req.at("world");
    }
    auto scene=base->diff(); scene->decoupleParent(); scene->setCurrentState(state);
    auto& acm=scene->getAllowedCollisionMatrixNonConst();
    for(const auto& pair:req.at("allowed_pairs")) acm.setEntry(pair.at(0).get<std::string>(),pair.at(1).get<std::string>(),true);
    std::string attached_id;
    if(!req.at("attachment").is_null()) {
      auto b=req.at("attachment"); attached_id=b.at("id");
      // A single object identity moves from world to attached; never duplicates.
      scene->getWorldNonConst()->removeObject(attached_id);
      moveit_msgs::msg::AttachedCollisionObject a; a.link_name="flange"; a.object=object(b,"flange");
      a.touch_links=b.at("touch_links").get<std::vector<std::string>>();
      if(!scene->processAttachedCollisionObjectMsg(a)) throw std::runtime_error("ATTACH_FAILED");
      if(scene->getWorld()->hasObject(attached_id)) throw std::runtime_error("DUPLICATE_ATTACHMENT");
    }
    double import_s=seconds(imported);
    if(op=="inspect") {
      J permissions=J::array();
      for(const auto& pair:req.at("inspect_pairs")) {
        collision_detection::AllowedCollision::Type allowed;
        bool found=acm.getEntry(pair.at(0).get<std::string>(),pair.at(1).get<std::string>(),allowed);
        permissions.push_back(found && allowed==collision_detection::AllowedCollision::ALWAYS);
      }
      std::vector<const moveit::core::AttachedBody*> bodies, base_bodies;scene->getCurrentState().getAttachedBodies(bodies);base->getCurrentState().getAttachedBodies(base_bodies);
      const std::string target=req.contains("clearance_policy") ? req.at("clearance_policy").value("target_id",attached_id) : attached_id;
      const auto world_target=scene->getWorld()->getObject(target);const auto* attached_target=scene->getCurrentState().getAttachedBody(target);
      J target_pose=nullptr;
      if(world_target && !world_target->global_shape_poses_.empty()) target_pose=serial(m710::worldShapePose(*world_target,0));
      if(attached_target && !attached_target->getGlobalCollisionBodyTransforms().empty()) target_pose=serial(attached_target->getGlobalCollisionBodyTransforms().at(0));
      return {{"status","SUCCESS"},{"world_count",scene->getWorld()->size()},{"attached_count",bodies.size()},
        {"target_id",target},{"target_in_world",bool(world_target)},{"target_attached",bool(attached_target)},{"target_world_pose",target_pose},
        {"permissions",permissions},{"base_attached_count",base_bodies.size()}};
    }
    if(op=="plan" || op=="diagnostic_connection" || op=="validate" || (op=="check_start" || op=="check_receiver_state" || (op=="check_extraction_end" || op=="check_transit_end")) || op=="build_static_prior") {
      if(!req.contains("clearance_policy")) throw std::runtime_error("CLEARANCE_POLICY_REQUIRED");
      if(req.at("clearance_policy").at("source_policy")!=bound_policy || req.at("clearance_policy").at("tool_links")!=bound_tools)
        throw std::runtime_error("EXECUTABLE_POLICY_MISMATCH");
      if(req.contains("process_policy") && op!="build_static_prior") {
        if(bound_compliant.empty() || req.at("clearance_policy").at("compliant_tool_links")!=bound_compliant)
          throw std::runtime_error("PROCESS_COLLIDER_OWNERSHIP_MISMATCH");
        if(bound_process_geometry.is_null()) throw std::runtime_error("PROCESS_CUP_GEOMETRY_BINDING_REQUIRED");
        if(req.at("process_policy").at("cups")!=bound_process_geometry.at("cups") ||
           req.at("process_policy").at("flange_from_physical_contact")!=bound_process_geometry.at("flange_from_physical_contact"))
          throw std::runtime_error("PROCESS_CUP_GEOMETRY_BINDING_MISMATCH");
        process=std::make_shared<m710::ProcessPolicy>(scene,req);
      }
      if(req.at("clearance_policy").at("schema")=="m710_native_process_clearance_v1" && !process && op!="build_static_prior")
        throw std::runtime_error("PROCESS_POLICY_REQUIRED");
      if(req.value("require_native_motion",false) && (op=="plan" || op=="diagnostic_connection") && !process) throw std::runtime_error("NATIVE_COLD_PROCESS_CONTEXT_REQUIRED");
      clearance=std::make_shared<m710::Clearance>(scene,req.at("clearance_policy"),req.value("clearance_mode",std::string("optimized")),req.value("native_check_reuse",true),true,req.value("pair_profile_enabled",false));
      // Environment + ACM belong to this immutable candidate. The predicate
      // always checks OMPL's supplied state, including its real attached body.
      scene->setStateFeasibilityPredicate([clearance,process](const moveit::core::RobotState& current,bool verbose){
        auto record=[&](bool valid,const char* checker,const J& failure) {
          if(m710::extension_recorder) {std::vector<double> q;current.copyJointGroupPositions("manipulator",q);
            (*m710::extension_recorder)(q,valid,checker,failure);}
          return valid;
        };
        if(!clearance->check(current,verbose)) return record(false,"CLEARANCE",clearance->last_failure);
        if(process && !process->check(current)) return record(false,"PROCESS_POLICY",process->last_failure);
        return record(true,"CUSTOM_FEASIBILITY",J(nullptr));
      });
    }
    if((op=="check_extraction_end" || op=="check_transit_end")) {
      const std::string end_stage=op=="check_extraction_end"?"extraction":"transit";
      const std::string error_prefix=op=="check_extraction_end"?"EXTRACTION_END":"TRANSIT_END";
      // A single endpoint under restored free-space pair rules, not a path audit.
      if(!planning_only || planning_mode!="cold_from_scratch" || req.at("stage")!=end_stage ||
         !req.value("require_native_motion",false) || req.at("attachment").is_null() || !process ||
         !req.at("process_policy").at("initial_proximity").is_null() ||
         !req.at("process_policy").at("support_names").empty() ||
         !req.at("ownership_transition").is_null() ||
         (end_stage=="transit" && req.value("purpose",std::string())!="FREE_LOADED_TRANSFER"))
        throw std::runtime_error(error_prefix+"_CHECK_SCOPE_INVALID");
      const std::string task=req.at("task_id"),parent=req.at("parent_stage_id");
      if(!tasks.count(task) || parent.empty() || !tasks.at(task)->records.count(parent))
        throw std::runtime_error("NATIVE_TASK_"+error_prefix+"_PARENT_MISSING");
      const auto& previous=*tasks.at(task)->records.at(parent);
      if(!previous.ready || previous.request.at("stage")!=end_stage || !previous.end ||
         previous.request.at("attachment").is_null())
        throw std::runtime_error("NATIVE_TASK_"+error_prefix+"_PARENT_INVALID");
      std::vector<double> q;previous.end->getCurrentState().copyJointGroupPositions("manipulator",q);
      if(req.at("q_start")!=J(q)) throw std::runtime_error("NATIVE_TASK_"+error_prefix+"_STATE_CHANGED");
      checkTransition(previous.end,scene,req,end_stage+"_endpoint");
      const bool valid=clearance->check(scene->getCurrentState());
      const bool process_valid=valid && process->check(scene->getCurrentState(),true);
      const std::string target=req.at("clearance_policy").at("target_id");
      const auto* attached=scene->getCurrentState().getAttachedBody(target);
      if(!attached || scene->getWorld()->hasObject(target))
        throw std::runtime_error("NATIVE_TASK_"+error_prefix+"_OWNERSHIP_INVALID");
      return {{"status",!valid?error_prefix+"_CLEARANCE_REJECTED":!process_valid?error_prefix+"_PROCESS_REJECTED":"SUCCESS"},
        {"failure",!valid?clearance->last_failure:process->last_failure},
        {"native_solver_calls",J::object()},{"scene_import_s",import_s},{"checked_states",1},
        {"task_id",task},{"parent_stage_id",parent},{"target_id",target},
        {"target_attached",true},{"target_in_world",false},
        {"target_world_pose",serial(attached->getGlobalCollisionBodyTransforms().at(0))},
        {"free_space_rules_restored",true},{"planning_only_status","PLANNING_ONLY_NOT_EXECUTABLE"}};
    }
    if(op=="check_receiver_state") {
      if(receiver_binding.is_null() || !planning_only || planning_mode!="cold_from_scratch" ||
         req.at("stage")!="pregrasp" || !req.at("attachment").is_null() ||
         req.at("process_policy").at("target_id")!=receiver_binding.at("target_id"))
        throw std::runtime_error("RECEIVER_PROBE_SCOPE_INVALID");
      size_t matching=0;
      for(const auto& b:req.at("world"))if(b.at("id")=="conveyor_transverse") {
        if(b!=receiver_binding.at("low") && b!=receiver_binding.at("high"))throw std::runtime_error("RECEIVER_PROBE_CONTEXT_CHANGED");
        ++matching;
      }
      if(matching!=1)throw std::runtime_error("RECEIVER_PROBE_IDENTITY_INVALID");
      const bool valid=clearance->check(scene->getCurrentState());
      return {{"status",valid?"SUCCESS":"RECEIVER_STATE_REJECTED"},
        {"failure",clearance->last_failure},{"checked_states",1},{"native_solver_calls",J::object()},
        {"scene_import_s",import_s},{"planning_only_status","PLANNING_ONLY_NOT_EXECUTABLE"}};
    }
    if(op=="check_start") {
      if(!planning_only || planning_mode!="cold_from_scratch" || req.at("stage")!="pregrasp" ||
         !req.at("attachment").is_null()) throw std::runtime_error("CHECK_START_SCOPE_INVALID");
      const bool valid=clearance->check(scene->getCurrentState());
      const bool process_valid=valid && (!process || process->check(scene->getCurrentState()));
      return {{"status",!valid?"INVALID_START_CLEARANCE":!process_valid?"INVALID_START_PROCESS":"SUCCESS"},
        {"failure",!valid?clearance->last_failure:process?process->last_failure:J(nullptr)},
        {"native_solver_calls",J::object()},{"scene_import_s",import_s},
        {"checked_states",1},{"planning_only_status","PLANNING_ONLY_NOT_EXECUTABLE"}};
    }
    if(op=="build_static_prior") {
      checkPriorContext(req);
      for(const auto& body:req.at("world")) {
        const auto category=body.value("category",std::string());
        if(category=="carton" || category=="payload") throw std::runtime_error("PRIOR_BUILD_REQUIRES_STATIC_WORLD");
      }
      auto result=m710::StaticPriorGraph::build(req,scene,*clearance);result["scene_import_s"]=import_s;return result;
    }
    auto path_check=[&](const J& path) {return clearance->checkPath(scene->getCurrentState(),path,req.at("clearance_policy").at("edge_resolution_rad"));};
    if(op=="validate") {
      if(req.contains("probe_states")) {
        J results=J::array();auto probe=scene->getCurrentState();clearance->phase="fixed_set";
        const auto t=Clock::now();double legacy_s=0;size_t legacy_queries=0;
        for(const auto& row:req.at("probe_states")) {
          auto values=row.get<std::vector<double>>();
          if(values.size()!=names.size()) throw std::runtime_error("INVALID_PROBE_STATE");
          for(double x:values) if(!std::isfinite(x)) throw std::runtime_error("INVALID_PROBE_STATE");
          probe.setJointGroupPositions("manipulator",values);probe.update();
          auto one=Clock::now();const bool clearance_valid=clearance->check(probe);
          const bool process_valid=!process || process->check(probe,true);const bool valid=clearance_valid&&process_valid;double check_s=seconds(one);
          const J failure=clearance_valid&&process?process->last_failure:clearance->last_failure;
          collision_detection::CollisionRequest cr;collision_detection::CollisionResult collision;
          auto lt=Clock::now();scene->checkCollision(cr,collision,probe);legacy_s+=seconds(lt);++legacy_queries;
          results.push_back({{"valid",valid},{"failure",failure},{"process_valid",process_valid},{"check_s",check_s},{"legacy_intersection_valid",!collision.collision}});
        }
        return {{"status","SUCCESS"},{"states",results},{"clearance",clearance->evidence()},{"process_policy_evidence",process?process->evidence():J(nullptr)},
          {"legacy_intersection_s",legacy_s},{"legacy_intersection_queries",legacy_queries},{"batch_s",seconds(t)}};
      }
      collision_detection::CollisionRequest old_request;old_request.contacts=true;old_request.max_contacts=20;
      collision_detection::CollisionResult old_result;scene->checkCollision(old_request,old_result);
      clearance->phase="diagnostic";
      const bool clearance_valid=clearance->check(scene->getCurrentState());const J failure=clearance->last_failure;
      const bool process_valid=!process || process->check(scene->getCurrentState(),true);
      const J process_failure=process?process->last_failure:J(nullptr);
      J path_failure=nullptr,process_path_failure=nullptr;if(req.contains("probe_path")) {clearance->phase="output";path_failure=path_check(req.at("probe_path"));
        if(process) process_path_failure=process->checkPath(scene->getCurrentState(),req.at("probe_path"),req.at("clearance_policy").at("edge_resolution_rad"));}
      return {{"status","SUCCESS"},{"legacy_intersection_valid",!old_result.collision},{"native_valid",clearance_valid&&process_valid},
        {"failure",failure},{"path_failure",path_failure},{"clearance",clearance->evidence()},
        {"process_valid",process_valid},{"process_failure",process_failure},{"process_path_failure",process_path_failure},{"process_policy_evidence",process?process->evidence():J(nullptr)},
        {"world_count",scene->getWorld()->size()},{"attached_id",attached_id},{"pipeline_calls",calls}};
    }
    if(op=="plan" || op=="diagnostic_connection") {
      if(!clearance->check(scene->getCurrentState())) return {{"status","INVALID_START_CLEARANCE"},{"failure",clearance->last_failure},{"clearance",clearance->evidence()},{"pipeline_calls",calls}};
      if(process && !process->check(scene->getCurrentState())) return {{"status","INVALID_START_PROCESS"},{"failure",process->last_failure},{"process_policy",process->evidence()},{"pipeline_calls",calls}};
      if(req.contains("q_goal")) {
        auto goal=req.at("q_goal").get<std::vector<double>>();
        if(goal.size()!=names.size()) throw std::runtime_error("INVALID_GOAL");
        for(double x:goal) if(!std::isfinite(x)) throw std::runtime_error("INVALID_GOAL");
        auto end=scene->getCurrentState();end.setJointGroupPositions("manipulator",goal);end.update();
        if(!clearance->check(end)) return {{"status","INVALID_GOAL_CLEARANCE"},{"failure",clearance->last_failure},{"clearance",clearance->evidence()},{"pipeline_calls",calls}};
        if(process && !process->check(end,true)) return {{"status","INVALID_GOAL_PROCESS"},{"failure",process->last_failure},{"process_policy",process->evidence()},{"pipeline_calls",calls}};
      }
    }
    collision_detection::CollisionRequest cr; cr.contacts=true; cr.max_contacts=20;
    collision_detection::CollisionResult collision; scene->checkCollision(cr,collision);
    if(collision.collision) {
      J pairs=J::array();for(auto& p:collision.contacts) pairs.push_back({p.first.first,p.first.second});
      return {{"status","INVALID_START_COLLISION"},{"collision_pairs",pairs},{"scene_import_s",import_s}};
    }
    if(op=="compose") {
      if(req.value("require_native_motion",false)) throw std::runtime_error("NATIVE_COLD_COMPOSITION_FORBIDDEN");
      mtc::Task task("",false);task.setRobotModel(model);task.setName("checked_complete_cycle");
      auto initial=std::make_unique<mtc::stages::FixedState>("frozen_start");initial->setState(scene);task.add(std::move(initial));
      for(const auto& spec:req.at("stages")) task.add(std::make_unique<CheckedProcessStage>(spec));
      task.plan(1);if(task.solutions().empty()) throw std::runtime_error("MTC_COMPOSITION_FAILED");
      const auto& last=task.solutions().front()->end()->scene();std::vector<std::string> attached;
      std::vector<const moveit::core::AttachedBody*> bodies; last->getCurrentState().getAttachedBodies(bodies); for(const auto* body:bodies) attached.push_back(body->getName());
      return {{"status","SUCCESS"},{"stage_count",req.at("stages").size()}, {"world_count",last->getWorld()->size()},
        {"attached_objects",attached},{"mtc_composition_s",seconds(begin)},{"physical_execution","NOT_RUN"}};
    }
    if(req.value("require_native_motion",false)) return nativeTaskPlan(req,scene,clearance,process,op=="diagnostic_connection");
    const auto pipeline=req.at("pipeline_id").get<std::string>(); const auto planner=req.at("planner_id").get<std::string>();
    if(!pipelines.count(pipeline) || !((pipeline=="ompl"&&planner=="RRTConnectkConfigDefault") ||
       (pipeline=="pilz_industrial_motion_planner"&&(planner=="PTP"||planner=="LIN")))) throw std::runtime_error("PLANNER_UNAVAILABLE");
    auto solver=std::make_shared<CountedPlanner>(pipelines.at(pipeline),calls[pipeline+"/"+planner]);
    solver->setProperty("goal_joint_tolerance",1e-12);
    solver->setProperty("goal_position_tolerance",m710::kNativeGoalPositionToleranceM);
    solver->setProperty("goal_orientation_tolerance",m710::kNativeGoalOrientationToleranceRad);
    solver->setPlannerId(planner);solver->setProperty("max_velocity_scaling_factor",req.at("velocity_scale").get<double>());
    solver->setProperty("max_acceleration_scaling_factor",req.at("acceleration_scale").get<double>());
    mtc::Task task("",false);task.setRobotModel(model);task.setName(req.at("stage"));
    auto initial=std::make_unique<mtc::stages::FixedState>("frozen_start"); initial->setState(scene);task.add(std::move(initial));
    auto motion=std::make_unique<mtc::stages::MoveTo>(req.at("stage"),solver);motion->setGroup("manipulator");
    motion->setTimeout(req.at("allowed_planning_time_s").get<double>());
    if(req.contains("goal_pose")) {
      if(req.at("flange_from_task_tcp")!=identity.at("flange_from_task_tcp")) throw std::runtime_error("TASK_TCP_CONTEXT_MISMATCH");
      const std::string tcp=identity.at("task_tcp_link");
      if(!model->getLinkModel(tcp) || !model->getJointModelGroup("manipulator")->canSetStateFromIK(tcp)) throw std::runtime_error("TASK_TCP_IK_UNAVAILABLE");
      motion->setIKFrame(Eigen::Isometry3d::Identity(),tcp);
      geometry_msgs::msg::PoseStamped target;target.header.frame_id="world";target.pose=pose(req.at("goal_pose"));motion->setGoal(target);
    } else {
      auto goal=req.at("q_goal").get<std::vector<double>>();if(goal.size()!=names.size()) throw std::runtime_error("INVALID_GOAL");
      std::map<std::string,double> joints;for(size_t i=0;i<names.size();++i) joints[names[i]]=goal[i];motion->setGoal(joints);
    }
    auto* motion_stage=motion.get();
    task.add(std::move(motion)); auto planning=Clock::now(); ++requests; clearance->phase="search"; task.plan(1);double plan_s=seconds(planning);
    J out={{"status","SEARCH_EXHAUSTED"},{"pipeline_id",pipeline},{"planner_id",planner},{"mtc_attempt_index",requests},{"pipeline_calls",calls},
      {"scene_import_s",import_s},{"scene_updated",changed},{"mtc_plan_s",plan_s},{"world_count",scene->getWorld()->size()},
      {"attached_id",attached_id},{"task_tcp_identity",identity.at("task_tcp_fingerprint")},{"interpolated_link",req.contains("goal_pose")?identity.at("task_tcp_link"):J(nullptr)},
      {"resident_seed",seed},{"request_seed",req.at("seed")},{"authoritative_status","NOT_RUN"}};
    if(task.solutions().empty()) {
      if(pipeline=="pilz_industrial_motion_planner") out["status"]="NATIVE_PLANNING_FAILED";
      std::ostringstream why; task.explainFailure(why);out["detail"]=why.str(); J failures=J::array();for(const auto& failure:motion_stage->failures()) failures.push_back(failure->comment());out["failure_comments"]=failures;
      for(const auto& item:failures) {
        const auto message=item.get<std::string>();
        if(message.find("NO_IK_SOLUTION")!=std::string::npos) out["status"]="NATIVE_IK_FAILED";
        else if(message.find("INVALID_MOTION_PLAN")!=std::string::npos) out["status"]="NATIVE_INVALID_MOTION_PLAN";
      }return out;}
    moveit_task_constructor_msgs::msg::Solution msg;task.solutions().front()->toMsg(msg);
    J points=J::array();
    for(auto& sub:msg.sub_trajectory) {
      auto& jt=sub.trajectory.joint_trajectory; if(jt.points.empty()) continue;
      if(jt.joint_names!=names) throw std::runtime_error("OUTPUT_JOINT_ORDER_MISMATCH");
      if(pipeline=="ompl") {
        robot_trajectory::RobotTrajectory rt(model,"manipulator");rt.setRobotTrajectoryMsg(scene->getCurrentState(),sub.trajectory);
        trajectory_processing::IterativeParabolicTimeParameterization iptp;
        if(!iptp.computeTimeStamps(rt,req.at("velocity_scale").get<double>(),req.at("acceleration_scale").get<double>())) throw std::runtime_error("TIME_PARAMETERIZATION_FAILED");
        rt.getRobotTrajectoryMsg(sub.trajectory);
      }
      for(auto& p:sub.trajectory.joint_trajectory.points) points.push_back({{"q",p.positions},{"v",p.velocities},{"a",p.accelerations},
        {"t",p.time_from_start.sec+p.time_from_start.nanosec*1e-9}});
    }
    clearance->phase="output"; J path=J::array();for(const auto& p:points) path.push_back(p.at("q"));
    auto output_check=Clock::now();J native_failure=path_check(path);
    out["native_output_check_s"]=seconds(output_check);out["clearance"]=clearance->evidence();
    if(!native_failure.is_null()) {out["status"]="NATIVE_PATH_REJECTED";out["failure"]=native_failure;out["points"]=points;out["total_s"]=seconds(begin);return out;}
    out["native_output_status"]="PASS";
    out["status"]="SUCCESS";out["points"]=points;out["joint_names"]=names;out["total_s"]=seconds(begin);
    out["time_parameterization"]=pipeline=="ompl"?"IPTP_preserves_waypoints":"Pilz_original";return out;
  }
};
#ifndef M710_NATIVE_WORKER_NO_MAIN
int main(int argc,char**argv) {
  setenv("RCUTILS_LOGGING_USE_STDOUT","0",1);rclcpp::init(argc,argv);std::map<std::string,std::unique_ptr<Worker>> workers;std::map<std::string,J> startups,init_requests;std::string line;
  while(std::getline(std::cin,line)) {
    J req,answer;try {req=J::parse(line); auto* protocol=std::cout.rdbuf(std::cerr.rdbuf()); try {const auto key=req.at("identity").dump();
      J init_content=req;init_content.erase("request_id");
      if(req.at("op")=="init" && startups.count(key)) {
        if(init_content!=init_requests.at(key)) throw std::runtime_error("CONTEXT_IDENTITY_REUSED_WITH_DIFFERENT_CONTENT");
        answer=startups.at(key);answer["context_reused"]=true;
      }
      else {
        if(req.at("op")=="init") {
          if(workers.size()>=4) throw std::runtime_error("UNSUPPORTED_RESIDENT_CONTEXT_CAPACITY");
          workers[key]=std::make_unique<Worker>();
        }
        if(!workers.count(key)) throw std::runtime_error("UNKNOWN_MODEL_TCP_CONTEXT");
        answer=workers.at(key)->run(req);
        if(req.at("op")=="init") {answer["context_reused"]=false;startups[key]=answer;init_requests[key]=init_content;}
      }} catch(...) {std::cout.rdbuf(protocol);throw;} std::cout.rdbuf(protocol);} catch(const std::exception& e) {answer={{"status","ERROR"},{"detail",e.what()}};}
    if(req.is_object() && (req.value("op",std::string())=="plan" ||
        req.value("op",std::string())=="diagnostic_connection" || req.value("op",std::string())=="validate"))
      m710::completeRequestEvidence(answer,false,false,[]{return J(nullptr);},[]{return J(nullptr);});
    answer["request_id"]=req.value("request_id",std::string());std::cout<<answer.dump()<<std::endl;
  }
  rclcpp::shutdown();return 0;
}

#endif  // M710_NATIVE_WORKER_NO_MAIN
