from __future__ import annotations

import copy
from pathlib import Path
from types import SimpleNamespace
from time import perf_counter

import numpy as np
import pytest

from unloading_sim.geometry import OBB
from unloading_sim.layout_trajectory import (
    ExactM710LayoutStateValidator,
    LayoutTrajectoryBudget,
    LayoutTrajectoryConnector,
    _audit_official_srdf_policy,
    validate_layout_trajectory_stage_contract,
)
from unloading_sim.robot import CollisionResult


def _segment() -> dict:
    path = [[0.01 * index, 0.0, 0.0, 0.0, 0.0, 0.0] for index in range(8)]
    identity = np.eye(4)
    mask = [True] + [False] * 71
    return {
        "schema": "m710id70_layout_complete_trajectory_segment_v1",
        "target": "carton_l07_c02",
        "face": "top",
        "path": path,
        "grasp_index": 2,
        "release_index": 6,
        "release_retreat_index": 7,
        "stage_ranges": {
            "home": [0, 0],
            "pregrasp": [0, 1],
            "contact": [1, 2],
            "support-release": [2, 3],
            "extraction": [3, 4],
            "transit": [4, 5],
            "place": [5, 6],
            "withdrawal": [6, 7],
        },
        "events": [
            {"index": 2, "event": "ATTACH"},
            {"index": 6, "event": "RELEASE"},
            {"index": 7, "event": "RELEASE_RETREAT_COMPLETE"},
        ],
        "contact": {
            "requested_virtual_task_tcp_pose_world": identity.tolist(),
            "requested_physical_contact_pose_world": identity.tolist(),
            "actual_q_rad": path[2].copy(),
            "actual_virtual_task_tcp_pose_world": identity.tolist(),
            "actual_physical_contact_pose_world": identity.tolist(),
            "physical_contact_from_box": identity.tolist(),
            "cup_selection": {
                "suction_mode": "ideal_independent_cups",
                "load_bearing_minimum_cup_count": None,
                "actual_contact_count": 1,
                "commanded_active_count": 1,
                "target_id": "carton_l07_c02",
                "target_face": "top",
                "geometrically_eligible_mask": mask.copy(),
                "commanded_active_mask": mask.copy(),
                "actual_contact_mask": mask.copy(),
                "actual_q_rad": path[2].copy(),
                "actual_virtual_task_tcp_pose_world": identity.tolist(),
                "actual_physical_contact_pose_world": identity.tolist(),
                "enforce_vacuum_force_capacity": False,
                "enforce_vacuum_break_force": False,
                "enforce_vacuum_break_torque": False,
            },
        },
        "place": {
            "receiver": "conveyor_transverse",
            "place_surface": "conveyor_transverse",
            "release_center_world_m": [0.0, 0.0, 0.0],
            "actual_box_pose_world": identity.tolist(),
            "support": {"supported": True},
        },
        "validation": {"execution_qualified": True},
    }


def test_complete_segment_requires_all_contiguous_stages_and_exact_events():
    segment = _segment()
    assert validate_layout_trajectory_stage_contract(segment) is segment

    missing = copy.deepcopy(segment)
    del missing["stage_ranges"]["support-release"]
    with pytest.raises(ValueError, match="eight required stages"):
        validate_layout_trajectory_stage_contract(missing)

    branch_switch = copy.deepcopy(segment)
    branch_switch["stage_ranges"]["transit"][0] -= 1
    with pytest.raises(ValueError, match="not contiguous"):
        validate_layout_trajectory_stage_contract(branch_switch)

    reordered = copy.deepcopy(segment)
    reordered["events"].reverse()
    with pytest.raises(ValueError, match="three ordered"):
        validate_layout_trajectory_stage_contract(reordered)


def test_complete_segment_rejects_empty_cup_attachment_and_wrong_actual_q():
    segment = _segment()
    segment["contact"]["cup_selection"]["actual_contact_count"] = 0
    with pytest.raises(ValueError, match="non-empty ideal cup"):
        validate_layout_trajectory_stage_contract(segment)

    segment = _segment()
    segment["contact"]["actual_q_rad"][0] += 0.1
    with pytest.raises(ValueError, match="must equal the grasp"):
        validate_layout_trajectory_stage_contract(segment)


def test_complete_segment_rejects_cup_mask_or_nested_actual_pose_tampering():
    segment = _segment()
    segment["contact"]["cup_selection"]["actual_contact_mask"][1] = True
    with pytest.raises(ValueError, match="counts, target, or enforcement"):
        validate_layout_trajectory_stage_contract(segment)
    segment = _segment()
    segment["contact"]["cup_selection"][
        "actual_physical_contact_pose_world"
    ][0][3] = 0.001
    with pytest.raises(ValueError, match="disagrees with contact evidence"):
        validate_layout_trajectory_stage_contract(segment)


def test_adaptive_contract_omits_pregrasp_and_support_lift_and_accepts_real_drop_prediction():
    from unloading_sim.conveyor_placement import PLACEMENT_SEMANTICS
    from unloading_sim.release_motion import MOTION_SEMANTICS, SHORT_DROP_RELEASE, predict_release
    segment = _segment()
    segment.update(motion_semantics=MOTION_SEMANTICS, placement_semantics=PLACEMENT_SEMANTICS)
    del segment["stage_ranges"]["pregrasp"]
    del segment["stage_ranges"]["support-release"]
    segment["stage_ranges"]["contact"][0] = 0
    segment["stage_ranges"]["extraction"][0] = 2
    box = OBB([0, 0, .775], [.3, .2, .15], np.eye(3), segment["target"], "carton")
    belt = OBB([0, 0, .3], [1, 1, .3], np.eye(3), "conveyor_transverse", "conveyor")
    prediction = predict_release(box, [belt], mode=SHORT_DROP_RELEASE)
    segment["place"].update(release_mode=SHORT_DROP_RELEASE, release_prediction=prediction,
        support=prediction["actual_support"], actual_box_pose_world=box.world_from_local.tolist(),
        release_center_world_m=box.center.tolist())
    validate_layout_trajectory_stage_contract(segment)
    segment["place"]["release_prediction"]["predicted_landing_pose_world"][0][3] += .01
    with pytest.raises(ValueError, match="disagrees"):
        validate_layout_trajectory_stage_contract(segment)

class _Robot:
    dof = 6
    joint_limits = np.tile([-2.0, 2.0], (6, 1))
    base_transform = np.eye(4)

    def within_limits(self, q, tolerance=1e-9):
        q = np.asarray(q)
        return q.shape == (6,) and np.all(np.abs(q) <= 2.0 + tolerance)

    def fk(self, q):
        result = np.eye(4)
        result[:3, 3] = np.asarray(q)[:3]
        return result

    def geometric_jacobian(self, q):
        return np.eye(6)

    def named_link_frames(self, q):
        return {"flange": self.fk(q)}

    def tool_collision_obbs(self, q):
        return []


class _ScriptedConnector(LayoutTrajectoryConnector):
    def _plan_branch(self, **kwargs):
        q = np.asarray(kwargs["grasp_q"])
        if q[0] < 0.5:
            return None, {"reason": "FIRST_BRANCH_DISCONNECTED", "stage": "transit"}, {
                "seed": kwargs["seed"]
            }
        # Synthetic branch fixture still exercises the real final contract and
        # completion binding; it does not represent checked robot geometry.
        segment = _segment()
        segment["target"] = kwargs["target"].name
        segment["contact"]["cup_selection"]["target_id"] = kwargs["target"].name
        failure = self._finalize_task(segment,
            [box for box in kwargs["all_obstacles"] if box.name != kwargs["target"].name]
            + [kwargs["target"]], kwargs["target"])
        return segment if failure is None else None, failure, {"seed": kwargs["seed"]}


def test_grasp_branch_search_is_lazy_bounded_and_backtracks_to_alternative():
    connector = _ScriptedConnector(
        _Robot(),
        lambda *args, **kwargs: None,
        flange_from_virtual_task_tcp=np.eye(4),
        flange_from_physical_contact=np.eye(4),
        ik_policy={"position_tolerance_m": .001, "orientation_tolerance_rad": .01},
        collision_margin_m=0.01,
        contact_tolerance_m=0.0002,
        joint_margin_rad=0.01,
        maximum_jacobian_condition=1e4,
        validator_identity="synthetic_exact_validator",
        execution_qualified=True,
    )
    candidates = [
        {"candidate_id": index, "q_rad": [float(index), 0, 0, 0, 0, 0]}
        for index in range(5)
    ]
    outcome = connector.plan(
        target=OBB([0, 0, 1], [0.3, 0.2, 0.15], np.eye(3), "target", "carton"),
        face="top",
        requested_virtual_contact=np.eye(4),
        grasp_candidates=candidates,
        home_q=np.zeros(6),
        all_obstacles=[],
        receiver=OBB([1, 0, 0.5], [0.5, 0.5, 0.1], np.eye(3), "receiver", "conveyor"),
        support_names=[],
        suction={},
        seed=10,
    )
    assert outcome.success
    assert len(outcome.attempts) == 2
    assert [attempt["success"] for attempt in outcome.attempts] == [False, True]
    assert outcome.attempts[0]["trace"]["seed"] == 10
    assert outcome.attempts[1]["trace"]["seed"] == 10010


class _CountingCandidateStream:
    def __init__(self):
        self.next_calls = 0

    def __iter__(self):
        return self

    def __next__(self):
        self.next_calls += 1
        return SimpleNamespace(
            q=np.full(6, 0.1 * self.next_calls),
            position_error=0.0,
            orientation_error=0.0,
            search_evidence={"candidate_id": f"candidate_{self.next_calls}"},
        )

    def evidence(self):
        return {
            "seeds_attempted": self.next_calls,
            "iterations_consumed": self.next_calls,
        }


class _LazyConnectionConnector(LayoutTrajectoryConnector):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.stream = _CountingCandidateStream()

    def _ik_stream(self, *args, **kwargs):
        return self.stream

    def _transit(self, start, goal, obstacles, **kwargs):
        return [], {"reason": "DISCONNECTED", "stage": kwargs["stage"]}, {
            "planning_iterations_consumed": 1,
        }


def test_stage_connection_limit_does_not_prefetch_an_unused_ik_candidate():
    connector = _LazyConnectionConnector(
        _Robot(),
        lambda *args, **kwargs: None,
        flange_from_virtual_task_tcp=np.eye(4),
        flange_from_physical_contact=np.eye(4),
        ik_policy={"position_tolerance_m": .001, "orientation_tolerance_rad": .01},
        collision_margin_m=0.01,
        contact_tolerance_m=0.0002,
        joint_margin_rad=0.01,
        maximum_jacobian_condition=1e4,
        validator_identity="synthetic_exact_validator",
        execution_qualified=True,
    )
    selected, path, failure, evidence = connector._connect_pose(
        np.eye(4),
        [np.zeros(6)],
        np.zeros(6),
        [],
        ik_seed=1,
        connection_seed=2,
        stage="transit",
    purpose="FREE_APPROACH")
    assert selected is None and path == []
    assert failure["reason"] == "DISCONNECTED"
    # The legacy candidate message is retained, but bounded search is not an
    # infeasibility proof. Scheduling remains lazy and within its original cap.
    assert failure['validation']['status'] == evidence['validation_status'] == 'INDETERMINATE'
    assert failure['validation']['can_continue_candidates']
    assert connector.stream.next_calls == connector.budget.stage_connection_attempts
    assert len(evidence["attempts"]) == connector.budget.stage_connection_attempts


def test_request_scoped_state_cache_and_wall_deadline_are_fail_closed():
    calls = []
    connector = LayoutTrajectoryConnector(
        _Robot(),
        lambda *args, **kwargs: calls.append(np.asarray(args[0]).copy()) or None,
        flange_from_virtual_task_tcp=np.eye(4),
        flange_from_physical_contact=np.eye(4),
        ik_policy={"position_tolerance_m": .001, "orientation_tolerance_rad": .01}, collision_margin_m=0.01, contact_tolerance_m=0.0002,
        joint_margin_rad=0.01, maximum_jacobian_condition=1e4,
        validator_identity="synthetic_exact_validator", execution_qualified=True,
        budget=LayoutTrajectoryBudget(planning_wall_time_s=1.0),
    )
    connector.start_planning_request()
    assert connector.validate_unloaded_state(np.zeros(6), [], stage="same") is None
    assert connector.validate_unloaded_state(np.zeros(6), [], stage="same") is None
    assert len(calls) == 1
    assert connector._statistics["state_cache_hits"] == 1
    assert connector.validate_unloaded_state(np.zeros(6), [], stage="different") is None
    assert len(calls) == 2
    assert connector._statistics["state_cache_misses"] == 2
    connector.start_planning_request(perf_counter() - 2.0)
    failure = connector.validate_unloaded_state(np.zeros(6), [], stage="expired")
    assert failure["reason"] == "PLANNING_WALL_CLOCK_DEADLINE"


def test_official_srdf_policy_has_only_six_adjacent_exclusions(tmp_path):
    root = Path(__file__).resolve().parents[1]
    source = (
        root
        / "assets/robots/fanuc_m710id_70/official/m710id_70_official.srdf"
    )
    evidence = _audit_official_srdf_policy(source)
    assert len(evidence["disabled_self_collision_pairs"]) == 6
    assert evidence["non_adjacent_exclusions_allowed"] is False

    tampered = tmp_path / "tampered.srdf"
    tampered.write_text(
        source.read_text(encoding="utf-8").replace(
            "link1=\"base_link\" link2=\"J1_link\"",
            "link1=\"base_link\" link2=\"J6_link\"",
        ),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="fixed adjacent pairs"):
        _audit_official_srdf_policy(tampered)


class _RecordingMeshRobot:
    dof = 6

    def __init__(self):
        self.calls = []

    def collision_result(self, q, obstacles, **kwargs):
        self.calls.append((tuple(box.name for box in obstacles), kwargs))
        return CollisionResult(False)


class _CompoundToolRobot:
    def tool_all_physical_obbs(self, q):
        return self.tool_collision_obbs(q)

    def tool_compliant_collision_obbs(self, q):
        return []

    def tool_collision_obbs(self, q):
        return [
            OBB([0.01 * index, 0, 1], [0.001, 0.001, 0.001], np.eye(3), f"tool_rigid_{index}", "robot")
            for index in range(58)
        ]


def test_exact_validator_retains_target_and_limits_exceptions_to_mount_pairs():
    mesh = _RecordingMeshRobot()
    validator = ExactM710LayoutStateValidator(
        mesh,
        _CompoundToolRobot(),
        collision_margin_m=0.01,
        floor_z_m=0.0,
        right_wall_y_m=-2.0,
        left_wall_y_m=2.0,
        robot_world_boxes=lambda q: [],
        collision_policy={"wrist_tool_exempt_links": ["J5_link", "J6_link"]},
    )
    target = OBB([3, 0, 1], [0.2, 0.2, 0.2], np.eye(3), "target", "carton")
    assert validator(
        np.zeros(6), [target], payload=None, target_contact=target, stage="contact"
    ) is None
    assert mesh.calls[0][0] == ()  # Immutable environment/self check.
    assert mesh.calls[0][1]["ignored_geometry_obstacle_pairs"] == {
        ("base_link", "chassis")
    }
    assert len(mesh.calls[1][0]) == 58
    assert mesh.calls[1][1]["ignored_geometry_obstacle_pairs"] == {
        (link, f"tool_rigid_{index}")
        for link in ("J5_link", "J6_link")
        for index in range(58)
    }
    assert mesh.calls[2][0] == ("target",)
    assert not mesh.calls[2][1].get("ignored_geometry_obstacle_pairs")
    # Reusing the same joints must still check a carton's new measured pose.
    moved = OBB([0, 0, 1], target.half_extents, np.eye(3), "target", "carton")
    failure = validator(np.zeros(6), [moved], payload=None,
                        target_contact=moved, stage="contact")
    assert failure["reason"] == "RIGID_TOOL_COLLISION"
    assert mesh.calls[-1][0] == ("target",)


def test_exact_validator_never_uses_contact_as_a_rigid_tool_collision_waiver():
    validator = ExactM710LayoutStateValidator(
        _RecordingMeshRobot(),
        _CompoundToolRobot(),
        collision_margin_m=0.01,
        floor_z_m=0.0,
        right_wall_y_m=-2.0,
        left_wall_y_m=2.0,
        robot_world_boxes=lambda q: [],
    )
    target = OBB([0, 0, 1], [0.02, 0.02, 0.02], np.eye(3), "target", "carton")
    failure = validator(
        np.zeros(6), [target], payload=None, target_contact=target, stage="contact"
    )
    assert failure == {
        "reason": "RIGID_TOOL_COLLISION",
        "pair": ["tool_rigid_0", "target"],
    }
