import json
from pathlib import Path
root=Path('/mount-formal-v1')
for variant,target in [('baseline','carton_l06_c02'),('baseline','carton_l06_c03'),('y_minus_100','carton_l06_c03'),('baseline','carton_l06_c00')]:
    run=root/variant/target/'seed-71070'
    result=json.loads((run/'result.json').read_text())
    print(variant,target)
    for a in result['attempts']:
        if 'folder' not in a:continue
        folder=run/a['folder']
        calls=json.loads((folder/'requests.json').read_text())
        plans=[c for c in calls if c['op']=='plan']
        print(a['folder'],'last_motion_calls', [{k:c.get(k) for k in ('stage','stage_id','status','op','planner_id')} for c in plans[-4:]])
        if plans:
            last=plans[-1]
            print('last_response', {k:v for k,v in last['response'].items() if k in ('failure','failure_reason','status','moveit_error_code','message','solver_message','error_code')})
        p=folder/'receiver-region-search.json'
        if p.exists():
            data=json.loads(p.read_text())
            print('receiver-search',str(data)[:1000])
