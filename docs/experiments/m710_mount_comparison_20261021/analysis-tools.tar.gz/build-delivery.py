"""Package this measured comparison; no planning or geometry synthesis."""
from pathlib import Path
from collections import Counter
import html,json,hashlib,tarfile,zipfile,shutil

ROOT=Path(__file__).resolve().parents[2]
E=ROOT/'docs/experiments/m710_mount_comparison_20261021'
A=ROOT/'artifacts/m710_mount_20261021'
v=json.loads((E/'verification.json').read_text())
s=json.loads((E/'summary.json').read_text())
def save(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
counts=Counter();lineage=Counter();cells=[]
for r in v['rows']:
    counts.update(r['counts'])
    lineage.update({k:r['verification']['runs'][0][k] for k in ('native_stages','coupled_native_samples','nominal_drop_samples')})
    cells.append(dict(variant=r['variant'],target_id=r['target_id'],completed=r['complete'],
        wall_s=r['wall_s'],dispatched_candidates=sum('folder'in a for a in r['attempts']),
        unsearched_option_count=sum(a.get('unsearched_option_count',0) for a in r['attempts']),
        attempts=[dict(folder=a['folder'],complete=a['complete'],wall_s=a['wall_s']) for a in r['attempts'] if 'folder'in a]))
save(E/'costs.json',dict(experiment_wall_s=s['experiment_wall_s'],
    task_wall_s=sum(r['wall_s'] for r in v['rows']),
    candidate_wall_s=sum(a['wall_s'] for r in v['rows'] for a in r['attempts'] if 'folder'in a),
    costs_are_nested_not_additive=True,dispatched_candidates=sum(c['dispatched_candidates'] for c in cells),
    request_counts=dict(counts),accepted_lineage_counts=dict(lineage),cells=cells))

labels={'baseline':'原位','y_minus_100':'仅右移 −Y 100 mm','x_minus_100':'仅后移 −X 100 mm','xy_minus_100':'右移并后移各 100 mm'}
failure={('baseline','carton_l06_c02'):'抽离：J2 / 左墙净空 4.359 mm，小于 5 mm；150 个端点后阶段预算到期。另 2 个工艺选项未访问。',
('baseline','carton_l06_c03'):'抽离：345 个端点后阶段预算到期，末次 NO_IK_SOLUTION；没有本次抽离碰撞见证。另 2 个工艺选项未访问。',
('y_minus_100','carton_l06_c03'):'抽离：J3 / 纵带净空 3.623 mm，小于 5 mm；194 个端点后阶段预算到期。另 2 个工艺选项未访问。',
('baseline','carton_l06_c00'):'接触 / Hmin 同步前缀未闭合；J2 / 横带净空 4.351 mm，小于 5 mm；共享前缀到期，271 个选项未访问。'}
offline=A/'offline-replay'
offline.mkdir(exist_ok=True)
with tarfile.open(E/'replays.tar.gz') as t:
    for member in t.getmembers():
        if member.isfile() and member.name.startswith('mount-replays/'):
            dest=offline/Path(member.name).name
            dest.write_bytes(t.extractfile(member).read())
compact=[];body=[]
for target in dict.fromkeys(r['target_id'] for r in v['rows']):
    body.append('<tr><th>'+html.escape(target.replace('carton_',''))+'</th>')
    for variant in labels:
        r=next(r for r in v['rows'] if r['variant']==variant and r['target_id']==target)
        a=r['accepted'];name=variant+'-'+target
        if a:
            detail=f"δ +{a['delta_m']*1000:.3f} mm · {a['cups']}/72 杯<br>接收 {a['receive_height_m']:.2f} m · {a['receive_sync_location']}"
            body.append(f'<td class="pass"><a href="{name}.html">完整成功 · 打开三维回放 ↗</a><p>{r["wall_s"]:.2f} s</p><small>{detail}</small></td>')
        else:
            detail=failure[(variant,target)]
            body.append(f'<td class="fail"><b>未完成</b><p>{r["wall_s"]:.2f} s</p><small>{html.escape(detail)}</small></td>')
        compact.append(dict(variant=variant,target_id=target,complete=r['complete'],wall_s=r['wall_s'],
            accepted=None if a is None else {k:a[k] for k in ('delta_m','temporary_height_m','receive_height_m','receive_sync_location','cups')},
            failure=failure.get((variant,target))))
    body.append('</tr>')
table=''.join(body)
headers=''.join('<th>'+n+f'<br><span>{v["by_layout"][k]["complete"]}/5</span></th>' for k,n in labels.items())
page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>M-710 安装位置对照 · 2026-10-21</title><style>
body{margin:0;background:#101722;color:#e6ecf4;font:16px/1.65 system-ui,"Microsoft YaHei",sans-serif}main{max-width:1320px;margin:auto;padding:40px 28px}h1{font-size:30px;line-height:1.3}p{max-width:1000px}a{color:#83d4ff}table{table-layout:fixed;min-width:1100px;border-collapse:collapse;width:100%;margin:26px 0;font-size:14px}th,td{border:1px solid #384252;padding:14px;text-align:left;vertical-align:top}th{background:#1a2636}th:first-child{width:85px}td p{margin:6px 0}small{color:#becada}.pass{background:#142d2b}.fail{background:#332727}span{font-size:22px;color:#89dfca}.scroll{overflow-x:auto}footer{color:#a5b4c6;border-top:1px solid #384252;padding-top:20px}code{font-size:12px;overflow-wrap:anywhere}
</style><main><p>安装位置对照 / 原生规划 / 2026-10-21</p>
<h1>后移 100 mm：五个代表箱全部完成</h1>
<p>原位 2/5，右移 4/5，后移 5/5，右移并后移 5/5。建议优先采用仅 −X 100 mm 的方案；此次单样本对照没有显示同时右移的额外收益。</p>
<p>每格都是独立的新规划世界。同一箱的四组采用相同初态、seed 和预算，机器人由本格本次原生 q 驱动。成功包含接触、同步、抽离、释放与完整后缀。以下不是连续卸完 20 箱，也不是全体 36 箱的新成功率。</p>
<div class="scroll"><table><thead><tr><th>目标箱</th>'''+headers+'</tr></thead><tbody>'+table+'''</tbody></table></div>
<p>右端 l07_c00 保留原有偏心权限；所有其他目标 δ=0。有效杯采用 ideal_independent_cups 理想吸力足够假设，全部 72 个物理杯保留。箱体下落为名义下落，IDEAL_RECEIVER_DRAIN 为理想清空，未进行物理执行。</p>
<p>回放内机构升降采用展示时长；原生机器人段使用本次轨迹时间，整体回放时长不代表实机周期。四个失败格仅给出实际失败证据，不绘制成功运动。</p>
<p>仅后移方案基座世界原点：[-1.425, 0.350, 0.600] m。底盘、箱堆、输送带和剪叉机构均不移动。最低带高仍为 0.60 m，后移没有解决低层要求 0.55 m 的工艺限制。</p>
<footer><p>实测源码 <code>cf40c1dda5a3fdda9001053289aca29bb5b88785</code></p>
<p>qualification_status=NOT_EVALUATED · continuous_swept_proof=false<br>physical_execution=NOT_RUN · execution_ready=false</p>
<p><a href="results.json">逐格结果 JSON</a> · <a href="costs.json">全部尝试成本</a></p></footer></main></html>'''
(offline/'index.html').write_text(page,encoding='utf-8')
save(offline/'results.json',compact)
shutil.copyfile(E/'costs.json',offline/'costs.json')
save(offline/'file-hashes.json',{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(offline.iterdir()) if p.is_file() and p.name!='file-hashes.json'})
with zipfile.ZipFile(E/'offline-replay.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(offline.iterdir()):
        if p.is_file():z.write(p,p.name)
save(E/'compact-results.json',compact)
print(json.dumps(dict(offline_index=str(offline/'index.html'),accepted_viewers=len(list(offline.glob('*.html')))-1,zip_bytes=(E/'offline-replay.zip').stat().st_size)))
