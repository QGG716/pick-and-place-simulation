from pathlib import Path
import gzip,hashlib,json,lzma,shutil,tarfile,time
base=Path('/root/autodl-tmp/m710-mount-20261021')
started=time.monotonic()
out=base/'formal-raw.tar.xz'
with gzip.open(base/'formal-raw.tar.gz','rb') as source,lzma.open(out,'wb',format=lzma.FORMAT_XZ,filters=[dict(id=lzma.FILTER_LZMA2,preset=6,dict_size=64*1024*1024)]) as dest:
    shutil.copyfileobj(source,dest,1024*1024)
manifest=json.loads((base/'formal-raw-file-hashes.json').read_text())
checked=0
with tarfile.open(out) as t:
    for m in t:
        if m.isfile() and m.name.startswith('mount-formal-v1/'):
            assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==manifest[m.name.removeprefix('mount-formal-v1/')]
            checked+=1
assert checked==len(manifest)
r=dict(file=out.name,bytes=out.stat().st_size,sha256=hashlib.sha256(out.read_bytes()).hexdigest(),file_count=checked,pack_and_verify_s=time.monotonic()-started,
       source_tar_gz_sha256=hashlib.sha256((base/'formal-raw.tar.gz').read_bytes()).hexdigest(),lossless_recompression=True)
(base/'formal-raw-xz-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
