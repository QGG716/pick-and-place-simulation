import json
from pathlib import Path
from export_m710_top_layer_replay import export

run=Path('/mount-formal-v1')
summary=json.loads((run/'summary.json').read_text())
assert summary['status']=='COMPARISON_COMPLETE'
for row in summary['outcomes']:
    if not row['completed_count']:continue
    output=Path('/mount-replays')/(row['variant']+'-'+row['target_id']+'.html')
    if output.exists():
        assert output.with_name(output.stem+'-checks.json').is_file()
        continue
    export(run/row['variant']/row['target_id'],71070,output)
