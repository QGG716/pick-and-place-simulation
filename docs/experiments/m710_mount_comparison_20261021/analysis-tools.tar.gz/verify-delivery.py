"""Verify the exact delivered bytes, including every retained raw run file."""
from pathlib import Path
import hashlib,json,tarfile,zipfile,re
root=Path(__file__).resolve().parents[2]
e=root/'docs/experiments/m710_mount_comparison_20261021'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=json.loads((e/'formal-raw-xz-receipt.json').read_text())
assert sha(e/receipt['file'])==receipt['sha256']
raw={};count=0
with tarfile.open(e/receipt['file']) as t:
    manifest=json.load(t.extractfile('formal-raw-file-hashes.json'))
    for m in t.getmembers():
        if m.isfile() and m.name.startswith('mount-formal-v1/'):
            relative=m.name.removeprefix('mount-formal-v1/')
            data=t.extractfile(m).read()
            assert hashlib.sha256(data).hexdigest()==manifest[relative],relative
            if relative in ('protocol.json','summary.json','verification.json'):
                assert data==(e/relative).read_bytes(),relative
            count+=1
assert count==len(manifest)==receipt['file_count']==342
with tarfile.open(e/'measured-source.tar.gz') as t:
    source_manifest=json.loads((e/'measured-source-manifest.json').read_text())
    for name,h in source_manifest['sha256'].items():
        assert hashlib.sha256(t.extractfile('work-mount-cf40c1d/'+name).read()).hexdigest()==h,name
source=json.loads((e/'source-check.json').read_text())
assert sha(e/'runtime-paired-inputs.json')==source['runtime_inputs_sha256']
assert sha(e/'paired-inputs.json')==source['git_fixture_sha256']
assert json.loads((e/'runtime-paired-inputs.json').read_text())==json.loads((e/'paired-inputs.json').read_text())
with zipfile.ZipFile(e/'offline-replay.zip') as z:
    index=z.read('index.html').decode()
    for name,h in json.loads(z.read('file-hashes.json')).items():
        assert hashlib.sha256(z.read(name)).hexdigest()==h,name
    for name in re.findall(r'href="([^"]+)"',index):assert name in z.namelist(),name
qa=json.loads((e/'browser-checks/summary.json').read_text())
assert qa['status']=='PASS' and qa['viewers']==16
report=dict(status='PASS',raw_files_verified=count,measured_source_manifest_files_verified=len(source_manifest['sha256']),
            decoded_input_identity='PASS',raw_inputs_byte_identity='PASS',offline_bundle_hashes_and_links='PASS',
            browser_viewers_passed=16,production_initial_states_passed=20,focused_regression_tests_passed=24,
            formal_trial_count=20,complete_cycle_count=16,formal_integration_exceptions=0,
            read_only_verifier_sha256=sha(root/'tools/verify_m710_mount_comparison.py'))
(e/'delivery-checks.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
manifest={p.relative_to(e).as_posix():sha(p) for p in sorted(e.rglob('*')) if p.is_file() and p.name!='manifest.json'}
(e/'manifest.json').write_text(json.dumps(dict(source_commit=source['measured_source'],
    report_sha256=sha(root/'docs/m710_mount_comparison_20261021.md'),sha256=manifest),indent=2)+'\n',encoding='utf-8')
print(json.dumps(report))
