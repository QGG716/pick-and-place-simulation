#!/bin/bash
set -euo pipefail
cd /work-mount-cf40c1d
export PYTHONPATH=/work-mount-cf40c1d/tools:/work-mount-cf40c1d/src
export PYTHONNOUSERSITE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
/opt/planning-venv/bin/python /mount-delivery/verify_m710_mount_comparison.py /mount-formal-v1
/opt/planning-venv/bin/python /mount-delivery/export-completed.py
