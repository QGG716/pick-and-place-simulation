from pathlib import Path
import hashlib,json,tarfile
base=Path('/root/autodl-tmp/m710-mount-20261021')
run=base/'rootfs/mount-formal-v1'
assert json.loads((run/'summary.json').read_text())['status']=='COMPARISON_COMPLETE'
assert len(json.loads((run/'verification.json').read_text())['rows'])==20

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

archives={}
for name,folder in [('formal-raw',run),('measured-source',base/'rootfs/work-mount-cf40c1d'),('replays',base/'rootfs/mount-replays')]:
    files=sorted(p for p in folder.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
    manifest={p.relative_to(folder).as_posix():sha(p) for p in files}
    manifest_path=base/(name+'-file-hashes.json')
    manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
    archive=base/(name+'.tar.gz')
    with tarfile.open(archive,'w:gz',compresslevel=3) as tar:
        for p in files:tar.add(p,arcname=folder.name+'/'+p.relative_to(folder).as_posix())
        tar.add(manifest_path,arcname=name+'-file-hashes.json')
    with tarfile.open(archive) as tar:
        for item in tar.getmembers():
            if item.isfile() and item.name.startswith(folder.name+'/'):
                h=hashlib.sha256(tar.extractfile(item).read()).hexdigest()
                assert h==manifest[item.name[len(folder.name)+1:]],item.name
    archives[name]=dict(bytes=archive.stat().st_size,sha256=sha(archive),file_count=len(files))
(base/'archive-receipts.json').write_text(json.dumps(archives,indent=2)+'\n')
print(json.dumps(archives))
