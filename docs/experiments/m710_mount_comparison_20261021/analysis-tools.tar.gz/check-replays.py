from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json,shutil
root=Path(__file__).resolve().parents[2]
art=root/'artifacts/m710_mount_20261021'
evidence=root/'docs/experiments/m710_mount_comparison_20261021/browser-checks'
evidence.mkdir(exist_ok=True)
def check(p):
    output=art/'browser-checks'/p.stem
    if p.stem=='y_minus_100-carton_l06_c02':
        assert p.read_bytes()==(art/'replays'/p.name).read_bytes()
        output=art/'browser-y-c02'
    else:
        output.mkdir(parents=True,exist_ok=True)
        with (output/'check.log').open('w',encoding='utf-8') as log:
            completed=subprocess.run(['node',str(root/'tools/record_m710_top_layer_replay.mjs'),str(p),str(output),
                'C:/Program Files/Google/Chrome/Application/chrome.exe','--check-only'],
                stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        assert completed.returncode==0,p.name
    result=json.loads((output/'browser-checks.json').read_text(encoding='utf-8'))
    assert result['status']=='PASS' and not result['errors']
    shutil.copyfile(output/'browser-checks.json',evidence/(p.stem+'.json'))
    print(p.stem,'PASS',flush=True)
    return p.stem
pages=sorted(p for p in (art/'offline-replay').glob('*.html') if p.name!='index.html')
assert len(pages)==16
with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(check,pages))
(evidence/'summary.json').write_text(json.dumps(dict(status='PASS',viewers=len(results),names=results),indent=2)+'\n',encoding='utf-8')
