#!/bin/bash
set -euo pipefail
round=/root/autodl-tmp/m710-mount-20261021
test ! -e "$round/formal-v1.pid"
test ! -e "$round/rootfs/mount-formal-v1"
date -u +%FT%TZ > "$round/formal-v1-started.txt"
nohup chroot "$round/rootfs" /bin/bash /run-formal.sh > "$round/formal-v1.log" 2>&1 < /dev/null &
echo $! > "$round/formal-v1.pid"
cat "$round/formal-v1.pid"
