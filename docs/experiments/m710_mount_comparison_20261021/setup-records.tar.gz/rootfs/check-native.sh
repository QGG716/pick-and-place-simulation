#!/bin/bash
set -eo pipefail
cd /work-mount-cf40c1d
PYTHONPATH=src /opt/planning-venv/bin/python /native-fixture.py
source /opt/ros/humble/setup.bash
export AMENT_PREFIX_PATH=/mount-install:${AMENT_PREFIX_PATH:-}
export LD_LIBRARY_PATH=/mount-install/lib:/mount-build:${LD_LIBRARY_PATH:-}
/mount-build/m710_coupled_receiver_test /native-fixture.json
/mount-build/m710_concept_solid_test
sha256sum /mount-build/m710_moveit_worker /mount-build/libm710_search_trace.so
