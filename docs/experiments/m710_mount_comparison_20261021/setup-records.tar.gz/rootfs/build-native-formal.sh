#!/bin/bash
set -eo pipefail
source /opt/ros/humble/setup.bash
cmake -S /work-mount-cf40c1d/ros2/m710_moveit_backend -B /mount-build -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=/mount-install
cmake --build /mount-build -j2 --target m710_moveit_worker m710_coupled_receiver_test m710_concept_solid_test
cmake --install /mount-build
/mount-build/m710_coupled_receiver_test
/mount-build/m710_concept_solid_test
sha256sum /mount-build/m710_moveit_worker /mount-build/libm710_search_trace.so
