#!/bin/bash
set -eo pipefail
source /opt/ros/humble/setup.bash
export AMENT_PREFIX_PATH=/mount-install:${AMENT_PREFIX_PATH:-}
export LD_LIBRARY_PATH=/mount-install/lib:/mount-build:${LD_LIBRARY_PATH:-}
exec /mount-build/m710_moveit_worker
