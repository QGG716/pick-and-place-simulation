#!/bin/bash
set -euo pipefail
cd /work-mount-cf40c1d
export PYTHONPATH=src PYTHONNOUSERSITE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export M710_MOVEIT_ASSET_ROOT=/work-mount-cf40c1d
/opt/planning-venv/bin/python tools/plan_m710_mount_comparison.py \
  --inputs docs/experiments/m710_mount_comparison_20261021/paired-inputs.json \
  --output /mount-checks-v3 --check-only \
  --source-commit cf40c1dda5a3fdda9001053289aca29bb5b88785 \
  --source-manifest source-manifest.json
