import json
from pathlib import Path
from unloading_sim.workcell_layout import load_workcell_layout, build_scene_snapshot, load_layout_validation_config
from unloading_sim.coupled_batch import coupled_binding
from unloading_sim.conveyor_lift import coupled_conveyor_state
from unloading_sim.moveit2_backend import box_message
from dataclasses import replace

root=Path('/work-mount-cf40c1d')
layout=load_workcell_layout(root/'configs/workcells/m710id70_unloading_layout_v1_transverse_scissor_026.yaml')
config=load_layout_validation_config(root/'configs/validation/m710id70_layout_poc_pair_clearance.yaml')
snapshot=build_scene_snapshot(replace(config,layout=layout))
binding=coupled_binding(layout,layout.cartons(),1.75,1.45,'carton_l06_c00',snapshot['assembly']['designed_contacts'])
old=load_workcell_layout(root/'configs/workcells/m710id70_unloading_layout_v1_rear_fixed_20261019.yaml')
data=dict(bindings=[binding],releases=[],old_model=dict(height_m=.6,world=[box_message(b) for b in coupled_conveyor_state(old,.6,legacy_geometry=True).boxes]))
Path('/native-fixture.json').write_text(json.dumps(data,separators=(',',':')))
