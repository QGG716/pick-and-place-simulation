#!/bin/bash
set -euo pipefail
round=/root/autodl-tmp/m710-mount-20261021
rootfs=$round/rootfs
cp "$round/ros-snapshot.asc" "$rootfs/usr/share/keyrings/ros-snapshot.asc"
cat > "$rootfs/etc/apt/sources.list" <<'APT'
deb http://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy main universe
deb http://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy-updates main universe
deb http://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy-security main universe
deb [signed-by=/usr/share/keyrings/ros-snapshot.asc] http://snapshots.ros.org/humble/2026-09-14/ubuntu jammy main
APT
cp "$round/ros2/m710_moveit_backend/ros-packages.lock" "$rootfs/ros-packages.lock"
cp "$round/docs/experiments/m710_top_row_retest_20261015/python-lock.txt" "$rootfs/python-lock.txt"
chroot "$rootfs" /bin/bash -c 'export DEBIAN_FRONTEND=noninteractive; mapfile -t packages < /ros-packages.lock; apt-get update && apt-get install -y --no-install-recommends build-essential cmake python3-ament-package python3-empy python3-catkin-pkg python3-venv nlohmann-json3-dev "${packages[@]}"'
chroot "$rootfs" dpkg-query -W > "$round/restored-system-packages.lock"
chroot "$rootfs" /bin/bash -c 'python3 -m venv /opt/planning-venv; /opt/planning-venv/bin/pip install --index-url https://pypi.tuna.tsinghua.edu.cn/simple -r /python-lock.txt; /opt/planning-venv/bin/pip freeze' > "$round/python-restore.log" 2>&1
