#!/bin/bash
set -euo pipefail
cd /work-xy-top-dev
export PYTHONPATH=src PYTHONNOUSERSITE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export M710_MOVEIT_ASSET_ROOT=/work-xy-top-dev
/opt/planning-venv/bin/python -m pytest -q tests/test_low_top_receiver.py tests/test_mount_comparison.py tests/test_carton_population.py tests/test_right_front_eccentric.py
/opt/planning-venv/bin/python -u tools/plan_m710_xy_top_population.py \
  --output /xy-top-development-integration-v1 --integration-top-fixture \
  --worker-command '/bin/bash /worker.sh' --worker-binary /mount-build/m710_moveit_worker \
  --source-commit a02b1be2a54608280c9447adaa23b99dd055207d --development
