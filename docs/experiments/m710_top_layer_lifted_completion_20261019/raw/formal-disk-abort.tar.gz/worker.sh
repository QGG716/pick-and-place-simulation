#!/bin/bash
set -e
source /opt/ros/humble/setup.bash
export AMENT_PREFIX_PATH=/tmp/top-layer-completion-formal-20261019/install:$AMENT_PREFIX_PATH
export LD_LIBRARY_PATH=/tmp/top-layer-completion-formal-20261019/install/lib:$LD_LIBRARY_PATH
exec /tmp/top-layer-completion-formal-20261019/build/m710_moveit_worker
