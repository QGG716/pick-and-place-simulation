#!/bin/bash
set -euo pipefail
round=/root/autodl-tmp/m710-l05-x500-20261022
cd "$round"
test -f setup-finished
test ! -e rootfs/work
tar xzf source.tar.gz -C rootfs
python3 - <<'PY'
from pathlib import Path
import tarfile,json,hashlib
root=Path('rootfs')
with tarfile.open('retained-native-setup.tar.gz') as tar:
    expected=json.load(tar.extractfile('setup-manifest.json'))
    for name in ['rootfs/mount-build/m710_moveit_worker','rootfs/mount-build/libm710_search_trace.so']:
        raw=tar.extractfile(name).read()
        assert hashlib.sha256(raw).hexdigest()==expected[name]
        dest=Path(name);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);dest.chmod(0o755)
assert hashlib.sha256((root/'mount-build/m710_moveit_worker').read_bytes()).hexdigest()=='0bab47de68ae112583afa76a285b74dccd16ff29518d8e11e6d1ac6bfb77756a'
share=root/'mount-install/share'
for kind in ['packages','moveit_core__pluginlib__plugin']:
    (share/'ament_index/resource_index'/kind).mkdir(parents=True,exist_ok=True)
(share/'ament_index/resource_index/packages/m710_moveit_backend').write_text('')
(share/'ament_index/resource_index/moveit_core__pluginlib__plugin/m710_moveit_backend').write_text('share/m710_moveit_backend/search_trace_plugin.xml\n')
(share/'m710_moveit_backend').mkdir()
for f in ['search_trace_plugin.xml','package.xml']:
    (share/'m710_moveit_backend'/f).write_bytes((root/'work/ros2/m710_moveit_backend'/f).read_bytes())
manifest=json.loads((root/'work/source-manifest.json').read_text())
for p,h in manifest['sha256'].items():assert hashlib.sha256((root/'work'/p).read_bytes()).hexdigest()==h,p
print('Source and retained native binary hashes PASS',manifest['source_commit'])
PY
mkdir -p rootfs/dev/shm
chmod 1777 rootfs/dev/shm
cp formal.sh rootfs/formal.sh
cat > rootfs/worker.sh <<'WORKER'
#!/bin/bash
set -eo pipefail
test -z "${LD_PRELOAD:-}"
source /opt/ros/humble/setup.bash
export AMENT_PREFIX_PATH=/mount-install:${AMENT_PREFIX_PATH:-}
export LD_LIBRARY_PATH=/mount-build:${LD_LIBRARY_PATH:-}
exec /mount-build/m710_moveit_worker
WORKER
chroot rootfs /bin/bash -c 'source /opt/ros/humble/setup.bash; export LD_LIBRARY_PATH=/mount-build:$LD_LIBRARY_PATH; ldd /mount-build/m710_moveit_worker' > native-ldd.txt
if grep -q 'not found' native-ldd.txt; then cat native-ldd.txt; exit 1; fi
chroot rootfs /bin/bash -c 'cd /work; export PYTHONPATH=/work/src PYTHONNOUSERSITE=1; /opt/planning-venv/bin/python -m pytest tests/test_mount_comparison.py -q' > focused-tests.log 2>&1
chroot rootfs /opt/planning-venv/bin/python - <<'PY'
from pathlib import Path
import subprocess,json
import pinocchio,hppfcl
versions={}
for line in Path('/ros-packages.lock').read_text().splitlines():
    name,want=line.split('=')
    version=subprocess.check_output(['dpkg-query','-W','-f=${Version}',name],text=True)
    assert version==want,(name,version,want)
    versions[name]=version
Path('/work/environment-check.json').write_text(json.dumps(dict(ros_versions=versions,pinocchio=pinocchio.__version__,hppfcl=hppfcl.__version__,motion_limit_exception=False),indent=2))
print('Pinned production imports and ROS packages PASS')
PY
touch deployment-checked
