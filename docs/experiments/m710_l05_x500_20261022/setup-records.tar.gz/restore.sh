#!/bin/bash
set -euo pipefail
round=/root/autodl-tmp/m710-l05-x500-20261022
cd "$round"
for spec in 'null 1 3' 'zero 1 5' 'random 1 8' 'urandom 1 9'; do
  read -r name major minor <<< "$spec"
  if [ ! -e "rootfs/dev/$name" ]; then mknod -m 666 "rootfs/dev/$name" c "$major" "$minor"; fi
done
chroot rootfs /bin/echo CHROOT_OK
cp ros-snapshot.asc rootfs/usr/share/keyrings/ros-snapshot.asc
cat > rootfs/etc/apt/sources.list <<'APT'
deb http://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy main universe
deb http://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy-updates main universe
deb http://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy-security main universe
deb [signed-by=/usr/share/keyrings/ros-snapshot.asc] http://snapshots.ros.org/humble/2026-09-14/ubuntu jammy main
APT
cp /var/cache/apt/archives/*.deb rootfs/var/cache/apt/archives/
cp ros-packages.lock rootfs/ros-packages.lock
cp python-lock.txt rootfs/python-lock.txt
chroot rootfs /bin/bash -c 'export DEBIAN_FRONTEND=noninteractive; mapfile -t packages < /ros-packages.lock; apt-get update && apt-get install -y --no-install-recommends build-essential cmake python3-ament-package python3-empy python3-catkin-pkg python3-venv nlohmann-json3-dev "${packages[@]}"'
chroot rootfs dpkg-query -W > restored-system-packages.lock
chroot rootfs /bin/bash -c 'python3 -m venv /opt/planning-venv; /opt/planning-venv/bin/pip install --index-url https://pypi.tuna.tsinghua.edu.cn/simple -r /python-lock.txt; /opt/planning-venv/bin/pip freeze' > python-restore.log 2>&1
touch setup-finished
