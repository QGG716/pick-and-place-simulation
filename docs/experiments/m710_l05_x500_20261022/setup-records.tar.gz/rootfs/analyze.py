"""Summarize the one retained task without calling any solver."""
from pathlib import Path
from collections import Counter
import json,hashlib,math,re

run=Path('/formal-v2/carton_l05_c03/seed-71070')
result=json.loads((run/'result.json').read_text())
rows=[]
for a in result['attempts']:
    if 'folder' not in a:continue
    folder=run/a['folder']
    calls=json.loads((folder/'requests.json').read_text())
    detail=json.loads((folder/'attempt.json').read_text())
    counts=Counter((c.get('op'),c.get('stage'),c.get('planner_id'),c['status']) for c in calls)
    lines=(folder/'worker.log').read_text(errors='replace').splitlines()
    errors=Counter(re.sub(r'^\[.*?\] \[.*?\] ','',s) for s in lines if '[ERROR]' in s or '[WARN]' in s)
    rows.append(dict(folder=a['folder'],complete=a['complete'],failure=a.get('failure'),option=a.get('option'),
        operations=[dict(op=k[0],stage=k[1],planner=k[2],status=k[3],count=v) for k,v in counts.items()],
        contact_q_rad=detail.get('contact_end_q_rad'),terminal_contact=detail.get('terminal_contact'),
        receive_sync_location=detail.get('receive_sync_location'),native_log_errors=dict(errors),
        collision_witnesses=[dict(stage=c.get('stage'),witness=w) for c in calls for w in c.get('response',{}).get('clearance',{}).get('rejected_examples',[])],
        native_round_trip_s=sum(c['round_trip_s'] for c in calls),times=detail.get('times')))
metrics=[]
for cycle in result['cycles']:
    for stage in cycle['stages']:
        points=stage.get('points') or []
        if not points:continue
        metrics.append(dict(stage=stage['stage'],planner=stage['planner_id'],point_count=len(points),duration_s=points[-1]['t'],
            max_abs_velocity_rad_s=[max(abs(p['v'][j]) for p in points) for j in range(6)],
            max_abs_acceleration_rad_s2=[max(abs(p['a'][j]) for p in points) for j in range(6)],
            max_step_rad=[max((abs(b['q'][j]-a['q'][j]) for a,b in zip(points,points[1:])),default=0.) for j in range(6)],
            joint_min_deg=[min(math.degrees(p['q'][j]) for p in points) for j in range(6)],
            joint_max_deg=[max(math.degrees(p['q'][j]) for p in points) for j in range(6)]))
manifest=json.loads(Path('/work/source-manifest.json').read_text())
for p,h in manifest['sha256'].items():assert hashlib.sha256((Path('/work')/p).read_bytes()).hexdigest()==h,p
out=dict(source_commit=manifest['source_commit'],source_reverified_after_run=True,solver_calls_added=0,
    completed_count=result['completed_count'],target_count=result['target_count'],planning_wall_s=result['planning_wall_s'],
    initial_cartons=len(result['initial']['world_cartons']),remaining_cartons=len(result['terminal']['world_cartons']),
    historical_completed=result['historical_completed_count'],attempts=rows,stage_metrics=metrics,
    unsearched=[a for a in result['attempts'] if 'folder' not in a],
    qualification_status='NOT_EVALUATED',continuous_swept_proof=False,physical_execution='NOT_RUN',execution_ready=False)
Path('/delivery/diagnostics.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:out[k] for k in ['completed_count','planning_wall_s','initial_cartons','remaining_cartons']}))
