#!/bin/bash
set -euo pipefail
export PYTHONPATH=/work/src PYTHONNOUSERSITE=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 M710_MOVEIT_ASSET_ROOT=/work
mkdir -p /delivery
/opt/planning-venv/bin/python /work/tools/verify_m710_extraction_retreat.py /formal-v2 > /delivery/verification.log
/opt/planning-venv/bin/python /analyze.py
if /opt/planning-venv/bin/python -c 'import json,sys;sys.exit(json.load(open("/formal-v2/carton_l05_c03/seed-71070/result.json"))["completed_count"]!=1)'; then
  /opt/planning-venv/bin/python /work/tools/export_m710_top_layer_replay.py /formal-v2/carton_l05_c03 --seed 71070 --output /delivery/replay.html > /delivery/export.log
fi
cp /formal-v2/verification.json /formal-v2/protocol.json /formal-v2/summary.json /formal-v2/initial-state-checks.json /delivery/
cp /work/source-manifest.json /work/environment-check.json /delivery/
cp /work/assets/robots/fanuc_m710id_70/official/LICENSES/Apache-2.0.txt /delivery/LICENSE.FANUC.txt
cp /work/tools/search_replay/vendor/LICENSE.three /delivery/LICENSE.three
tar -cJf /delivery/raw-records.tar.xz -C / formal-v1 formal-v2
touch /analysis-finished
