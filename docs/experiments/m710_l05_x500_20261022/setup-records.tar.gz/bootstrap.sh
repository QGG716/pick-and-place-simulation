#!/bin/bash
set -euo pipefail
round=/root/autodl-tmp/m710-l05-x500-20261022
mkdir -p "$round"
cd "$round"
test ! -e rootfs
curl --fail --location --retry 2 --connect-timeout 20 --max-time 180 \
  https://cdimage.ubuntu.com/ubuntu-base/releases/22.04/release/ubuntu-base-22.04.5-base-amd64.tar.gz -o ubuntu-base.tar.gz
curl --fail --location --retry 2 --connect-timeout 20 --max-time 60 \
  https://cdimage.ubuntu.com/ubuntu-base/releases/22.04/release/SHA256SUMS -o SHA256SUMS
python3 - <<'PY'
import hashlib
from pathlib import Path
name='ubuntu-base-22.04.5-base-amd64.tar.gz'
expected=next(s.split()[0] for s in Path('SHA256SUMS').read_text().splitlines() if s.endswith(name))
assert hashlib.sha256(Path('ubuntu-base.tar.gz').read_bytes()).hexdigest()==expected
PY
mkdir rootfs
tar xzf ubuntu-base.tar.gz -C rootfs
cp /etc/resolv.conf rootfs/etc/resolv.conf
mount --bind /dev rootfs/dev
mount -t proc proc rootfs/proc
cp ros-snapshot.asc rootfs/usr/share/keyrings/ros-snapshot.asc
cat > rootfs/etc/apt/sources.list <<'APT'
deb http://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy main universe
deb http://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy-updates main universe
deb http://mirrors.tuna.tsinghua.edu.cn/ubuntu/ jammy-security main universe
deb [signed-by=/usr/share/keyrings/ros-snapshot.asc] http://snapshots.ros.org/humble/2026-09-14/ubuntu jammy main
APT
cp /var/cache/apt/archives/*.deb rootfs/var/cache/apt/archives/
cp ros-packages.lock rootfs/ros-packages.lock
cp python-lock.txt rootfs/python-lock.txt
chroot rootfs /bin/bash -c 'export DEBIAN_FRONTEND=noninteractive; mapfile -t packages < /ros-packages.lock; apt-get update && apt-get install -y --no-install-recommends build-essential cmake python3-ament-package python3-empy python3-catkin-pkg python3-venv nlohmann-json3-dev "${packages[@]}"'
chroot rootfs dpkg-query -W > restored-system-packages.lock
chroot rootfs /bin/bash -c 'python3 -m venv /opt/planning-venv; /opt/planning-venv/bin/pip install --index-url https://pypi.tuna.tsinghua.edu.cn/simple -r /python-lock.txt; /opt/planning-venv/bin/pip freeze' > python-restore.log 2>&1
touch setup-finished
