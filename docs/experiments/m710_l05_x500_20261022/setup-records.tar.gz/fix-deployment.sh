#!/bin/bash
set -euo pipefail
round=/root/autodl-tmp/m710-l05-x500-20261022
cd "$round"
cp deploy.sh deploy-original.sh
cp rootfs/worker.sh worker-original.sh
cp rootfs/formal.sh formal-original.sh
mkdir -p rootfs/mount-install/lib
cp rootfs/mount-build/libm710_search_trace.so rootfs/mount-install/lib/libm710_search_trace.so
cmp rootfs/mount-build/libm710_search_trace.so rootfs/mount-install/lib/libm710_search_trace.so
sha256sum rootfs/mount-build/libm710_search_trace.so rootfs/mount-install/lib/libm710_search_trace.so
sed -i 's@LD_LIBRARY_PATH=/mount-build:@LD_LIBRARY_PATH=/mount-install/lib:/mount-build:@' rootfs/worker.sh
cp formal-fixed.sh rootfs/formal.sh
sha256sum rootfs/mount-build/m710_moveit_worker
find rootfs/formal-v1 -name requests.json -exec ls -l {} \;
