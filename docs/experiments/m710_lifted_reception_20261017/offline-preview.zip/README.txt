Offline geometry process preview
Open preview.html directly in a browser. No network, ROS or web server required.
GEOMETRY_PROCESS_PREVIEW
MOTION_PLANNING_NOT_RUN
PHYSICAL_EXECUTION_NOT_RUN
No executable robot trajectory. Manual belt heights are NOT_EVALUATED.
Source: 66f18208a86d291ff6895ca3f0e3b461ad2b7b62
