FANUC M-710iD/70 正抓＋Hmax 横带原生规划回放

解压后用浏览器打开 c02-replay.html 或 c04-replay.html，无需网络。
阶段按钮切换接近、横带升高、接触、抽离；各自滑块显示本次实际关节状态。
横带升高滑块表示几何进度，没有真实升降速度或执行时间。
最终目标仍附着，5 cm 间隔保留，没有释放、落带或物理执行。
机器人来自官方模型及本次原生轨迹 q，不是固定参考姿态配独立移动工具。
两例第一个区域样本即通过，未选样本数为 0；没有捏造额外尝试。

实测源码 f896a9d84675125678dd32208de1183b2fb8dadb。
c02 规划 4.390408 s；c04 规划 5.450982 s。初始化与回放制作另计。
回放显示在实测冻结后作了文字/可读性修整，规划输入和结果没有改变。

geometry-preview-legend-fixed.html 是前轮纯几何预览的图例修正副本，
仅修复红色图例问号，不能当作本轮机器人实际规划轨迹。
旧预览原件与此前失败原始记录均保留在仓库历史/对应报告中。

PLANNING_ONLY_NOT_EXECUTABLE
qualification_status=NOT_EVALUATED
continuous_swept_proof=false
physical_execution=NOT_RUN

保留的第三方许可证见 LICENSE.three 与 LICENSE.fanuc.txt。
