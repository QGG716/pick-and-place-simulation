"""Negative initialized protocol reachability probe: zero IK and zero motion."""
import sys,json,os
from pathlib import Path
import numpy as np
sys.path[:0]=["/work-single-contact-20261016/src","/work-single-contact-20261016/tools"]
from unloading_sim.layout_single_carton import load_layout_motion_policy,build_verified_motion_input,_build_automatic_trajectory_connector
from unloading_sim.single_contact import SingleContactClient
from unloading_sim.single_preplace import SinglePreplaceConnector
from unloading_sim.contact_target import simulation_contact_targets
from unloading_sim.moveit2_backend import ResidentMoveItClient,MoveItUnavailable
root=Path("/work-single-contact-20261016")
o=Path("/tmp/single-preplace-20261016")
p=load_layout_motion_policy(root/"configs/validation/m710id70_proof_of_concept.yaml")
s=build_verified_motion_input(p,root)
b=_build_automatic_trajectory_connector(s,p.layout_validation.layout.robot())
client=SingleContactClient(ResidentMoveItClient(str(o/"worker.sh"),log_path=str(o/"probe-worker.log")),preplace_enabled=True)
try:
    c=SinglePreplaceConnector.from_existing(b.connector,s,native_client=client,planning_mode="cold_from_scratch",
        native_budget=dict(task_wall_time_s=300.,stage_wall_time_s=90.,ipc_timeout_s=100.))
    target=next(x for x in s.cartons if x.name=="carton_l07_c02")
    t=simulation_contact_targets(s,target,c.robot.base_transform[:3,3],c.budget.pregrasp_standoff_m)[0][0]
    c.expected_contact(t,p.data["suction"])
    q=np.asarray(p.layout_validation.initial_q)
    req=c._build_native_request(q,q,s.all_obstacles,seed=71070,stage="pregrasp")
    req.update(op="check_transit_end",ownership_transition=None,parent_stage_id="",purpose="FREE_LOADED_TRANSFER")
    # Deliberately bypass Python scope fence ONLY for this malformed negative protocol probe.
    try:
        result=client.client.request(req,timeout=100.)
        detail=json.dumps(result)
    except MoveItUnavailable as exc:
        result=dict(exception=str(exc));detail=str(exc)
    assert "TRANSIT_END_CHECK_SCOPE_INVALID" in detail and "UNKNOWN_OPERATION" not in detail,detail
    evidence=dict(scope="INITIALIZED_NEGATIVE_PROTOCOL_REACHABILITY_ONLY",motion_requests=0,ik_requests=0,
        result=result,initialization_records=client.records)
    (o/"protocol-probe.json").write_text(json.dumps(evidence,indent=2)+"\n")
    print("INITIALIZED_TRANSIT_ENDPOINT_HANDLER_REACHED_ZERO_SOLVES")
finally:client.close()

