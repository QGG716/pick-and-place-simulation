// User-requested planning-only rate-limit diagnostic for one named carton.
// No solver, joint position, collision, or process predicate is replaced.
#include <pilz_industrial_motion_planner/trajectory_functions.h>
#include <dlfcn.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <stdexcept>
#include <moveit/robot_state/robot_state.h>

namespace {
bool allRatesException() {
  const char* scope=std::getenv("M710_PLANNING_ONLY_ALL_JOINT_RATES_EXCEPTION");
  return scope && std::strcmp(scope,"carton_l05_c03")==0;
}
template<class Function> Function originalBounds(const char* symbol) {
  static void* library=dlopen("libmoveit_robot_state.so",RTLD_NOW|RTLD_LOCAL);
  auto fn=library?reinterpret_cast<Function>(dlsym(library,symbol)):nullptr;
  if (!fn) throw std::runtime_error("MOVEIT_ORIGINAL_BOUNDS_CHECK_UNAVAILABLE");
  return fn;
}
bool finiteState(const moveit::core::RobotState& state) {
  for (std::size_t i=0;i<state.getVariableCount();++i)
    if (!std::isfinite(state.getVariablePositions()[i]) ||
        (state.hasVelocities() && !std::isfinite(state.getVariableVelocities()[i]))) return false;
  return true;
}
}

namespace moveit::core {
// MoveIt 2.5.10 satisfiesBounds checks positions AND populated velocities.
// Preserve the real trajectory and RobotModel. Only the temporary predicate
// input drops velocity presence; the original position predicate still runs.
bool RobotState::satisfiesBounds(double margin) const {
  using Original=bool (*)(const RobotState*,double);
  static auto original=originalBounds<Original>("_ZNK6moveit4core10RobotState15satisfiesBoundsEd");
  if (!allRatesException() || !hasVelocities()) return original(this,margin);
  if (!finiteState(*this)) return false;
  RobotState positions(*this);positions.dropVelocities();
  const bool accepted=original(&positions,margin);
  if (accepted && !original(this,margin)) std::fprintf(stderr,
    "M710_DIAGNOSTIC_STATE_VELOCITY_IGNORED target=carton_l05_c03 scope=all position_bounds_pass=true physical_execution=NOT_RUN\n");
  return accepted;
}
bool RobotState::satisfiesBounds(const JointModelGroup* group,double margin) const {
  using Original=bool (*)(const RobotState*,const JointModelGroup*,double);
  static auto original=originalBounds<Original>("_ZNK6moveit4core10RobotState15satisfiesBoundsEPKNS0_15JointModelGroupEd");
  if (!allRatesException() || !hasVelocities()) return original(this,group,margin);
  if (!finiteState(*this)) return false;
  RobotState positions(*this);positions.dropVelocities();
  const bool accepted=original(&positions,group,margin);
  if (accepted && !original(this,group,margin)) std::fprintf(stderr,
    "M710_DIAGNOSTIC_STATE_VELOCITY_IGNORED target=carton_l05_c03 scope=group position_bounds_pass=true physical_execution=NOT_RUN\n");
  return accepted;
}
}

namespace pilz_industrial_motion_planner {
bool verifySampleJointLimits(const std::map<std::string,double>& previous,
    const std::map<std::string,double>& previous_velocity,
    const std::map<std::string,double>& current, double previous_dt, double dt,
    const JointLimitsContainer& limits) {
  using Original=bool (*)(const std::map<std::string,double>&,
      const std::map<std::string,double>&,const std::map<std::string,double>&,
      double,double,const JointLimitsContainer&);
  static Original original=[] {
    Dl_info info{};
    if (!dladdr(reinterpret_cast<void*>(&verifySampleJointLimits),&info) || !info.dli_sname)
      throw std::runtime_error("PILZ_SAMPLE_CHECK_SYMBOL_UNAVAILABLE");
    // Pilz is plugin-loaded with local visibility in the production worker;
    // RTLD_NEXT alone only worked in the directly linked regression process.
    // Resolve the original definition through its actual library handle.
    static void* library=dlopen("libtrajectory_generation_common.so",RTLD_NOW|RTLD_LOCAL);
    auto fn=library?reinterpret_cast<Original>(dlsym(library,info.dli_sname)):nullptr;
    if (!fn || fn==&verifySampleJointLimits)
      throw std::runtime_error("PILZ_ORIGINAL_SAMPLE_CHECK_UNAVAILABLE");
    return fn;
  }();
  const char* scope=std::getenv("M710_PLANNING_ONLY_ALL_JOINT_RATES_EXCEPTION");
  if (!scope || std::strcmp(scope,"carton_l05_c03")!=0)
    return original(previous,previous_velocity,current,previous_dt,dt,limits);
  if (!std::isfinite(dt) || !std::isfinite(previous_dt) || dt<=1e-5 || previous_dt<0)
    return false;
  JointLimitsContainer diagnostic_limits;
  for (const auto& item:limits) {
    auto bound=item.second;
    bound.has_velocity_limits=false;
    bound.has_acceleration_limits=false;
    bound.has_deceleration_limits=false;
    if (!diagnostic_limits.addLimit(item.first,bound))
      throw std::runtime_error("PILZ_DIAGNOSTIC_LIMIT_COPY_FAILED");
  }
  for (const auto& item:current) {
    const double last=previous.at(item.first),last_v=previous_velocity.at(item.first);
    const double v=(item.second-last)/dt,a=2*(v-last_v)/(previous_dt+dt);
    if (!std::isfinite(item.second) || !std::isfinite(last) || !std::isfinite(last_v)
        || !std::isfinite(v) || !std::isfinite(a)) return false;
    const auto bound=limits.getLimit(item.first);
    const bool accelerating=std::abs(last_v)<=std::abs(v);
    const bool violation=(bound.has_velocity_limits && std::abs(v)>bound.max_velocity) ||
      (accelerating && bound.has_acceleration_limits && std::abs(a)>std::abs(bound.max_acceleration)) ||
      (!accelerating && bound.has_deceleration_limits && std::abs(a)>std::abs(bound.max_deceleration));
    if (violation) std::fprintf(stderr,
      "M710_DIAGNOSTIC_JOINT_RATE_IGNORED target=carton_l05_c03 joint=%s velocity_rad_s=%.17g acceleration_rad_s2=%.17g delta_q_rad=%.17g dt_s=%.17g velocity_limit_rad_s=%.17g acceleration_limit_rad_s2=%.17g deceleration_limit_rad_s2=%.17g physical_execution=NOT_RUN\n",
      item.first.c_str(),v,a,item.second-last,dt,bound.max_velocity,bound.max_acceleration,bound.max_deceleration);
  }
  return original(previous,previous_velocity,current,previous_dt,dt,diagnostic_limits);
}
}
