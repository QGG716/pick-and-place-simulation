"""Pure geometry policies consumed by the M-710 Isaac replay adapter.

The functions in this module deliberately have no Isaac/Kit dependencies.  The
CPU test suite therefore exercises the exact attachment and conveyor-selection
logic that the heavyweight runtime consumes, even when Isaac is unavailable.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import acos, cos
from typing import Any, Mapping, Sequence

import numpy as np


class RuntimeFeedbackMonitor:
    """Per-task, first-observation stop latch. No physics or drive side effects.

    Reference is the zero-order-held trajectory command that produced the
    observed step, never the gravity-biased drive target or next command time.
    Attachment baseline belongs to actual constraint creation/closure.
    """

    def __init__(self, joint_names, lower, upper, velocity, policy):
        from dataclasses import asdict
        self.names = list(joint_names)
        self.policy = policy
        self.lower, self.upper, self.velocity = [np.asarray(v, float) for v in (lower, upper, velocity)]
        if (not self.names or len(set(self.names)) != len(self.names)
                or any(v.shape != (len(self.names),) or not np.isfinite(v).all()
                       for v in (self.lower, self.upper, self.velocity))
                or np.any(self.lower >= self.upper) or np.any(self.velocity <= 0)):
            raise ValueError("invalid official feedback limits/joint order")
        self.thresholds = dict(policy=asdict(policy), joint_names=self.names,
            lower_rad=self.lower.tolist(), upper_rad=self.upper.tolist(), velocity_rad_s=self.velocity.tolist(),
            source="ReplayQualificationPolicy and bound official joint limits; no debounce")
        self.first_failure = None
        self.last_valid = None
        self.last_observation = None
        self.attachment_baseline = None
        self.attachment_released = False
        self.observations = 0
        self.stop_handling = None

    @staticmethod
    def _json(value):
        """Keep invalid values explicit while emitting strict portable JSON."""
        if isinstance(value, np.ndarray): return RuntimeFeedbackMonitor._json(value.tolist())
        if isinstance(value, np.generic): return RuntimeFeedbackMonitor._json(value.item())
        if isinstance(value, dict): return {str(k): RuntimeFeedbackMonitor._json(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)): return [RuntimeFeedbackMonitor._json(v) for v in value]
        if isinstance(value, float) and not np.isfinite(value): return str(value)
        return value

    def latch(self, reasons, observation):
        if self.first_failure is None:
            import copy
            self.first_failure = copy.deepcopy(self._json(dict(
                reason=reasons[0]['reason'], violations=reasons, observation=observation)))
        return False

    def observe(self, *, q, qd, reference, reference_velocity, attached,
                legally_released=False, body_pose=None, carton_pose=None,
                captured_relative_pose=None, attachment_expected=False, context=None):
        if self.first_failure is not None: return False
        self.observations += 1
        errors = []
        observation = dict(context or {}, q_rad=q, qd_rad_s=qd,
                           reference_q_rad=reference, reference_qd_rad_s=reference_velocity,
                           attached=attached, legally_released=legally_released)
        def vector(value, count, name):
            try:
                a = np.asarray(value, float)
                if a.shape != (count,) or not np.isfinite(a).all(): raise ValueError()
                return a
            except (TypeError, ValueError):
                errors.append(dict(reason="INVALID_ACTUAL_FEEDBACK", field=name,
                                   expected_shape=[count], measured=self._json(value)))
                return None
        n = len(self.names)
        q, qd = vector(q,n,'q_rad'), vector(qd,n,'qd_rad_s')
        ref, refd = vector(reference,n,'reference_q_rad'), vector(reference_velocity,n,'reference_qd_rad_s')
        if not isinstance(attached, (bool, np.bool_)) or not isinstance(legally_released, (bool, np.bool_)):
            errors.append(dict(reason="INVALID_ACTUAL_FEEDBACK", field="attachment_lifecycle"))
        def joint_error(reason, values, mask, **limits):
            indices = np.flatnonzero(mask)
            if indices.size:
                errors.append(dict(reason=reason, joints=[self.names[i] for i in indices],
                    indices=indices.tolist(), measured=values[indices].tolist(), **limits))
        if q is not None:
            tolerance = self.policy.joint_position_tolerance_rad
            joint_error('ACTUAL_JOINT_POSITION_LIMIT', q,
                        (q < self.lower-tolerance) | (q > self.upper+tolerance),
                        lower=self.lower.tolist(), upper=self.upper.tolist(), tolerance_rad=tolerance)
        if qd is not None:
            tolerance = self.policy.joint_velocity_tolerance_rad_s
            joint_error('ACTUAL_JOINT_VELOCITY_LIMIT', qd, np.abs(qd)>self.velocity+tolerance,
                        limits_rad_s=self.velocity.tolist(), tolerance_rad_s=tolerance)
        if q is not None and ref is not None:
            delta = np.abs(q-ref)
            observation['tracking_error_rad'] = delta
            joint_error('ACTUAL_JOINT_TRACKING_ERROR', delta, delta>self.policy.tracking_error_limit_rad,
                        limit_rad=self.policy.tracking_error_limit_rad)
        if legally_released and not attached:
            self.attachment_released = True
        if (attachment_expected or self.attachment_baseline is not None) and not self.attachment_released and not attached:
            errors.append(dict(reason='ACTUAL_ATTACHMENT_LOST'))
        if attached:
            def pose(value, name):
                a=vector(value,7,name)
                if a is not None and (not np.isfinite(np.linalg.norm(a[3:])) or np.linalg.norm(a[3:]) <= 1e-12):
                    errors.append(dict(reason='INVALID_ACTUAL_FEEDBACK',field=name+'.quaternion'))
                    return None
                return a
            body, carton = pose(body_pose,'body_pose'), pose(carton_pose,'carton_pose')
            observation.update(body_pose=body_pose, carton_pose=carton_pose)
            def mul(a,b):
                return np.r_[a[0]*b[0]-a[1:]@b[1:], a[0]*b[1:]+b[0]*a[1:]+np.cross(a[1:],b[1:])]
            if body is not None and carton is not None:
                b=body[3:]/np.linalg.norm(body[3:]); c=carton[3:]/np.linalg.norm(carton[3:])
                inverse=b*np.array([1,-1,-1,-1])
                relative=np.r_[mul(mul(inverse,np.r_[0,carton[:3]-body[:3]]),b)[1:],mul(inverse,c)]
                if self.attachment_baseline is None:
                    baseline=pose(captured_relative_pose,'captured_attachment_pose') if captured_relative_pose is not None else relative
                    if baseline is not None: self.attachment_baseline=baseline.copy()
                if self.attachment_baseline is not None:
                    baseline=self.attachment_baseline
                    translation=float(np.linalg.norm(relative[:3]-baseline[:3]))
                    angle=float(2*np.arccos(np.clip(abs(relative[3:]@(baseline[3:]/np.linalg.norm(baseline[3:]))),0,1)))
                    observation.update(attachment_position_error_m=translation,attachment_rotation_error_rad=angle,
                                       captured_relative_pose=baseline)
                    for value,limit,reason in [(translation,self.policy.attachment_position_tolerance_m,'ACTUAL_ATTACHMENT_TRANSLATION'),
                                               (angle,self.policy.attachment_rotation_tolerance_rad,'ACTUAL_ATTACHMENT_ROTATION')]:
                        if value>limit: errors.append(dict(reason=reason,measured=value,limit=limit))
        self.last_observation=self._json(observation)
        if errors: return self.latch(errors,observation)
        import copy
        self.last_valid=copy.deepcopy(self.last_observation)
        return True

    def evidence(self):
        return self._json(dict(schema='m710_runtime_feedback_v1', thresholds=self.thresholds,
            observations=self.observations, first_failure=self.first_failure,
            last_valid_actual_state=self.last_valid, last_observation=self.last_observation,
            stop_handling=self.stop_handling))

    def persist(self, path):
        import json, os
        from pathlib import Path
        path=Path(path);temporary=path.with_suffix(path.suffix+'.tmp')
        temporary.write_text(json.dumps(self.evidence(),indent=2,allow_nan=False),encoding='utf-8')
        os.replace(temporary,path)


def archived_replay_initialization(metadata):
    """Validate a bound archive context before constructing a *new* world.

    Historical events are initialization context, never new execution results.
    The caller authors the bundle's poses only during initial scene creation.
    """
    from copy import deepcopy
    from .serial_unloading import _identity_set, _reception_event_sets
    context = metadata.get("initial_actual_state_context")
    if not context:
        if (metadata.get("completed_carton_ids") or metadata.get("processed_carton_ids")
                or metadata.get("handed_off_ids") or metadata.get("receiver_transport_state")):
            raise ValueError("archived events require the bound actual-state initialization context")
        return None
    if (context.get("schema") != "m710id70_actual_motion_state_v1"
            or context.get("source") != "ACTUAL_RIGID_BODY_STATE"
            or context.get("completion_source") != "EXPLICIT_EXECUTION_EVENTS_NOT_POSITION_CLASSIFICATION"):
        raise ValueError("archive initialization requires validated actual-state provenance")
    fingerprint = context.get("actual_state_fingerprint")
    if (not isinstance(fingerprint, str) or len(fingerprint) != 64
            or any(c not in "0123456789abcdef" for c in fingerprint)):
        raise ValueError("archive initialization requires its actual-state fingerprint")
    initial = _identity_set([r["name"] for r in context["initial_carton_registry"]], "archive registry")
    actual, ideal, processed, transported = _reception_event_sets(
        context, metadata.get("post_landing_transport"), initial)
    handed = _identity_set(context.get("handed_off_ids", []), "archive outfed identities")
    active = _identity_set([p["name"] for p in metadata["scene_primitives"] if p.get("dynamic")],
                           "archive active identities")
    if not handed <= processed or active != initial - handed:
        raise ValueError("archive active identities disagree with historical events")
    for field, expected in (("completed_carton_ids", actual), ("processed_carton_ids", processed),
                            ("handed_off_ids", handed)):
        if _identity_set(metadata.get(field, []), field) != expected:
            raise ValueError(f"archive metadata changed historical events: {field}")
    if metadata.get("receiver_transport_state", {}) != context.get("receiver_transport_state", {}):
        raise ValueError("archive metadata changed reception provenance")
    if metadata.get("target") not in active - processed:
        raise ValueError("archive replay target must be active and unprocessed")
    velocities = context.get("carton_velocities", {})
    if set(velocities) != active:
        raise ValueError("archive must retain every active body's observed velocity")
    for record in velocities.values():
        for field in ("linear_velocity_m_s", "angular_velocity_rad_s"):
            value = np.asarray(record.get(field), dtype=float)
            if value.shape != (3,) or not np.all(np.isfinite(value)):
                raise ValueError(f"archive has invalid {field}")
    time_s = context.get("time_s")
    if not context.get("world_session_id") or not isinstance(time_s, (int, float)) or not np.isfinite(time_s) or time_s < 0:
        raise ValueError("archive requires its original world and time")
    result = deepcopy(context)
    result["world_scope"] = "NEW_WORLD_RECONSTRUCTED_FROM_ARCHIVED_ACTUAL_STATE"
    result["historical_counts"] = {"actual_received": len(actual), "ideal_received": len(ideal),
                                   "processed": len(processed), "outfed": len(handed)}
    result["active_ideal_transport_ids"] = sorted(transported & active)
    return result


def archived_world_actual_state(metadata, initialization, *, q_rad, joint_names, cartons, world_session_id):
    """Capture post-settling measurements; do not restore any pose to the plan."""
    from copy import deepcopy
    from .serial_unloading import _identity_set, _vector, rotation_from_actual_quaternion
    if not world_session_id or world_session_id == initialization["world_session_id"]:
        raise ValueError("archive reconstruction requires a distinct new-world identity")
    expected = {p["name"] for p in metadata["scene_primitives"] if p.get("dynamic")}
    if _identity_set([c["name"] for c in cartons], "measured active bodies") != expected:
        raise ValueError("post-settling readback lost active carton identities")
    if _identity_set(joint_names, "measured joint names") != set(metadata["joint_names"]):
        raise ValueError("post-settling readback changed joint identities")
    q = _vector(q_rad, len(joint_names), "measured q_rad")
    records = []
    for item in cartons:
        rotation_from_actual_quaternion(item["quaternion_wxyz"])
        record = {"name": item["name"], "orientation_wxyz": list(item["quaternion_wxyz"])}
        for destination, source in (("position_m", "center_m"),
                                    ("linear_velocity_m_s", "linear_velocity_m_s"),
                                    ("angular_velocity_rad_s", "angular_velocity_rad_s")):
            record[destination] = _vector(item[source], 3, source).tolist()
        records.append(record)
    return {
        "schema": "m710id70_actual_motion_state_v1", "q_rad": q.tolist(),
        "joint_names": list(joint_names), "world_session_id": world_session_id,
        "time_s": float(initialization["time_s"]), "attached": False, "attachment_target": None,
        "cartons": records,
        **{field: deepcopy(initialization[field]) for field in (
            "completed_carton_ids", "processed_carton_ids", "ideal_received_ids",
            "handed_off_ids", "receiver_transport_state")},
        "inactive_carton_ids": list(initialization["handed_off_ids"]),
        "post_landing_transport": deepcopy(metadata["post_landing_transport"]),
        "simulation_profile": deepcopy(metadata.get("simulation_profile")),
        "initialization_provenance": {
            "world_scope": initialization["world_scope"],
            "source_world_session_id": initialization["world_session_id"],
            "source_actual_state_fingerprint": initialization["actual_state_fingerprint"],
            "historical_events_counted_as_new_task_completion": False,
        },
    }


def verify_physics_backend_readback(requested, actual):
    """The configured engine/device policy must be the one PhysX reports."""
    fields = {"mode", "device", "broadphase_type", "gpu_dynamics_enabled", "fabric_enabled", "ccd_enabled"}
    if not isinstance(requested, Mapping) or set(requested) != fields:
        raise ValueError("physics execution backend requires the complete bound policy")
    # This milestone preserves the previous CPU world's CCD. The installed
    # GPU PhysX backend cannot preserve CCD and is therefore not an allowed
    # execution policy, even when GPU rendering remains enabled.
    expected = {"mode": "physx_cpu", "device": "cpu", "broadphase_type": "MBP",
                "gpu_dynamics_enabled": False, "fabric_enabled": True, "ccd_enabled": True}
    if dict(requested) != expected:
        raise ValueError("unsupported or contradictory physics execution backend")
    if not isinstance(actual, Mapping) or dict(actual) != expected:
        raise ValueError(f"physics execution backend readback mismatch: expected {expected}, actual {actual}")
    return {"status": "PASS", "requested": dict(requested), "actual": dict(actual),
            "source": "SimulationManager_and_PhysicsContext_runtime_readback"}


def obb_aabb_definitely_separated(center_a, half_a, rotation_a, center_b, half_b, rotation_b):
    """Conservative world-axis rejection only, with outward roundoff padding."""
    extent_a = np.abs(rotation_a) @ half_a
    extent_b = np.abs(rotation_b) @ half_b
    scale = max(1.0, float(np.max(np.abs(center_a))), float(np.max(np.abs(center_b))),
                float(np.max(extent_a)), float(np.max(extent_b)))
    padding = 64.0 * np.finfo(float).eps * scale
    return bool(np.any(np.abs(center_b - center_a) > extent_a + extent_b + padding))


def obb_penetration_depth(center_a, half_a, rotation_a, center_b, half_b, rotation_b,
                          *, use_aabb_broadphase=True):
    """The original SAT depth; skip it only for proved-separated world AABBs."""
    center_a = np.asarray(center_a, dtype=float)
    center_b = np.asarray(center_b, dtype=float)
    half_a = np.asarray(half_a, dtype=float)
    half_b = np.asarray(half_b, dtype=float)
    rotation_a = np.asarray(rotation_a, dtype=float)
    rotation_b = np.asarray(rotation_b, dtype=float)
    if use_aabb_broadphase and obb_aabb_definitely_separated(
            center_a, half_a, rotation_a, center_b, half_b, rotation_b):
        return 0.0
    axes = [*rotation_a.T, *rotation_b.T]
    axes.extend(np.cross(first, second) for first in rotation_a.T for second in rotation_b.T)
    center_delta = center_b - center_a
    minimum_overlap = float("inf")
    for raw_axis in axes:
        magnitude = float(np.linalg.norm(raw_axis))
        if magnitude <= 1e-10:
            continue
        axis = raw_axis / magnitude
        radius_a = float(np.sum(half_a * np.abs(rotation_a.T @ axis)))
        radius_b = float(np.sum(half_b * np.abs(rotation_b.T @ axis)))
        overlap = radius_a + radius_b - abs(float(center_delta @ axis))
        if overlap <= 0.0:
            return 0.0
        minimum_overlap = min(minimum_overlap, overlap)
    return 0.0 if not np.isfinite(minimum_overlap) else minimum_overlap


def swept_payload_tool_clearance(
    payload_center_m,
    payload_half_extents_m,
    payload_rotation,
    transport_direction_world,
    transport_distance_m,
    tool_body_center_m,
    tool_body_rotation,
    tool_collider_corners_body_m,
):
    """Conservative clearance from live tool colliders to a payload sweep.

    ``tool_collider_corners_body_m`` contains the authored collision geometry
    expressed in the owning rigid body's frame.  The caller supplies the live
    PhysX body pose, avoiding USD/Fabric transforms that can remain stale for
    articulation children.  Each collider is evaluated separately: combining
    disconnected tool shapes into one box would fill the real gaps between
    them and can incorrectly prevent conveyor start.
    """
    payload_center = np.asarray(payload_center_m, dtype=float)
    payload_half = np.asarray(payload_half_extents_m, dtype=float)
    payload_rotation = np.asarray(payload_rotation, dtype=float)
    direction = np.asarray(transport_direction_world, dtype=float)
    tool_center = np.asarray(tool_body_center_m, dtype=float)
    tool_rotation = np.asarray(tool_body_rotation, dtype=float)
    corner_sets = [np.asarray(corners, dtype=float) for corners in tool_collider_corners_body_m]
    if (
        payload_center.shape != (3,)
        or payload_half.shape != (3,)
        or payload_rotation.shape != (3, 3)
        or direction.shape != (3,)
        or tool_center.shape != (3,)
        or tool_rotation.shape != (3, 3)
        or not corner_sets
        or any(corners.ndim != 2 or corners.shape[1] != 3 or len(corners) < 2 for corners in corner_sets)
        or not all(
            np.all(np.isfinite(value))
            for value in (payload_center, payload_half, payload_rotation, direction,
                          tool_center, tool_rotation, *corner_sets)
        )
        or np.any(payload_half <= 0.0)
        or not np.isfinite(transport_distance_m)
        or transport_distance_m < 0.0
    ):
        raise ValueError("live swept-clearance inputs must be finite valid geometry")
    direction_norm = float(np.linalg.norm(direction))
    if abs(direction_norm - 1.0) > 1.0e-6:
        raise ValueError("transport direction must be a unit vector")

    signs = np.asarray(
        [[x, y, z] for x in (-1.0, 1.0) for y in (-1.0, 1.0) for z in (-1.0, 1.0)],
        dtype=float,
    )
    payload_corners = (signs * payload_half) @ payload_rotation.T + payload_center
    translated_corners = payload_corners + direction * float(transport_distance_m)
    swept_corners = np.vstack((payload_corners, translated_corners))
    swept_low = swept_corners.min(axis=0)
    swept_high = swept_corners.max(axis=0)

    clearances = []
    for corners in corner_sets:
        tool_world = corners @ tool_rotation.T + tool_center
        tool_low = tool_world.min(axis=0)
        tool_high = tool_world.max(axis=0)
        separating_gaps = np.maximum(swept_low - tool_high, tool_low - swept_high)
        positive = np.maximum(separating_gaps, 0.0)
        if np.any(positive > 0.0):
            clearances.append(float(np.linalg.norm(positive)))
        else:
            overlap = np.minimum(tool_high, swept_high) - np.maximum(tool_low, swept_low)
            clearances.append(-float(np.min(overlap)))
    return min(clearances)


def replay_command_arrays(bundle, expected_joint_names):
    """Consume the exporter schema identically for initial and continued tasks."""
    if "timestamps_seconds" not in bundle or "positions_rad" not in bundle:
        raise ValueError("replay commands require timestamps_seconds and positions_rad")
    timestamps = np.asarray(bundle["timestamps_seconds"], dtype=float)
    positions = np.asarray(bundle["positions_rad"], dtype=float)
    if (timestamps.ndim != 1 or len(timestamps) < 2
            or positions.shape != (len(timestamps), len(expected_joint_names))
            or not np.all(np.isfinite(timestamps)) or not np.all(np.isfinite(positions))
            or abs(timestamps[0]) > 1e-12 or np.any(np.diff(timestamps) <= 0)):
        raise ValueError("replay bundle command dimensions or times are invalid")
    reference = bundle.get('metadata', {}).get('joint_reference')
    if reference is not None:
        from .timing import sample_quintic_knots
        knots = np.asarray(reference.get('timestamps_seconds'), float)
        values = np.asarray(reference.get('positions_rad'), float)
        if (reference.get('interpolation') != 'C2_piecewise_quintic_rest_to_rest'
                or knots.ndim != 1 or len(knots) < 2 or values.shape != (len(knots), len(expected_joint_names))
                or not np.all(np.isfinite(knots)) or not np.all(np.isfinite(values))
                or np.any(np.diff(knots) <= 0) or abs(knots[0]) > 1e-12
                or abs(knots[-1]-timestamps[-1]) > 1e-10):
            raise ValueError('analytic reference knots are invalid')
        sampled, _ = sample_quintic_knots(knots, values, timestamps)
        if not np.allclose(sampled, positions, atol=1e-10, rtol=0):
            raise ValueError('commands disagree with the bound analytic reference')
    return timestamps, positions


def validate_continuation_request(request, *, world_session_id, actual_state_sha256):
    """Reject stale queue messages when they carry a world/state identity."""
    if not isinstance(request, Mapping):
        raise ValueError("continuation request must be a JSON object")
    expected = {"world_session_id": world_session_id, "actual_state_sha256": actual_state_sha256}
    for field, value in expected.items():
        if field in request and request[field] != value:
            raise ValueError(f"continuation request has stale {field}")
    return {"world_session_id": world_session_id, "actual_state_sha256": actual_state_sha256}


def finite_gravity_compensated_drive_target(reference_q, gravity_nm, stiffness_nm_rad,
                                             effort_limits_nm):
    """Bias a finite-force position drive by g/Kp without adding an uncapped force.

    The PhysX position drive remains the sole actuator and retains its official
    maxForce. This is equivalent to a gravity feedforward inside that actuator's
    saturation, not an independent torque source beyond the effort limit.
    """
    values = [np.asarray(value, dtype=float) for value in
              (reference_q, gravity_nm, stiffness_nm_rad, effort_limits_nm)]
    q, gravity, stiffness, limits = values
    if (q.ndim != 1 or any(value.shape != q.shape or not np.all(np.isfinite(value)) for value in values)
            or np.any(stiffness <= 0) or np.any(limits <= 0)):
        raise ValueError("gravity-compensated drive inputs must be finite matching vectors")
    compensated = np.clip(gravity, -limits, limits)
    return q + compensated / stiffness


def sample_joint_reference(timestamps, positions, time_s, *, held=False, reference=None):
    """Same piecewise-linear position path and its segment derivative.

    Interior knots use the right segment. Outside the path and at its two
    endpoints the velocity is zero. A clock hold commands zero velocity without
    changing position. No trajectory resampling or velocity-limit clipping is
    performed: a bound violation must be rejected by the caller.
    """
    if reference is not None:
        from .timing import sample_quintic_knots
        if reference["interpolation"] != "C2_piecewise_quintic_rest_to_rest":
            raise ValueError("unsupported bound joint reference")
        q, velocity = sample_quintic_knots(reference["timestamps_seconds"], reference["positions_rad"], time_s)
        return q, np.zeros_like(velocity) if held else velocity
    times, values = np.asarray(timestamps), np.asarray(positions)
    if not np.isfinite(time_s):
        raise ValueError("reference time must be finite")
    t = float(np.clip(time_s, times[0], times[-1]))
    position = np.asarray([np.interp(t, times, values[:, j]) for j in range(values.shape[1])])
    velocity = np.zeros(values.shape[1], dtype=float)
    if not held and times[0] < t < times[-1]:
        index = min(int(np.searchsorted(times, t, side="right")) - 1, len(times) - 2)
        velocity = (values[index + 1] - values[index]) / (times[index + 1] - times[index])
    return position, velocity


@dataclass
class RestStartGate:
    """Wait with a real position drive until measured q/qd permit a rest start."""
    maximum_wait_s: float = 2.0
    position_tolerance_rad: float = .002
    velocity_tolerance_rad_s: float = .03
    position_derived_speed_tolerance_rad_s: float = .001
    required_stable_s: float = .1
    stable_since_s: float | None = None
    passed: bool = False
    previous_q: np.ndarray | None = None
    previous_time_s: float | None = None

    def evaluate(self, time_s, actual_q, actual_qd, reference_q):
        actual_q = np.asarray(actual_q, float)
        error = float(np.max(np.abs(actual_q-np.asarray(reference_q))))
        speed = float(np.max(np.abs(actual_qd)))
        position_speed = None
        if self.previous_time_s is not None and time_s > self.previous_time_s:
            position_speed = float(np.max(np.abs(actual_q-self.previous_q))/(time_s-self.previous_time_s))
        self.previous_q, self.previous_time_s = actual_q.copy(), time_s
        if not np.isfinite(error+speed):
            return dict(hold=True, reason='ACTUAL_START_STATE_UNAVAILABLE', error_rad=error, speed_rad_s=speed)
        if self.passed:
            return dict(hold=False, reason=None, error_rad=error, speed_rad_s=speed)
        # PhysX can report a small solver velocity at a position-stationary
        # equilibrium. Retain that raw channel, independently require quiet
        # measured positions, and never replace either with commanded zero.
        stable = (error <= self.position_tolerance_rad and speed <= self.velocity_tolerance_rad_s
                  and position_speed is not None
                  and position_speed <= self.position_derived_speed_tolerance_rad_s)
        self.stable_since_s = (time_s if self.stable_since_s is None else self.stable_since_s) if stable else None
        if stable and time_s-self.stable_since_s >= self.required_stable_s:
            self.passed = True
        return dict(hold=not self.passed,
            reason='ACTUAL_START_SETTLING_TIMEOUT' if not self.passed and time_s >= self.maximum_wait_s else None,
            error_rad=error, speed_rad_s=speed, position_derived_speed_rad_s=position_speed,
            actual_q_rad=actual_q.tolist(), actual_qd_rad_s=np.asarray(actual_qd).tolist(),
            reported_velocity_tolerance_rad_s=self.velocity_tolerance_rad_s)


def resolve_actual_task_stage(
    stage_windows,
    trajectory_time_s,
    *,
    grasp_commanded,
    grasp_event_time_s,
    contact_wait_started_s,
    attached=False,
    release_commanded=False,
    release_event_time_s=None,
    support_wait_started_s=None,
):
    """Contact and place follow the actual attachment/release lifecycle.

    CPU stage windows end at arrival, whereas the exported controller schedule
    adds a settling dwell before the grasp command. That dwell is still contact,
    not unattached extraction. Only the runtime's existing bounded contact wait
    can extend it beyond the scheduled grasp event; arbitrary late unattached
    motion never receives a contact-stage exception.  The equivalent release
    dwell remains place while the real constraint is attached; withdrawal starts
    only after the release command removes it.  A bounded support wait may extend
    that state, but arbitrary late attached motion receives no permission.
    """
    def stage_name(window):
        return str(window.get("stage", window.get("name", "motion")))
    # A zero-duration home waypoint is a position marker, not an interval
    # that can mask the actual pregrasp phase at trajectory time zero.
    # Zero-duration contact/place windows retain their lifecycle rules below.
    planned = next((stage_name(window) for window in stage_windows
                    if not (stage_name(window) == "home"
                            and float(window.get("start_time_s", 0.)) == float(window.get("end_time_s", 0.)))
                    if float(window.get("start_time_s", 0.)) <= trajectory_time_s
                    <= float(window.get("end_time_s", 0.))), "motion")
    contact = next((window for window in stage_windows if stage_name(window) == "contact"), None)
    if (not grasp_commanded and contact is not None and grasp_event_time_s is not None
            and trajectory_time_s >= float(contact["start_time_s"])
            and (trajectory_time_s <= float(grasp_event_time_s) or contact_wait_started_s is not None)):
        return "contact"
    place = next((window for window in stage_windows if stage_name(window) == "place"), None)
    if (grasp_commanded and attached and not release_commanded and place is not None
            and release_event_time_s is not None
            and trajectory_time_s >= float(place["start_time_s"])
            and (trajectory_time_s <= float(release_event_time_s)
                 or support_wait_started_s is not None)):
        return "place"
    return planned


def payload_gravity_compensation(jacobian_world, tcp_position_world, payload_com_world,
                                 mass_kg, gravity_world):
    """External attached rigid-body gravity feedforward in world coordinates.

    J is [linear; angular] at the TCP. F=-m*g is the upward compensating force;
    tau=Jv.T@F + Jw.T@((COM-TCP) cross F). This equals d(-m*g.COM)/dq.
    Only gravity is modeled here, not acceleration, contact or measured effort.
    The caller adds this inside the existing finite-force drive saturation.
    """
    jacobian = np.asarray(jacobian_world, dtype=float)
    tcp, com, gravity = [np.asarray(value, dtype=float) for value in
                         (tcp_position_world, payload_com_world, gravity_world)]
    if (jacobian.ndim != 2 or jacobian.shape[0] != 6 or not np.all(np.isfinite(jacobian))
            or any(value.shape != (3,) or not np.all(np.isfinite(value)) for value in (tcp, com, gravity))
            or not np.isfinite(mass_kg) or mass_kg <= 0):
        raise ValueError("payload gravity requires a finite world Jacobian, COM, gravity and positive mass")
    force = -float(mass_kg) * gravity
    return jacobian[:3].T @ force + jacobian[3:].T @ np.cross(com - tcp, force)


def audit_runtime_short_drop(metadata, *, position, rotation, linear_velocity,
                             angular_velocity, current_cartons):
    """Recheck the real release state and current receiver occupancy."""
    from .release_motion import ReleasePolicy, SHORT_DROP_RELEASE, predict_release
    planned = metadata["release_prediction"]
    policy = ReleasePolicy(**planned["policy"])
    release_pose = np.asarray(planned["release_pose_world"], float)
    if (np.linalg.norm(np.asarray(position) - release_pose[:3, 3]) > 0.003
            or np.linalg.norm(np.asarray(rotation) - release_pose[:3, :3]) > 0.02):
        return {"accepted": False, "reason": "ACTUAL_RELEASE_REGION_MISMATCH"}
    box, supports, obstacles = _runtime_release_geometry(metadata, position, rotation, current_cartons)
    if box is None:
        return obstacles
    return predict_release(box, supports, mode=metadata.get("release_mode", SHORT_DROP_RELEASE),
        linear_velocity=linear_velocity, angular_velocity=angular_velocity, obstacles=obstacles,
        policy=policy, contact_tolerance_m=planned["landing_support"]["tolerance_m"],
        edge_tolerance_m=planned["landing_support"]["edge_tolerance_m"])


def _runtime_release_geometry(metadata, position, rotation, current_cartons):
    from .geometry import OBB
    from .release_motion import ReleasePolicy
    primitives = {item["name"]: item for item in metadata["scene_primitives"]}
    target = primitives[metadata["target"]]
    policy = ReleasePolicy(**metadata["release_prediction"]["policy"])
    supports = [OBB(p["center_m"], np.asarray(p["size_m"]) / 2, p["rotation_matrix"], p["name"], "conveyor")
                for p in primitives.values() if p["name"] in metadata["selected_place_support_names"]]
    actual = {p["name"]: p for p in current_cartons}
    obstacles = []
    for name, primitive in primitives.items():
        if name == target["name"]:
            continue
        if primitive.get("dynamic"):
            if name not in actual:
                return None, None, {"accepted": False, "reason": "ACTUAL_RELEASE_OBSTACLE_MISSING", "target": name}
            record = actual[name]
            from .serial_unloading import rotation_from_actual_quaternion
            pose_rotation = rotation_from_actual_quaternion(record["quaternion_wxyz"])
            # Flight-time swept displacement from the actual velocity; never
            # replace it by commanded belt speed.
            drift = np.linalg.norm(record["linear_velocity_m_s"]) * policy.maximum_flight_s
            spin = np.linalg.norm(record["angular_velocity_rad_s"]) * policy.maximum_flight_s
            expansion = drift + spin * np.linalg.norm(np.asarray(primitive["size_m"]) / 2)
            obstacles.append(OBB(record["center_m"], np.asarray(primitive["size_m"]) / 2 + expansion,
                                 pose_rotation, name, "carton"))
        else:
            obstacles.append(OBB(primitive["center_m"], np.asarray(primitive["size_m"]) / 2,
                                 primitive["rotation_matrix"], name, primitive.get("category", "fixed")))
    box = OBB(position, np.asarray(target["size_m"]) / 2, rotation, target["name"], "carton")
    return box, supports, obstacles


class IdealReleaseHandoff:
    """One task's measured release receipt and bounded first-takeover gate.

    Constructed by the runtime before removal, never from a serialized success
    boolean. Evidence is copied on input/output; the original release audit is
    retained separately from the falling body's current-state audit.
    """

    def __init__(self, metadata, *, world_id, task_id, receiver, transport_policy):
        import copy
        self._metadata = copy.deepcopy(metadata)
        self._context = dict(world_id=str(world_id), task_id=str(task_id),
            target=metadata["target"], receiver=receiver, transport_policy=copy.deepcopy(transport_policy))
        if (not world_id or not str(task_id) or receiver not in metadata["selected_place_support_names"]
                or metadata.get("release_mode") != "IDEAL_RECEPTION_RELEASE"
                or transport_policy.get("reception_mode") != "ideal"):
            raise ValueError("invalid ideal release handoff context")
        self._release = self._removal = self._takeover = self._record = None

    def evidence(self):
        import copy
        return copy.deepcopy(dict(context=self._context, release=self._release,
                                  removal=self._removal, takeover=self._takeover))

    def accept_release(self, *, time_s, **measurement):
        import copy
        if self._release is not None or not np.isfinite(time_s):
            raise ValueError("release receipt cannot be replaced")
        audit = audit_runtime_short_drop(self._metadata, **measurement)
        if audit["accepted"]:
            measurement = {k: v.tolist() if isinstance(v, np.ndarray) else v for k, v in measurement.items()}
            self._release = copy.deepcopy(dict(time_s=float(time_s), measurement=measurement, audit=audit))
        return audit

    def confirm_independence(self, *, time_s, joint_present, translation_m, rotation_rad,
                             minimum_translation_m, minimum_rotation_rad):
        values = [time_s, translation_m, rotation_rad, minimum_translation_m, minimum_rotation_rad]
        gates = self._metadata.get("actual_state_gates", {})
        if (self._release is None or joint_present or not np.all(np.isfinite(values))
                or min(values[1:]) < 0 or time_s <= self._release["time_s"]
                or minimum_translation_m != gates.get("release_independence_translation_m", .002)
                or minimum_rotation_rad != gates.get("release_independence_rotation_rad", .01)
                or not (translation_m > minimum_translation_m or rotation_rad > minimum_rotation_rad)):
            raise ValueError("ideal takeover requires measured constraint removal and independence")
        self._removal = dict(time_s=float(time_s), joint_present=False,
            relative_translation_m=float(translation_m), relative_rotation_rad=float(rotation_rad),
            minimum_translation_m=float(minimum_translation_m), minimum_rotation_rad=float(minimum_rotation_rad))

    def audit_takeover(self, metadata, *, world_id, task_id, receiver, transport_policy,
                      target, time_s, joint_present, position, rotation, linear_velocity,
                      angular_velocity, current_cartons):
        import copy
        from .geometry import OBB
        from .release_motion import ReleasePolicy, flight_box, reception_footprint_audit
        result = dict(accepted=False, reason="IDEAL_HANDOFF_MISSING_RELEASE_EVIDENCE")
        def reject(reason):
            result["reason"] = reason
            self._takeover = copy.deepcopy(result)
            return result
        context = dict(world_id=str(world_id), task_id=str(task_id), target=target,
                       receiver=receiver, transport_policy=transport_policy)
        if context != self._context or metadata != self._metadata:
            return reject("IDEAL_HANDOFF_CONTEXT_MISMATCH")
        if self._release is None or self._removal is None or joint_present:
            return reject("IDEAL_HANDOFF_MISSING_RELEASE_EVIDENCE")
        policy = ReleasePolicy(**metadata["release_prediction"]["policy"])
        elapsed = float(time_s) - self._release["time_s"]
        result.update(time_s=float(time_s), elapsed_s=elapsed,
                      actual_release_height_m=self._release["audit"]["height_m"])
        if not np.isfinite(elapsed) or not 0 < elapsed <= policy.maximum_flight_s or time_s < self._removal["time_s"]:
            return reject("IDEAL_HANDOFF_EXPIRED_OR_NONMONOTONIC")
        try:
            box, supports, obstacles = _runtime_release_geometry(metadata, position, rotation, current_cartons)
            if box is None:
                return reject(obstacles["reason"])
            v, w = np.asarray(linear_velocity, float), np.asarray(angular_velocity, float)
            flight_box(box, v, w, 0)  # finite shape/velocity validation
            original = self._release["measurement"]
            start = OBB(original["position"], box.half_extents, original["rotation"], box.name, box.category)
            predicted = flight_box(start, original["linear_velocity"], original["angular_velocity"], elapsed, policy.gravity_m_s2)
            position_error = float(np.linalg.norm(box.center - predicted.center))
            position_limit = (policy.position_uncertainty_m + policy.velocity_uncertainty_m_s * elapsed
                              + .5 * policy.gravity_m_s2 * elapsed * policy.prediction_step_s)
            expected_v = np.asarray(original["linear_velocity"], float) - [0, 0, policy.gravity_m_s2 * elapsed]
            velocity_error = float(np.linalg.norm(v - expected_v))
            result.update(position_error_m=position_error, position_limit_m=position_limit,
                          velocity_error_m_s=velocity_error, current_pose_world=box.world_from_local.tolist(),
                          linear_velocity_m_s=v.tolist(), angular_velocity_rad_s=w.tolist())
            if (position_error > position_limit or velocity_error > policy.velocity_uncertainty_m_s + policy.gravity_m_s2 * policy.prediction_step_s
                    or np.linalg.norm(v) > policy.maximum_landing_speed_m_s
                    or np.linalg.norm(w) > policy.maximum_angular_speed_rad_s
                    or np.linalg.norm(box.rotation - start.rotation) > 2**.5 * policy.maximum_angular_speed_rad_s * elapsed + 1e-6):
                return reject("IDEAL_HANDOFF_ABNORMAL_MOTION")
            support = reception_footprint_audit(box, supports,
                edge_tolerance_m=metadata["release_prediction"]["landing_support"]["edge_tolerance_m"])
            gap = float(np.min(box.corners()[:, 2]) - support["support_z_m"])
            result["first_takeover_height_m"] = gap
            if not support["supported"] or gap < -1e-12:
                return reject("IDEAL_HANDOFF_REGION_OR_PENETRATION")
            landed_pose = box.world_from_local.copy()
            landed_pose[2, 3] -= max(0., gap)
            landed = OBB(landed_pose[:3, 3], box.half_extents, box.rotation, box.name, box.category)
            # One conservative envelope covers release -> measurement -> ideal descent.
            corners = np.vstack([start.corners(), box.corners(), landed.corners()])
            lo, hi = corners.min(axis=0), corners.max(axis=0)
            envelope = OBB((lo+hi)/2, (hi-lo)/2, np.eye(3), box.name, box.category)
            for obstacle in obstacles:
                if obstacle.name not in {s.name for s in supports} and envelope.intersects_obb(obstacle):
                    result["pair"] = [box.name, obstacle.name]
                    return reject("IDEAL_HANDOFF_ENVELOPE_COLLISION")
            result.update(accepted=True, reason="LEGAL_RELEASE_TO_IDEAL_TAKEOVER",
                reception_region=dict(accepted=True, reason="VALIDATED_POST_RELEASE_TRANSITION", support=support,
                    height_policy=policy.to_mapping(),
                    gap_m=gap, current_takeover_pose_world=box.world_from_local.tolist(),
                    actual_release_pose_world=start.world_from_local.tolist(), reception_pose_world=landed_pose.tolist(),
                    vertical_correction_m=-max(0., gap), physical_landing_qualified=False,
                    actual_top_contact_observed=False))
        except (ValueError, KeyError, TypeError):
            return reject("IDEAL_HANDOFF_INVALID_MEASUREMENT")
        self._takeover = copy.deepcopy(result)
        return result

    def takeover_region(self, box, *, time_s, receiver, policy):
        import copy
        if (not self._takeover or not self._takeover["accepted"] or box.name != self._context["target"]
                or receiver != self._context["receiver"] or policy != self._context["transport_policy"]
                or time_s != self._takeover["time_s"]
                or not np.array_equal(box.world_from_local, self._takeover["current_pose_world"])):
            raise ValueError("ideal takeover lacks the bound current-state handoff audit")
        return copy.deepcopy(self._takeover["reception_region"])


class BoundedFreeTransitGate:
    """Pause command time, never physics, until unchanged actual clearance passes."""

    def __init__(self, boundary_time_s, maximum_wait_s, *, waive_timeout=False):
        self.boundary_time_s = float(boundary_time_s)
        self.maximum_wait_s = float(maximum_wait_s)
        if (not np.isfinite(self.boundary_time_s) or self.boundary_time_s < 0
                or not np.isfinite(self.maximum_wait_s) or self.maximum_wait_s < 0):
            raise ValueError("free-transit boundary and wait must be finite and nonnegative")
        self.wait_started_s = None
        self.passed = False
        self.waive_timeout = bool(waive_timeout)
        self.timeout_waived = False
        self.events = []

    def evaluate(self, trajectory_time_s, physical_time_s, actual_free):
        if self.passed or trajectory_time_s < self.boundary_time_s:
            return {"hold": False, "reason": None}
        if actual_free:
            self.passed = True
            self.events.append({"event": "actual_free_transit_gate_passed", "time_s": float(physical_time_s),
                                "wait_elapsed_s": 0.0 if self.wait_started_s is None else physical_time_s - self.wait_started_s})
            return {"hold": False, "reason": None}
        if self.timeout_waived:
            return {"hold": False, "reason": None}
        if self.wait_started_s is None:
            self.wait_started_s = float(physical_time_s)
            self.events.append({"event": "actual_free_transit_wait_started", "time_s": float(physical_time_s),
                                "trajectory_time_s": self.boundary_time_s, "maximum_wait_s": self.maximum_wait_s})
        elapsed = physical_time_s - self.wait_started_s
        reason = "ACTUAL_PAYLOAD_NOT_CLEAR_FOR_FREE_TRANSIT" if elapsed >= self.maximum_wait_s else None
        if reason:
            self.events.append({"event": "actual_free_transit_wait_timeout", "time_s": float(physical_time_s),
                                "wait_elapsed_s": float(elapsed), "reason": reason})
            if self.waive_timeout:
                self.timeout_waived = True
                self.events.append({"event": "USER_WAIVED_FREE_TRANSIT_TIMEOUT", "time_s": float(physical_time_s),
                                    "waived_reason": reason, "actual_clearance_passed": False,
                                    "other_collision_and_physics_monitors_unchanged": True})
                return {"hold": False, "reason": None}
        return {"hold": True, "reason": reason}

    def advance(self, trajectory_time_s, dt_s, duration_s):
        following = min(float(duration_s), trajectory_time_s + dt_s)
        if not (self.passed or self.timeout_waived) and trajectory_time_s < self.boundary_time_s <= following:
            following = self.boundary_time_s
        return following


class BoundedTargetCupReleaseClearance:
    """Separate constraint independence from restoration of target-cup margin.

    The caller keeps moving the verified withdrawal while this latch is open.
    Legacy mode requires LOST. POC also accepts fresh measured separation at
    its policy entry clearance for every known compliant-cup/selected-target
    pair. No robot, rigid insert or neighbor obtains this permission.
    """

    def __init__(self, maximum_wait_s, *, required_clearance_m=None):
        self.maximum_wait_s = float(maximum_wait_s)
        self.required_clearance_m = required_clearance_m
        if required_clearance_m is not None and (not np.isfinite(required_clearance_m) or required_clearance_m <= 0):
            raise ValueError("release pair clearance must be positive and finite")
        if not np.isfinite(self.maximum_wait_s) or self.maximum_wait_s < 0:
            raise ValueError("release clearance wait must be finite and nonnegative")
        self.started_s = None
        self.pending = False
        self.events = []

    def begin(self, time_s):
        if self.started_s is not None:
            raise ValueError("release clearance latch cannot be restarted")
        self.started_s = float(time_s)
        self.pending = True
        self.events.append({"event": "target_cup_release_clearance_started", "time_s": float(time_s),
                            "maximum_wait_s": self.maximum_wait_s})

    def observe(self, time_s, active_headers, *, target_path, compliant_paths, current_pair_separations=None):
        if not self.pending:
            return None
        keys = [key for key in active_headers if target_path in key[:2]
                and any(path in compliant_paths for path in key[2:])]
        if self.required_clearance_m is not None:
            measurements = current_pair_separations or {}
            keys = [key for key in keys if not (
                key in measurements and np.isfinite(measurements[key])
                and measurements[key] >= self.required_clearance_m)]
        elapsed = float(time_s) - self.started_s
        if not keys:
            self.pending = False
            self.events.append({"event": "target_cup_release_clearance_restored", "time_s": float(time_s),
                                "elapsed_s": elapsed, "active_target_compliant_pairs": 0,
                                "required_clearance_m": self.required_clearance_m,
                                "source": "fresh_pair_separation_or_lost" if self.required_clearance_m is not None else "lost"})
            return None
        if elapsed >= self.maximum_wait_s:
            reason = "TARGET_CUP_RELEASE_CLEARANCE_TIMEOUT"
            self.events.append({"event": "target_cup_release_clearance_timeout", "time_s": float(time_s),
                                "elapsed_s": elapsed, "active_target_compliant_pairs": len(keys), "reason": reason})
            return reason
        return None

    def end_for_assumed_reception(self, time_s, *, record):
        from .post_landing_transport import RECEPTION_SOURCE
        if (record.get("completion_source") != RECEPTION_SOURCE or not record.get("attachment_removed")
                or not record.get("reception_region", {}).get("accepted")):
            raise ValueError("unqualified ideal reception")
        self.pending = False
        self.events.append({"event": "target_cup_clearance_ended_by_assumed_reception",
                            "time_s": float(time_s), "physical_clearance_certified": False})

    def end_for_actual_ideal_takeover(self, time_s, *, attachment_removed, actual_top_landing):
        if not attachment_removed or not actual_top_landing:
            raise ValueError("release proximity exemption requires actual released-and-landed takeover")
        self.pending = False
        self.events.append({"event": "target_cup_clearance_ended_by_ideal_takeover",
                            "time_s": float(time_s), "physical_clearance_certified": False})


def _same_tool_collision_boxes(previous, current):
    """Ignore only roundoff from world/flange round trips, never shape changes."""
    if previous is None or current is None:
        return previous is current
    if not isinstance(previous, list) or not isinstance(current, list) or len(previous) != len(current):
        return False
    numeric_fields = {"center_m": (3,), "size_m": (3,), "rotation_matrix": (3, 3)}
    for before, after in zip(previous, current):
        if not isinstance(before, dict) or not isinstance(after, dict) or before.keys() != after.keys():
            return False
        for field in before:
            if field not in numeric_fields:
                if before[field] != after[field]:
                    return False
                continue
            try:
                left, right = np.asarray(before[field], dtype=float), np.asarray(after[field], dtype=float)
            except (ValueError, TypeError):
                return False
            if (left.shape != numeric_fields[field] or right.shape != left.shape
                    or not np.all(np.isfinite(left)) or not np.all(np.isfinite(right))
                    or not np.allclose(left, right, rtol=0.0, atol=1e-12)):
                return False
    return True


def validate_continuation_rendering(previous_metadata, metadata):
    """Allow recording resolution/cadence changes while the physical world is paused."""
    before = previous_metadata.get("rendering")
    after = metadata.get("rendering")
    if before == after:
        return False
    if not isinstance(before, dict) or not isinstance(after, dict):
        raise ValueError("continuation requires the bound rendering contracts")
    if ({k: v for k, v in before.items() if k != "required_output"}
            != {k: v for k, v in after.items() if k != "required_output"}):
        raise ValueError("continuation changed fixed rendering materials or conveyor visuals")
    old_output = before.get("required_output", {})
    output = after.get("required_output", {})
    keys = {"width_px", "height_px", "fps", "camera_mode", "render_every_physics_steps"}
    if not isinstance(output, dict) or set(output) != keys:
        raise ValueError("continuation rendering output is incomplete")
    if output["camera_mode"] != old_output.get("camera_mode"):
        raise ValueError("continuation changed the fixed camera mode")
    for key in keys - {"camera_mode"}:
        value = output[key]
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise ValueError(f"invalid continuation rendering {key}")
    if output["width_px"] % 2 or output["height_px"] % 2:
        raise ValueError("continuation recording dimensions must be even")
    # Preserve the established physics cadence and normal-time video playback.
    if (output["fps"] * output["render_every_physics_steps"]
            != old_output.get("fps", 0) * old_output.get("render_every_physics_steps", 0)):
        raise ValueError("continuation rendering changed the physics-to-video time scale")
    return True


def validate_same_world_continuation(previous_metadata, next_bundle, actual_state, *,
                                     position_tolerance_m=0.001,
                                     joint_tolerance_rad=0.001):
    """Validate a new offline plan against the live, retained physical world.

    This does not restore the scene to the plan. A stale plan is rejected while
    preserving every existing body and the current articulation state.
    """
    if actual_state.get("attached") or actual_state.get("attachment_target"):
        raise ValueError("continuation requires confirmed release of the previous carton")
    if next_bundle.get("format") != "isaacsim_fanuc_replay_v1":
        raise ValueError("unsupported continuation bundle")
    metadata = next_bundle["metadata"]
    for field in ("robot_model", "joint_names", "base_position_m", "base_rpy_rad",
                  "urdf_path", "robot_srdf_path", "robot_srdf_sha256", "physics", "collision_policy",
                  "official_model_manifest_sha256", "robot_link_dynamics", "robot_tool_mass_accounting",
                  "joint_effort_limits_nm", "joint_velocity_limits_rad_s",
                  "joint_position_lower_limits_rad", "joint_position_upper_limits_rad",
                  "joint_drive_stiffness_nm_rad", "joint_drive_damping_nm_s_rad",
                  "joint_gravity_feedforward_enabled", "joint_velocity_feedforward_enabled",
                  "attached_payload_gravity_feedforward_enabled", "tool_length_m",
                  "isaac_grasp_body_path_suffix", "flange_offset_from_grasp_body_m",
                  "conveyor", "actual_state_gates", "camera", "post_landing_transport"):
        if metadata.get(field) != previous_metadata.get(field):
            raise ValueError(f"continuation changed fixed physical input: {field}")
    rendering_changed = validate_continuation_rendering(previous_metadata, metadata)
    for field in ("physical_cup_compression_m", "cup_radius_m", "task_tcp_from_flange_m",
                  "compressed_contact_plane_from_flange_m", "mass_properties_path",
                  "physical_cup_count", "mask_bit_order_cup_ids", "cup_centers_tool_yz_m",
                  "gripper_mass_kg", "center_of_mass_from_flange_m", "inertia_at_com_kg_m2",
                  "step_path", "visual_mesh_path", "collision_mesh_path",
                  "flange_origin_step_mm", "step_from_tool_rotation_matrix", "frame_contract",
                  "suction_mode", "holding_capacity_assumption",
                  "max_grip_distance_m", "max_normal_misalignment_rad", "maximum_contact_penetration_m"):
        if metadata.get("gripper", {}).get(field) != previous_metadata.get("gripper", {}).get(field):
            raise ValueError(f"continuation changed tool physical input: {field}")
    box_field = "qualified_rigid_collision_boxes_tool_frame"
    if not _same_tool_collision_boxes(previous_metadata.get("gripper", {}).get(box_field),
                                      metadata.get("gripper", {}).get(box_field)):
        raise ValueError(f"continuation changed tool physical input: {box_field}")
    if (not metadata.get("simulation_execution_ready") or metadata.get("execution_blockers")):
        raise ValueError("continuation bundle is not simulation ready")
    current = {item["name"]: item for item in actual_state["cartons"]}
    from .post_landing_transport import ideal_transport_ids
    ideal_transport_ids(metadata.get("post_landing_transport"), actual_state.get("receiver_transport_state", {}))
    if metadata.get("receiver_transport_state", {}) != actual_state.get("receiver_transport_state", {}):
        raise ValueError("continuation changed observed post-landing transport states")
    dynamic = {item["name"]: item for item in metadata["scene_primitives"] if item.get("dynamic")}
    if set(current) != set(dynamic):
        raise ValueError("continuation must retain every live carton identity")
    if metadata.get("target") in actual_state.get("completed_carton_ids", []):
        raise ValueError("continuation selected an already completed carton")
    for event_field in ("completed_carton_ids", "handed_off_ids"):
        if set(metadata.get(event_field, [])) != set(actual_state.get(event_field, [])):
            raise ValueError(f"continuation must preserve cumulative execution events: {event_field}")
    for name, record in current.items():
        if np.linalg.norm(np.asarray(record["position_m"]) - dynamic[name]["center_m"]) > position_tolerance_m:
            raise ValueError(f"continuation plan has stale actual carton position: {name}")
        quaternion = np.asarray(record["orientation_wxyz"], dtype=float)
        quaternion /= np.linalg.norm(quaternion)
        w, x, y, z = quaternion
        rotation = np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
                             [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
                             [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])
        if np.linalg.norm(rotation - dynamic[name]["rotation_matrix"]) > 0.002:
            raise ValueError(f"continuation plan has stale actual carton rotation: {name}")
    previous_static = {item["name"]: item for item in previous_metadata["scene_primitives"] if not item.get("dynamic")}
    next_static = {item["name"]: item for item in metadata["scene_primitives"] if not item.get("dynamic")}
    if previous_static != next_static:
        raise ValueError("continuation changed fixed scene structure")
    actual_order = list(actual_state.get("joint_names", metadata["joint_names"]))
    actual_q = np.asarray(actual_state["q_rad"])[[actual_order.index(name) for name in metadata["joint_names"]]]
    _, commands = replay_command_arrays(next_bundle, metadata["joint_names"])
    first = commands[0]
    if first.shape != actual_q.shape or np.max(np.abs(first - actual_q)) > joint_tolerance_rad:
        raise ValueError("continuation path does not start at actual joint configuration")
    return {"accepted": True, "retained_carton_count": len(current),
            "recording_output_changed": rendering_changed,
            "world_session_id": actual_state.get("world_session_id"),
            "scene_restored_or_teleported": False}


class ActualStackContactMonitor:
    """Bound actual contact/sliding without suppressing PhysX carton shapes.

    The geometric free-space transition latches only when every current
    neighbor clears the policy distance. Monitoring uses actual world states;
    neither a stage label nor a fixed extraction distance proves separation.
    """

    def __init__(self, target, neighbors, policy):
        self.initial_target = target
        self.initial_neighbors = {item.name: item for item in neighbors if item.name != target.name}
        self.policy = policy
        self.free_space_reached = not self.initial_neighbors
        self.progress_reference = np.asarray(target.center).copy()
        self.progress_clock = None
        self.instability_clock = None
        self.peak_penetration_m = 0.0
        self.peak_neighbor_displacement_m = 0.0
        self.peak_neighbor_tilt_rad = 0.0
        self.first_free_space_time_s = None
        self.observations = 0

    def observe(self, time_s, target, neighbors, *, commanded_motion, geometry=None,
                allow_free_space_transition=True):
        current = {item.name: item for item in neighbors}
        missing = set(self.initial_neighbors) - set(current)
        if missing:
            raise ValueError(f"actual stack state lost carton identities: {sorted(missing)}")
        if geometry is not None:
            if (geometry['policy_fingerprint'] != self.policy.fingerprint
                    or geometry['time_s'] != time_s
                    or geometry['sample_phase'] != 'POST_WORLD_STEP_PHYSX_TENSOR'
                    or geometry['boxes'].get(target.name) is not target
                    or set(geometry['pairs']) != set(self.initial_neighbors)
                    or any(geometry['boxes'].get(name) is not current[name] for name in self.initial_neighbors)):
                raise ValueError('stack monitor geometry does not bind current measurement')
            clearance = min((p['surface_distance_m'] for p in geometry['pairs'].values()), default=float('inf'))
            penetration = max((p['sat_overlap_bound_m'] for p in geometry['pairs'].values()), default=0.)
        else:
            clearance = min((target.signed_distance_obb(current[name])
                             for name in self.initial_neighbors), default=float("inf"))
            penetration = max(0.0, -clearance)
        if geometry is None and self.policy.poc_pair_clearance and clearance > 0:
            from .pair_clearance import obb_surface_distance
            clearance = min((obb_surface_distance(target, current[name])
                             for name in self.initial_neighbors), default=float("inf"))
        drift = max((float(np.linalg.norm(current[name].center - original.center))
                     for name, original in self.initial_neighbors.items()), default=0.0)
        tilt = max((float(np.arccos(np.clip(current[name].rotation[:, 2] @ original.rotation[:, 2], -1, 1)))
                    for name, original in self.initial_neighbors.items()), default=0.0)
        self.peak_penetration_m = max(self.peak_penetration_m, penetration)
        self.peak_neighbor_displacement_m = max(self.peak_neighbor_displacement_m, drift)
        self.peak_neighbor_tilt_rad = max(self.peak_neighbor_tilt_rad, tilt)
        self.observations += 1
        previously_free = self.free_space_reached
        if allow_free_space_transition and not self.free_space_reached and clearance >= self.policy.free_space_clearance_m:
            self.free_space_reached = True
            self.first_free_space_time_s = float(time_s)
        if penetration > self.policy.maximum_actual_penetration_m:
            reason = "SEVERE_ACTUAL_STACK_PENETRATION"
        elif previously_free and clearance < (
            self.policy.free_space_clearance_m
            - self.policy.free_space_clearance_loss_tolerance_m
        ):
            reason = "ACTUAL_FREE_TRANSIT_STACK_CLEARANCE_LOST"
        elif drift > self.policy.maximum_neighbor_displacement_m:
            reason = "EXCESSIVE_ACTUAL_NEIGHBOR_DISPLACEMENT"
        else:
            reason = None
        if tilt > self.policy.maximum_neighbor_tilt_rad:
            if self.instability_clock is None:
                self.instability_clock = float(time_s)
            if time_s - self.instability_clock >= getattr(self.policy, "neighbor_instability_duration_s", 0.5):
                reason = reason or "PERSISTENT_ACTUAL_STACK_INSTABILITY"
        else:
            self.instability_clock = None
        progress = float(np.linalg.norm(target.center - self.progress_reference))
        if not commanded_motion or self.progress_clock is None or progress >= self.policy.minimum_progress_m:
            self.progress_clock = float(time_s)
            self.progress_reference = np.asarray(target.center).copy()
        elif not self.free_space_reached and time_s - self.progress_clock > self.policy.progress_timeout_s:
            reason = reason or "ACTUAL_STACK_EXTRACTION_STALLED"
        return {"accepted": reason is None, "reason": reason,
                "minimum_stack_clearance_m": None if not np.isfinite(clearance) else float(max(0., clearance) if self.policy.poc_pair_clearance else clearance),
                "actual_penetration_m": None if self.policy.poc_pair_clearance else penetration,
                "sat_overlap_bound_m": penetration, "penetration_query_scope": "SAT_BOUND_NOT_MEASURED_DEPTH",
                "policy_fingerprint": self.policy.fingerprint, "neighbor_displacement_m": drift,
                "neighbor_tilt_rad": tilt, "free_space_reached": self.free_space_reached,
                "first_free_space_time_s": self.first_free_space_time_s}

    def summary(self):
        return {"observations": self.observations, "box_box_physics_enabled": True,
                "free_space_reached": self.free_space_reached,
                "first_free_space_time_s": self.first_free_space_time_s,
                "peak_actual_penetration_m": None if self.policy.poc_pair_clearance else self.peak_penetration_m,
                "peak_sat_overlap_bound_m": self.peak_penetration_m,
                "peak_neighbor_displacement_m": self.peak_neighbor_displacement_m,
                "peak_neighbor_tilt_rad": self.peak_neighbor_tilt_rad,
                "contact_force_channel": "NOT_USED_BY_GEOMETRIC_DISTURBANCE_MONITOR"}


@dataclass(frozen=True)
class AttachmentContactAudit:
    """Result of checking every active cup ray against the target carton."""

    accepted: bool
    reason: str | None
    signed_gaps_m: tuple[float | None, ...]
    normal_alignments: tuple[float | None, ...]
    hit_count: int
    within_gap_count: int
    normal_aligned_count: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "accepted": self.accepted,
            "reason": self.reason,
            "signed_gaps_m": list(self.signed_gaps_m),
            "normal_alignments": list(self.normal_alignments),
            "hit_count": self.hit_count,
            "within_gap_count": self.within_gap_count,
            "normal_aligned_count": self.normal_aligned_count,
        }


@dataclass(frozen=True)
class PayloadSupportAudit:
    """Actual-state gate for releasing a payload onto one declared support.

    The audit is intentionally geometric and kinematic.  It does not infer a
    support from the planned release time: the payload bottom plane must be at
    the real support top plane, their horizontal footprints must overlap, and
    the payload must have settled below the configured velocity thresholds.
    """

    accepted: bool
    reason: str | None
    support_name: str
    signed_normal_gap_m: float
    footprint_overlap_ratio: float
    support_normal_alignment: float
    linear_speed_m_s: float
    angular_speed_rad_s: float
    support_surface_velocity_world_m_s: tuple[float, float, float] | None = None
    transport_velocity_error_m_s: float | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "accepted": self.accepted,
            "reason": self.reason,
            "support_name": self.support_name,
            "signed_normal_gap_m": self.signed_normal_gap_m,
            "footprint_overlap_ratio": self.footprint_overlap_ratio,
            "support_normal_alignment": self.support_normal_alignment,
            "linear_speed_m_s": self.linear_speed_m_s,
            "angular_speed_rad_s": self.angular_speed_rad_s,
            "support_surface_velocity_world_m_s": (
                None if self.support_surface_velocity_world_m_s is None
                else list(self.support_surface_velocity_world_m_s)
            ),
            "transport_velocity_error_m_s": self.transport_velocity_error_m_s,
        }


def _rotation(value: Sequence[Sequence[float]], name: str) -> np.ndarray:
    result = np.asarray(value, dtype=float)
    if (
        result.shape != (3, 3)
        or not np.all(np.isfinite(result))
        or not np.allclose(result.T @ result, np.eye(3), atol=1e-9, rtol=0.0)
        or not np.isclose(np.linalg.det(result), 1.0, atol=1e-9, rtol=0.0)
    ):
        raise ValueError(f"{name} must be a finite proper rotation matrix")
    return result


def audit_surface_attachment_contact(
    *,
    grasp_body_position_m: Sequence[float],
    grasp_body_rotation: Sequence[Sequence[float]],
    contact_plane_from_grasp_body_m: float,
    active_cup_offsets_yz_m: Sequence[Sequence[float]],
    target_center_m: Sequence[float],
    target_rotation: Sequence[Sequence[float]],
    target_size_m: Sequence[float],
    max_attachment_gap_m: float,
    max_normal_misalignment_rad: float,
    maximum_penetration_m: float = 1e-5,
) -> AttachmentContactAudit:
    """Audit physical cup-plane contact without moving either rigid body.

    Cup rays start on the *nominal compressed* physical contact plane and point
    along grasp-body +X.  A negative signed gap means that the nominal contact
    point has already crossed the carton face; only the small explicit
    numerical penetration tolerance is accepted.
    """

    body_position = np.asarray(grasp_body_position_m, dtype=float)
    carton_center = np.asarray(target_center_m, dtype=float)
    carton_size = np.asarray(target_size_m, dtype=float)
    cup_offsets = np.asarray(active_cup_offsets_yz_m, dtype=float)
    body_rotation = _rotation(grasp_body_rotation, "grasp_body_rotation")
    carton_rotation = _rotation(target_rotation, "target_rotation")
    scalars = (
        float(contact_plane_from_grasp_body_m),
        float(max_attachment_gap_m),
        float(max_normal_misalignment_rad),
        float(maximum_penetration_m),
    )
    if body_position.shape != (3,) or carton_center.shape != (3,):
        raise ValueError("body and target centers must contain three values")
    if carton_size.shape != (3,) or np.any(carton_size <= 0.0):
        raise ValueError("target_size_m must contain three positive values")
    if cup_offsets.ndim != 2 or cup_offsets.shape[1] != 2 or len(cup_offsets) == 0:
        raise ValueError("active_cup_offsets_yz_m must have shape (N, 2)")
    if not all(np.all(np.isfinite(value)) for value in (body_position, carton_center, carton_size, cup_offsets)):
        raise ValueError("attachment geometry must be finite")
    if not all(np.isfinite(value) for value in scalars):
        raise ValueError("attachment tolerances and contact-plane offset must be finite")
    if max_attachment_gap_m < 0.0 or maximum_penetration_m < 0.0:
        raise ValueError("attachment gap and penetration tolerance must be non-negative")
    if not 0.0 <= max_normal_misalignment_rad < 0.5 * np.pi:
        raise ValueError("normal misalignment must be in [0, pi/2)")

    half_extents = 0.5 * carton_size
    ray_world = body_rotation[:, 0]
    ray_local = carton_rotation.T @ ray_world
    minimum_alignment = cos(max_normal_misalignment_rad)
    signed_gaps: list[float | None] = []
    alignments: list[float | None] = []

    for offset_y, offset_z in cup_offsets:
        point_body = np.asarray(
            [contact_plane_from_grasp_body_m, float(offset_y), float(offset_z)],
            dtype=float,
        )
        point_world = body_position + body_rotation @ point_body
        point_local = carton_rotation.T @ (point_world - carton_center)
        ray_min = -float("inf")
        ray_max = float("inf")
        entry_axis: int | None = None
        entry_outward_sign = 0.0
        intersects = True
        for axis in range(3):
            direction = float(ray_local[axis])
            if abs(direction) <= 1e-12:
                if abs(float(point_local[axis])) > half_extents[axis] + 1e-12:
                    intersects = False
                    break
                continue
            lower = (-half_extents[axis] - point_local[axis]) / direction
            upper = (half_extents[axis] - point_local[axis]) / direction
            if lower <= upper:
                near, far, outward_sign = lower, upper, -1.0
            else:
                near, far, outward_sign = upper, lower, 1.0
            if near > ray_min:
                ray_min = near
                entry_axis = axis
                entry_outward_sign = outward_sign
            ray_max = min(ray_max, far)
            if ray_min > ray_max + 1e-12:
                intersects = False
                break
        if not intersects or entry_axis is None or ray_max < max(ray_min, 0.0) - 1e-12:
            signed_gaps.append(None)
            alignments.append(None)
            continue
        outward_local = np.zeros(3, dtype=float)
        outward_local[entry_axis] = entry_outward_sign
        outward_world = carton_rotation @ outward_local
        alignment = float(np.clip((-ray_world) @ outward_world, -1.0, 1.0))
        signed_gaps.append(float(ray_min))
        alignments.append(alignment)

    hit_count = sum(value is not None for value in signed_gaps)
    comparison_epsilon_m = 1e-12
    within_gap_count = sum(
        value is not None
        and -maximum_penetration_m - comparison_epsilon_m
        <= value
        <= max_attachment_gap_m + comparison_epsilon_m
        for value in signed_gaps
    )
    normal_aligned_count = sum(
        value is not None and value >= minimum_alignment
        for value in alignments
    )
    cup_count = len(cup_offsets)
    if hit_count != cup_count:
        reason = "ACTIVE_CUP_RAY_MISSES_TARGET"
    elif within_gap_count != cup_count:
        if any(
            value is not None
            and value < -maximum_penetration_m - comparison_epsilon_m
            for value in signed_gaps
        ):
            reason = "PHYSICAL_CONTACT_PLANE_PENETRATES_TARGET"
        else:
            reason = "PHYSICAL_CONTACT_GAP_EXCEEDS_LIMIT"
    elif normal_aligned_count != cup_count:
        reason = "PHYSICAL_CONTACT_NORMAL_MISALIGNED"
    else:
        reason = None
    return AttachmentContactAudit(
        accepted=reason is None,
        reason=reason,
        signed_gaps_m=tuple(signed_gaps),
        normal_alignments=tuple(alignments),
        hit_count=hit_count,
        within_gap_count=within_gap_count,
        normal_aligned_count=normal_aligned_count,
    )


def audit_payload_support_contact(
    *,
    payload_center_m: Sequence[float],
    payload_rotation: Sequence[Sequence[float]],
    payload_size_m: Sequence[float],
    payload_linear_velocity_m_s: Sequence[float],
    payload_angular_velocity_rad_s: Sequence[float],
    support: Mapping[str, Any],
    supports: Sequence[Mapping[str, Any]] | None = None,
    max_support_gap_m: float = 0.003,
    maximum_penetration_m: float = 0.001,
    minimum_footprint_overlap_ratio: float = 1.0,
    max_support_tilt_rad: float = np.deg2rad(5.0),
    max_linear_speed_m_s: float = 0.03,
    max_angular_speed_rad_s: float = 0.08,
    support_surface_velocity_world_m_s: Sequence[float] | None = None,
    footprint_boundary_tolerance_m: float = 1e-6,
    evaluate_stability: bool = True,
) -> PayloadSupportAudit:
    """Require real, non-penetrating receiver support before vacuum release.

    ``support.rotation_matrix[:, 2]`` is the support normal.  This keeps the
    calculation valid for a known tilted receiver while still rejecting a
    side-wall as a support because its local-X/Y footprint and top plane would
    not match the payload bottom plane.
    """

    payload_center = np.asarray(payload_center_m, dtype=float)
    payload_size = np.asarray(payload_size_m, dtype=float)
    payload_linear_velocity = np.asarray(payload_linear_velocity_m_s, dtype=float)
    payload_angular_velocity = np.asarray(payload_angular_velocity_rad_s, dtype=float)
    support_velocity = (None if support_surface_velocity_world_m_s is None else
                        np.asarray(support_surface_velocity_world_m_s, dtype=float))
    payload_rotation_matrix = _rotation(payload_rotation, "payload_rotation")
    support_center = np.asarray(support.get("center_m", []), dtype=float)
    support_size = np.asarray(support.get("size_m", []), dtype=float)
    support_rotation = _rotation(
        support.get("rotation_matrix", []), "support rotation"
    )
    support_name = str(support.get("name", "")).strip()
    scalars = np.asarray(
        [
            max_support_gap_m,
            maximum_penetration_m,
            minimum_footprint_overlap_ratio,
            max_support_tilt_rad,
            max_linear_speed_m_s,
            max_angular_speed_rad_s,
        ],
        dtype=float,
    )
    if (
        payload_center.shape != (3,)
        or payload_size.shape != (3,)
        or payload_linear_velocity.shape != (3,)
        or payload_angular_velocity.shape != (3,)
        or (support_velocity is not None and support_velocity.shape != (3,))
        or support_center.shape != (3,)
        or support_size.shape != (3,)
        or not support_name
        or not all(
            np.all(np.isfinite(value))
            for value in (
                payload_center,
                payload_size,
                payload_linear_velocity,
                payload_angular_velocity,
                support_center,
                support_size,
                np.zeros(3) if support_velocity is None else support_velocity,
            )
        )
        or np.any(payload_size <= 0.0)
        or np.any(support_size <= 0.0)
        or not np.all(np.isfinite(scalars))
        or max_support_gap_m < 0.0
        or maximum_penetration_m < 0.0
        or not 0.0 < minimum_footprint_overlap_ratio <= 1.0
        or not 0.0 <= max_support_tilt_rad < 0.5 * np.pi
        or max_linear_speed_m_s < 0.0
        or max_angular_speed_rad_s < 0.0
    ):
        raise ValueError("payload support audit inputs must be finite and physical")

    support_from_payload = support_rotation.T @ payload_rotation_matrix
    payload_half = 0.5 * payload_size
    support_half = 0.5 * support_size
    payload_center_support = support_rotation.T @ (payload_center - support_center)
    projected_payload_half = np.abs(support_from_payload) @ payload_half
    signed_gap = float(
        payload_center_support[2]
        - projected_payload_half[2]
        - support_half[2]
    )

    overlaps = []
    payload_widths = []
    for axis in (0, 1):
        payload_min = float(payload_center_support[axis] - projected_payload_half[axis])
        payload_max = float(payload_center_support[axis] + projected_payload_half[axis])
        support_min = -float(support_half[axis])
        support_max = float(support_half[axis])
        overlaps.append(max(0.0, min(payload_max, support_max) - max(payload_min, support_min)))
        payload_widths.append(2.0 * float(projected_payload_half[axis]))
    payload_area = payload_widths[0] * payload_widths[1]
    overlap_ratio = float(overlaps[0] * overlaps[1] / payload_area)
    union_audit = None
    if supports is not None:
        from .conveyor_placement import support_union_audit
        from .geometry import OBB
        actual_box = OBB(payload_center, payload_half, payload_rotation_matrix, "actual_payload", "carton")
        support_boxes = [OBB(
            np.asarray(item["center_m"], dtype=float),
            0.5 * np.asarray(item["size_m"], dtype=float),
            _rotation(item["rotation_matrix"], "support rotation"),
            str(item["name"]), "conveyor",
        ) for item in supports]
        union_audit = support_union_audit(
            actual_box, support_boxes,
            contact_tolerance_m=max(max_support_gap_m, maximum_penetration_m),
            max_support_tilt_rad=max_support_tilt_rad,
            edge_tolerance_m=footprint_boundary_tolerance_m,
        )
        overlap_ratio = (1.0 - union_audit["unsupported_area_m2"] / union_audit["footprint_area_m2"]
                         if union_audit["footprint_area_m2"] > 0 else 0.0)
        support_name = "+".join(union_audit["receiver_names"]) or support_name
    # A carton may be placed on any of its six physical faces after a loaded
    # reorientation.  Compare the inward normal of the actual bottom face with
    # the receiver normal; local +Z is only correct for an unrotated carton.
    if union_audit is not None and union_audit["support_face_local_axis"] is not None:
        bottom_axis = int(union_audit["support_face_local_axis"])
        bottom_sign = int(union_audit["support_face_local_sign"])
    else:
        support_normal_in_payload = payload_rotation_matrix.T @ support_rotation[:, 2]
        bottom_axis = int(np.argmax(np.abs(support_normal_in_payload)))
        bottom_sign = -1 if support_normal_in_payload[bottom_axis] > 0.0 else 1
    payload_inward_support_normal = (
        -bottom_sign * payload_rotation_matrix[:, bottom_axis]
    )
    support_normal_alignment = float(
        np.clip(payload_inward_support_normal @ support_rotation[:, 2], -1.0, 1.0)
    )
    linear_speed = float(np.linalg.norm(payload_linear_velocity))
    angular_speed = float(np.linalg.norm(payload_angular_velocity))
    transport_velocity_error = (None if support_velocity is None else
                                float(np.linalg.norm(payload_linear_velocity - support_velocity)))
    epsilon = 1e-12
    if support_normal_alignment < cos(max_support_tilt_rad) - epsilon:
        reason = "PAYLOAD_SUPPORT_NORMAL_MISALIGNED"
    elif signed_gap > max_support_gap_m + epsilon:
        reason = "PAYLOAD_NOT_IN_SUPPORT_CONTACT"
    elif signed_gap < -maximum_penetration_m - epsilon:
        reason = "PAYLOAD_PENETRATES_SUPPORT"
    elif (
        union_audit is not None
        and not union_audit["supported"]
    ):
        reason = ("PAYLOAD_SUPPORT_FOOTPRINT_INSUFFICIENT" if union_audit["reason"] == "UNSUPPORTED_FOOTPRINT"
                  else "PAYLOAD_NOT_IN_SUPPORT_CONTACT")
    elif overlap_ratio + epsilon < minimum_footprint_overlap_ratio:
        reason = "PAYLOAD_SUPPORT_FOOTPRINT_INSUFFICIENT"
    elif not evaluate_stability:
        # First top landing is a geometric/contact event. The caller still
        # requires a real contact report; no speed, friction or later tipping
        # qualification is implied by this explicitly selected mode.
        reason = None
    elif angular_speed > max_angular_speed_rad_s + epsilon:
        reason = "PAYLOAD_ANGULAR_SPEED_TOO_HIGH_FOR_RELEASE"
    elif support_velocity is None and linear_speed > max_linear_speed_m_s + epsilon:
        reason = "PAYLOAD_LINEAR_SPEED_TOO_HIGH_FOR_RELEASE"
    elif support_velocity is not None:
        support_speed = float(np.linalg.norm(support_velocity))
        direction = support_velocity / support_speed
        along = float(payload_linear_velocity @ direction)
        normal_speed = abs(float(payload_linear_velocity @ support_rotation[:, 2]))
        lateral = payload_linear_velocity - along * direction
        lateral -= float(lateral @ support_rotation[:, 2]) * support_rotation[:, 2]
        if (support_speed <= epsilon
                or along < -max_linear_speed_m_s - epsilon
                or along > support_speed + max_linear_speed_m_s + epsilon
                or normal_speed > max_linear_speed_m_s + epsilon
                or float(np.linalg.norm(lateral)) > max_linear_speed_m_s + epsilon):
            reason = "PAYLOAD_VELOCITY_INCOMPATIBLE_WITH_MOVING_SUPPORT"
        else:
            reason = None
    else:
        reason = None
    return PayloadSupportAudit(
        accepted=reason is None,
        reason=reason,
        support_name=support_name,
        signed_normal_gap_m=signed_gap,
        footprint_overlap_ratio=overlap_ratio,
        support_normal_alignment=support_normal_alignment,
        linear_speed_m_s=linear_speed,
        angular_speed_rad_s=angular_speed,
        support_surface_velocity_world_m_s=(
            None if support_velocity is None else tuple(float(value) for value in support_velocity)
        ),
        transport_velocity_error_m_s=transport_velocity_error,
    )


def _horizontal_footprint_contains(
    payload_center_m: np.ndarray,
    primitive: Mapping[str, Any],
    tolerance_m: float,
) -> bool:
    center = np.asarray(primitive.get("center_m", []), dtype=float)
    size = np.asarray(primitive.get("size_m", []), dtype=float)
    rotation = _rotation(primitive.get("rotation_matrix", []), "conveyor rotation")
    if center.shape != (3,) or size.shape != (3,) or np.any(size <= 0.0):
        raise ValueError("conveyor primitives require finite positive OBB geometry")
    local = rotation.T @ (payload_center_m - center)
    # Only the OBB's horizontal footprint decides transfer ownership.  Vertical
    # support/contact remains PhysX's responsibility and is audited separately.
    world_axes = rotation[:, :2]
    if np.any(np.abs(world_axes[2, :]) > 1e-9):
        raise ValueError("conveyor support surfaces must be horizontal")
    return bool(
        abs(float(local[0])) <= 0.5 * float(size[0]) + tolerance_m
        and abs(float(local[1])) <= 0.5 * float(size[1]) + tolerance_m
    )


def select_active_conveyor_surfaces(
    *,
    payload_center_m: Sequence[float] | None,
    conveyor_primitives: Mapping[str, Mapping[str, Any]],
    started: bool,
    exclusive: bool,
    current_surface: str | None = None,
    preferred_initial_surface: str | None = None,
    preferred_overlap_surface: str | None = None,
    payload_size_m: Sequence[float] | None = None,
    payload_rotation: Sequence[Sequence[float]] | None = None,
    footprint_tolerance_m: float = 1e-6,
) -> tuple[str, ...]:
    """Select continuous belt drives with footprint-based transfer ownership.

    Away from a transfer all physical belts keep running.  When the payload's
    actual bottom footprint overlaps multiple belt surfaces, only the declared
    transfer owner among those competing contacts remains driven.  Other belts
    that cannot contact this payload continue running.
    """

    if not started:
        return ()
    if footprint_tolerance_m < 0.0 or not np.isfinite(footprint_tolerance_m):
        raise ValueError("footprint_tolerance_m must be finite and non-negative")
    names = tuple(sorted(str(name) for name in conveyor_primitives))
    if not exclusive:
        return names
    if payload_center_m is None:
        return ()
    center = np.asarray(payload_center_m, dtype=float)
    if center.shape != (3,) or not np.all(np.isfinite(center)):
        raise ValueError("payload_center_m must contain three finite values")
    if payload_size_m is not None or payload_rotation is not None:
        if payload_size_m is None or payload_rotation is None:
            raise ValueError("payload size and rotation must be supplied together")
        from .conveyor_placement import footprint_support_overlap_areas
        from .geometry import OBB
        payload = OBB(
            center,
            0.5 * np.asarray(payload_size_m, dtype=float),
            _rotation(payload_rotation, "payload rotation"),
            "active_conveyor_payload",
            "carton",
        )
        supports = [OBB(
            np.asarray(conveyor_primitives[name]["center_m"], dtype=float),
            0.5 * np.asarray(conveyor_primitives[name]["size_m"], dtype=float),
            _rotation(conveyor_primitives[name]["rotation_matrix"], "conveyor rotation"),
            name,
            "conveyor",
        ) for name in names]
        areas = footprint_support_overlap_areas(
            payload, supports, edge_tolerance_m=footprint_tolerance_m
        )
        matching = tuple(name for name in names if areas[name] > 1e-12)
    else:
        matching = tuple(
            name
            for name in names
            if _horizontal_footprint_contains(center, conveyor_primitives[name], footprint_tolerance_m)
        )
    if len(matching) <= 1:
        owner = matching[0] if matching else (
            preferred_initial_surface if preferred_initial_surface in names else current_surface
        )
        return tuple(([owner] if owner in names else []) + [name for name in names if name != owner])
    if len(matching) > 1:
        owner = next((candidate for candidate in (
            preferred_overlap_surface, preferred_initial_surface, current_surface
        ) if candidate in matching), None)
        if owner is None:
            return ()
        return tuple([str(owner), *[name for name in names if name not in matching]])
    return names


__all__ = [
    "AttachmentContactAudit",
    "PayloadSupportAudit",
    "audit_payload_support_contact",
    "audit_surface_attachment_contact",
    "select_active_conveyor_surfaces",
]
